-keepclassmembers class com.apsa.shopifyagent.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.apsa.shopifyagent.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
