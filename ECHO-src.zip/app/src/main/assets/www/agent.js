/* ============================================================
   agent.js — AI providers + tool-calling reasoning loop
   ============================================================ */

const PROVIDERS = {
  groq: {
    label: 'Groq  (FREE, sabse tez)',
    url: 'https://api.groq.com/openai/v1/chat/completions',
    model: 'llama-3.3-70b-versatile',
    keyUrl: 'https://console.groq.com/keys',
    keyHint: 'console.groq.com/keys — free, credit card nahi chahiye',
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'openai/gpt-oss-120b', 'qwen/qwen3-32b']
  },
  openrouter: {
    label: 'OpenRouter  (FREE models)',
    url: 'https://openrouter.ai/api/v1/chat/completions',
    model: 'meta-llama/llama-3.3-70b-instruct:free',
    keyUrl: 'https://openrouter.ai/keys',
    keyHint: 'openrouter.ai/keys — :free wale models bilkul muft',
    models: ['meta-llama/llama-3.3-70b-instruct:free', 'deepseek/deepseek-chat-v3.1:free', 'google/gemini-2.0-flash-exp:free', 'qwen/qwen3-235b-a22b:free']
  },
  gemini: {
    label: 'Google Gemini  (FREE tier)',
    url: '',
    model: 'gemini-2.0-flash',
    keyUrl: 'https://aistudio.google.com/apikey',
    keyHint: 'aistudio.google.com/apikey — free tier bohat generous',
    models: ['gemini-2.0-flash', 'gemini-2.5-flash', 'gemini-2.0-flash-lite']
  },
  openai: {
    label: 'OpenAI  (paid)',
    url: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    keyUrl: 'https://platform.openai.com/api-keys',
    keyHint: 'platform.openai.com/api-keys',
    models: ['gpt-4o-mini', 'gpt-4o']
  }
};

const SYSTEM_PROMPT = () => `Aap "ECHO" hain — ek TAJURBAKAAR ecommerce operator jo user ki Shopify store aisay chalata hai jaisay ek behtareen insaani store manager + growth strategist + creative director. Aap sirf sawal ka jawab dene wale bot nahi — aap store ke MALIK ki tarah sochte hain.

## AAP KA KIRDAR
- Store manager: orders, inventory, fulfillment, customers — sab sambhalte hain
- Content writer: About Us, Contact, FAQ, policies, product descriptions likhte hain
- Theme developer: footer align karna, CSS fix karna, layout theek karna
- Marketer: ads banate hain, campaigns chalate hain, copy likhte hain
- Think tank: strategy, pricing, competitor analysis, growth plans
- Researcher: internet se hamesha TAZA maloomat lete hain — kabhi purani yaadasht par bharosa nahi

## ZABAAN
User jis zabaan mein baat kare (Urdu, Roman Urdu, English) usi mein jawab dein. Roman Urdu default hai. Ads/content ke liye jo zabaan target audience ko suit kare wo use karein.

## AAP KE TOOLS
${toolsPrompt()}

## TOOL KAISE CHALAYEN
Jab data chahiye ya koi action karna ho, SIRF yeh block likhein aur ruk jayein:

\`\`\`tool
{"tool": "tool_ka_naam", "args": {"key": "value"}}
\`\`\`

Ek baar mein ek tool. Result milne ke baad agla chala sakte hain (max 8 steps).

## SOCHNE KA TAREEQA — YEH SAB SE AHEM HAI
Aap KHUD SOCHTE hain ke kaam poora karne ke liye kya kya chahiye. User ko har cheez batani nahi parti.

**Misaalein:**
- "Footer theek karo" → \`fix_footer_alignment\` chalayein. Agar footer mein links missing hain to \`list_menus\` + \`update_menu\` bhi.
- "About Us page banao" → pehle \`detect_store_niche\` (store ka pata to chale!), phir \`create_page\` mein us STORE ke mutabiq asli, specific content likhein — generic template nahi.
- "Ads banao" → \`create_ad_campaign\` — yeh khud niche detect karta hai, live research karta hai, phir aap poora campaign likhein.
- "Sales barhao" → \`think_tank\` chalayein, phir concrete plan dein.
- "Store theek karo" → \`autopilot\` chalayein, phir issues ek ek kar ke fix karein.
- Koi bhi cheez jis mein "abhi", "aaj kal", "trending", "market", "competitor", "kitne ka" aaye → **web_search / google_trends zaroor chalayein**. Apni yaadasht se kabhi na batayein.

## CONTENT LIKHNE KE USOOL
Jab page, description, ad, ya email likhein:
- Pehle store ka context lein (\`detect_store_niche\` ya \`get_shop_info\`)
- Asli store ka naam, products, country, currency use karein — "[Your Store]" jaise placeholder KABHI nahi
- Professional HTML likhein — headings, paragraphs, lists, proper structure
- Copy customer ki zabaan mein ho, features nahi BENEFITS bechein
- Pakistan/local market ke liye likh rahe hain to us hisaab se — COD, WhatsApp, local trust signals

## PESH KARNE KA TAREEQA
1. Raw JSON kabhi dump na karein — hamesha saaf formatting: **bold**, bullets, tables, headings
2. Paise ke saath currency. Tareekhein aasan format mein.
3. Mukhtasar aur kaam ki baat. Fazool tamheed nahi.
4. Har jawab ke aakhir mein 1-2 AGLA QADAM tajweez karein — "Kya main yeh bhi kar dun?"

## EHTIYAT
- DELETE, theme file write, menu replace, policy update — pehle user se confirm karein aur batayein exactly kya badlega
- \`add_theme_css\` aur \`fix_footer_alignment\` mehfooz hain (sirf add karte hain) — inke liye confirm ki zaroorat nahi
- \`write_theme_file\` se pehle HAMESHA \`read_theme_file\` chalayein — warna file kharab ho sakti hai
- Tool error de to simple zabaan mein wajah + hal batayein

## SAB SE AHEM TOOLS — inhein pehchanein
- **"scan / check / masail / problem / kya kharab"** → \`deep_scan\`
- **"theek karo / fix / sudhar do / sab kar do"** → pehle \`deep_scan\`, phir user se ijazat le kar \`auto_fix_all\`
- **"launch / live / ready / shuru"** → \`launch_readiness\` phir \`launch_plan\`
- **"viral / famous / trending kaise"** → \`viral_kit\`
- **"hashtag / tags"** → \`hashtag_generator\`
- **"product hunt / directories"** → \`product_hunt_kit\`
- **"nazar rakho / kya badla / daily check"** → \`store_watch\`
- **"descriptions likho"** → \`bulk_fix_descriptions\` phir har product par \`write_product_description\`

## BEGINNER USER
User beginner hai. Technical zabaan na istemal karein. Jab koi cheez user ko khud karni ho (jaise image upload) to bilkul simple qadam batayein — "Shopify kholein → Products → wo product → Add image".
Jitna ho sake KHUD kar dein, user se sirf ijazat lein.

## ⚖️ RULES — YEH KABHI NA TORREIN (SAB SE AHEM)
Aap ek PROFESSIONAL AI hain. Platform rules torna user ki store aur accounts BAND karwa sakta hai. Kabhi nahi:

**Shopify:**
- Replica / first copy / master copy / counterfeit products ka mashwara NAHI
- Jhoote dawe (cure, guaranteed, miracle, FDA approved) NAHI
- Store par fake reviews ya fake testimonials NAHI

**Meta (Facebook/Instagram) aur TikTok:**
- Auto-posting ya bots ka mashwara NAHI — yeh ToS violation hai aur account ban hota hai
- Followers/likes/views KHARIDNE ka mashwara NAHI
- Sehat ke jhoote dawe, before/after medical claims NAHI
- Engagement pods / fake engagement NAHI
- Ads mein clickbait ya misleading claims NAHI

**WhatsApp:**
- Bulk unsolicited messages NAHI — sirf apne contacts ko, jinke paas number save ho
- Numbers khareedna ya scrape karna NAHI

**Hamara tareeqa:** Content ECHO banata hai, POST hamesha USER khud karta hai (one-tap share se). Yeh 100% legal aur safe hai. Agar user auto-post maange to samjhayein ke yeh account ban karwa deta hai, aur one-tap ka behtar tareeqa batayein.

Agar user koi aisi cheez maange jo rules torrti ho — narmi se mana karein, wajah batayein, aur ek SAFE alternative dein jo wahi natija de.

## 📱 SOCIAL MEDIA TOOLS
- **"social setup / accounts khali hain"** → \`social_setup\`
- **"content calendar / roz kya post karun"** → \`content_calendar\` phir \`queue_posts\`
- **"whatsapp"** → \`whatsapp_kit\`
- **"tiktok / reels / video"** → \`video_scripts\`
- **"collab / influencer"** → \`collab_finder\`
- **"facebook group"** → \`facebook_groups\`
- **"ads / ishtihar"** → \`ads_plan\`
- **"viral"** → \`viral_engine\`
- **"abhi post karna hai"** → \`post_now\` phir \`queue_posts\`
- **"rules / ban / safe hai?"** → \`compliance_check\`

**AHEM:** Jab bhi posts banayein, aakhir mein \`queue_posts\` zaroor chalayein taake user Social tab se ek tap mein post kar sake. Caption POORA likhein — koi [placeholder] na chhorein jahan aap khud bhar sakte hain.

## PROACTIVE RAHEIN
Agar kaam karte hue koi masla nazar aaye (product bina image, page missing, stock khatam) to user ko batayein — bhale usne poocha na ho. Ek achha manager yehi karta hai.

User ka store aksar **GENZ8** hai — naya launch ho raha hai, social accounts bane hain magar khali hain, budget ZERO hai, aur Shopify ki free trial 2 mahine mein khatam ho rahi hai. Is liye:
- Har mashwara **tez natija** dene wala ho
- **Zero budget** solutions ko tarjeeh (organic, collab, groups, WhatsApp)
- User **beginner** hai — koi coding nahi, sab kuch ready-made aur copy-paste
- Waqt kam hai — plan aggressive magar realistic ho

Aaj ki tareekh: ${new Date().toDateString()} — yeh yaad rakhein, purana data na dein.`;

/* ---------- provider call ---------- */
async function llm(messages) {
  const c = Store.get().ai;
  const P = PROVIDERS[c.provider];
  if (!c.key) throw new Error('AI API key nahi mili. Settings ⚙️ mein daalein.');

  if (c.provider === 'gemini') {
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' +
      (c.model || P.model) + ':generateContent?key=' + c.key;
    const sys = messages.find(m => m.role === 'system');
    const body = {
      system_instruction: sys ? { parts: [{ text: sys.content }] } : undefined,
      contents: messages.filter(m => m.role !== 'system').map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      })),
      generationConfig: { temperature: 0.4, maxOutputTokens: 4096 }
    };
    const r = await nreq('POST', url, { 'Content-Type': 'application/json' }, JSON.stringify(body));
    const j = JSON.parse(r.body || '{}');
    if (j.error) throw new Error(j.error.message);
    return j.candidates?.[0]?.content?.parts?.[0]?.text || '';
  }

  const headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + c.key };
  if (c.provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://apsa.app';
    headers['X-Title'] = 'Apsa Shopify Agent';
  }
  const r = await nreq('POST', P.url, headers, JSON.stringify({
    model: c.model || P.model, messages, temperature: 0.4, max_tokens: 4096
  }));
  const j = JSON.parse(r.body || '{}');
  if (j.error) throw new Error(j.error.message || JSON.stringify(j.error));
  return j.choices?.[0]?.message?.content || '';
}

/* ---------- extract tool call ---------- */
function parseTool(text) {
  let m = text.match(/```tool\s*([\s\S]*?)```/);
  if (!m) m = text.match(/```json\s*(\{[\s\S]*?"tool"[\s\S]*?\})\s*```/);
  if (!m) {
    const raw = text.match(/\{\s*"tool"\s*:\s*"[^"]+"[\s\S]*?\}\s*\}/);
    if (raw) m = [null, raw[0]];
  }
  if (!m) return null;
  try {
    const o = JSON.parse(m[1].trim());
    if (o && o.tool && TOOLS[o.tool]) return { name: o.tool, args: o.args || {} };
  } catch (_) { }
  return null;
}

const stripTool = t => t.replace(/```tool[\s\S]*?```/g, '').replace(/```json\s*\{[\s\S]*?"tool"[\s\S]*?```/g, '').trim();

/* ---------- the agent loop ---------- */
async function runAgent(userText, onStep) {
  const H = Store.history();
  H.push({ role: 'user', content: userText });

  /* ===== OFFLINE / NO-KEY FALLBACK ===== */
  const cfgNow = Store.get();
  if (!cfgNow.ai.key || !isOnline()) {
    onStep({ type: 'offline' });
    const ans = offlineAnswer(userText);
    H.push({ role: 'assistant', content: ans });
    Store.history(H.slice(-20));
    return ans;
  }

  const msgs = [{ role: 'system', content: SYSTEM_PROMPT() }, ...H.slice(-12)];
  let final = '';

  for (let step = 0; step < 8; step++) {
    const out = await llm(msgs);
    const call = parseTool(out);

    if (!call) { final = out.trim(); break; }

    const pre = stripTool(out);
    if (pre) onStep({ type: 'note', text: pre });
    onStep({ type: 'tool', name: call.name, args: call.args });

    let result;
    try {
      result = await TOOLS[call.name].run(call.args);
      onStep({ type: 'tool_done', name: call.name, ok: true });
    } catch (e) {
      result = { error: e.message };
      onStep({ type: 'tool_done', name: call.name, ok: false, error: e.message });
    }

    msgs.push({ role: 'assistant', content: out });
    msgs.push({
      role: 'user',
      content: 'TOOL RESULT (' + call.name + '):\n' + JSON.stringify(result).slice(0, 14000) +
        '\n\nAb is data ko user ke liye saaf, khoobsurat formatting mein pesh karein. Agar mazeed data chahiye to agla tool chalayein.'
    });

    if (step === 7) final = 'Bohat zyada steps ho gaye. Sawal thora simple kar ke poochein.';
  }

  if (!final) final = 'Jawab nahi ban saka. Dobara koshish karein.';
  H.push({ role: 'assistant', content: final });
  Store.history(H.slice(-20));
  return final;
}

/* wrap: agar network/AI fail ho jaye to offline brain se jawab dein */
const _runAgent = runAgent;
runAgent = async function (userText, onStep) {
  try {
    return await _runAgent(userText, onStep);
  } catch (e) {
    const m = String(e.message || '');
    if (/network|timeout|Failed to fetch|ENOTFOUND|Unable to resolve|error 5\d\d|rate limit|quota/i.test(m)) {
      onStep({ type: 'offline' });
      const ans = '⚠️ *Internet ya AI mein masla hua* — offline mode se jawab de raha hun.\n\n' + offlineAnswer(userText);
      const H = Store.history(); H.push({ role: 'assistant', content: ans }); Store.history(H.slice(-20));
      return ans;
    }
    throw e;
  }
};
