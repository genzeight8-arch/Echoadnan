/* ============================================================
   brain.js — ECHO OFFLINE BRAIN
   Bina internet aur bina AI key ke kaam karta hai.
   Rule-based intent engine + content generators + cached data.
   ============================================================ */

/* ---------- offline cache of store data ---------- */
const Cache = {
  put(key, val) {
    try {
      localStorage.setItem('echo_c_' + key, JSON.stringify({ t: Date.now(), v: val }));
    } catch (_) { }
  },
  get(key, maxAgeMs) {
    try {
      const o = JSON.parse(localStorage.getItem('echo_c_' + key) || 'null');
      if (!o) return null;
      if (maxAgeMs && Date.now() - o.t > maxAgeMs) return { stale: true, age: Date.now() - o.t, v: o.v };
      return { stale: false, age: Date.now() - o.t, v: o.v };
    } catch { return null; }
  },
  ago(ms) {
    const m = Math.round(ms / 60000);
    if (m < 1) return 'abhi';
    if (m < 60) return m + ' minute pehle';
    const h = Math.round(m / 60);
    if (h < 24) return h + ' ghante pehle';
    return Math.round(h / 24) + ' din pehle';
  }
};

/* online detection */
const isOnline = () => (typeof navigator === 'undefined') ? true : navigator.onLine !== false;

/* ============================================================
   OFFLINE CONTENT GENERATORS
   Store ka naam/niche le kar professional content banate hain.
   ============================================================ */

function ctxOf() {
  const c = Cache.get('niche');
  const s = Cache.get('shop');
  const n = c?.v || {};
  const sh = s?.v || {};
  const cat = (n.categories?.[0] || '').replace(/\s*\(\d+\)/, '') || 'products';
  return {
    name: sh.name || n.store || 'GENZ8',
    domain: sh.domain || Store.get().shop.domain || '',
    email: sh.email || '',
    country: sh.country || n.country || 'Pakistan',
    currency: sh.currency || n.currency || 'PKR',
    city: sh.city || '',
    category: cat,
    products: n.total_products || 0,
    priceBand: n.price_band || null,
    samples: n.sample_products || []
  };
}

const GEN = {

  about(x) {
    const c = x || ctxOf();
    return `<h2>${c.name} — Hamari Kahani</h2>
<p><strong>${c.name}</strong> ka safar ek simple soch se shuru hua: ${c.country} ke logon tak <strong>asli, mayaari ${c.category}</strong> pohanchana — wo bhi munasib qeemat par, bina kisi jhanjhat ke.</p>

<h3>Hum kyun mukhtalif hain</h3>
<ul>
  <li><strong>Mayaar par koi samjhauta nahi</strong> — har product hamari team khud check karti hai.</li>
  <li><strong>Imandarana qeematein</strong> — koi chhupi hui fees nahi. Jo dikhta hai wahi milta hai.</li>
  <li><strong>Tez delivery</strong> — poore ${c.country} mein aap ke darwaze tak.</li>
  <li><strong>Asli customer support</strong> — robot nahi, asli insaan jawab dete hain.</li>
</ul>

<h3>Hamara Waada</h3>
<p>Hum sirf saman nahi bechte — hum <em>bharosa</em> banate hain. Agar aap ko koi product pasand na aaye, hum se raabta karein. Aap ki khushi hamari sab se bari kamyabi hai.</p>

<h3>Hum se juriye</h3>
<p>Sawal, tajweez, ya sirf salam — hum hamesha sunne ke liye maujood hain.${c.email ? ' Email: <strong>' + c.email + '</strong>' : ''}</p>

<p><strong>Shukriya ke aap ne ${c.name} ko chuna.</strong> 💚</p>`;
  },

  contact(x) {
    const c = x || ctxOf();
    return `<h2>Hum se Raabta Karein</h2>
<p>Aap ka har sawal hamare liye ahem hai. Hum <strong>24 ghanton</strong> ke andar jawab dete hain.</p>

<h3>📧 Email</h3>
<p>${c.email || 'support@' + (c.domain || 'yourstore.com')}<br>
<small>Orders, refunds, ya kisi bhi masle ke liye</small></p>

<h3>💬 WhatsApp</h3>
<p>Sab se tez jawab WhatsApp par milta hai. Apna <strong>order number</strong> zaroor likhein.</p>

<h3>🕐 Kaam ke Auqaat</h3>
<ul>
  <li>Peer – Hafta: subah 9 baje – shaam 8 baje</li>
  <li>Itwar: bandh</li>
</ul>

<h3>📦 Order ke bare mein?</h3>
<p>Apna order number (jaise <strong>#1001</strong>) aur registered email/phone bhejein — hum foran status bata denge.</p>

<h3>🤝 Business / Wholesale</h3>
<p>Bulk order ya partnership ke liye hum se raabta karein — special rates available hain.</p>

${c.city ? '<h3>📍 Location</h3><p>' + c.city + ', ' + c.country + '</p>' : ''}

<p><em>Hum har message parhte hain aur jawab dete hain. Aap akele nahi hain.</em></p>`;
  },

  faq(x) {
    const c = x || ctxOf();
    const cur = c.currency;
    const qa = [
      ['Order kaise karun?', 'Product select karein → "Add to Cart" → "Checkout" → apna naam, address aur phone likhein → order confirm. Bas! Aap ko email/SMS par tasdeeq mil jayegi.'],
      ['Delivery mein kitne din lagte hain?', 'Bare shehron mein <strong>2-4 kaam ke din</strong>, chhote shehron mein <strong>4-7 din</strong>. Order ship hote hi aap ko tracking number mil jata hai.'],
      ['Cash on Delivery (COD) hai?', 'Ji haan! Aap saman haath mein le kar paise de sakte hain. Advance payment par aksar extra discount bhi milta hai.'],
      ['Delivery charges kitne hain?', 'Checkout par exact charges dikh jate hain. Ek certain amount se upar order par <strong>delivery free</strong> hoti hai.'],
      ['Saman asli hai?', 'Bilkul. Har product hamari team check karti hai. Agar kisi cheez mein masla ho to hum wapas lete hain — bina bahas ke.'],
      ['Return ya exchange kar sakta hun?', 'Ji haan — saman milne ke <strong>7 din</strong> ke andar, agar product istemal na kiya gaya ho aur original packing mein ho. Hum se raabta karein.'],
      ['Refund kab tak milta hai?', 'Product wapas milne ke baad <strong>3-5 kaam ke din</strong> mein refund process ho jata hai.'],
      ['Order track kaise karun?', 'Aap ko email/SMS par tracking link milta hai. Ya hamein order number bhejein — hum bata denge.'],
      ['Order cancel kar sakta hun?', 'Ji haan, jab tak order ship na hua ho. Foran hum se raabta karein.'],
      ['Ghalat ya toota hua saman aaya?', 'Bohat afsos! Unboxing ki tasveer/video bhejein — hum foran replacement ya poora refund denge.'],
      ['Payment ke tareeqe kaunse hain?', 'COD, bank transfer, aur online card payment — sab available hain.'],
      ['Size ya rang ka masla?', 'Har product page par tafseel di gayi hai. Confusion ho to message karein — hum sahi mashwara denge.']
    ];
    return `<h2>Aksar Poochay Janay Walay Sawalat</h2>
<p>Jo cheez yahan na mile, hum se poochein — hum khushi se batayenge.</p>
${qa.map(([q, a]) => `<h3>${q}</h3>\n<p>${a}</p>`).join('\n')}
<hr>
<p><strong>Koi aur sawal?</strong> Contact page se hum se raabta karein — 24 ghanton mein jawab milega.</p>`;
  },

  shipping(x) {
    const c = x || ctxOf();
    return `<h2>Shipping Policy</h2>
<h3>Order Processing</h3>
<p>Order confirm hone ke baad <strong>1-2 kaam ke din</strong> mein pack aur dispatch kar diya jata hai. Itwar aur chhutti wale din process nahi hota.</p>

<h3>Delivery ka Waqt</h3>
<ul>
  <li><strong>Bare shehr:</strong> 2-4 kaam ke din</li>
  <li><strong>Chhote shehr / qasbe:</strong> 4-7 kaam ke din</li>
  <li><strong>Door daraz ilaqe:</strong> 7-10 kaam ke din</li>
</ul>

<h3>Shipping Charges</h3>
<p>Checkout par aap ke address ke hisaab se exact charges dikh jate hain. Ek minimum amount se upar order par <strong>delivery bilkul free</strong> hai.</p>

<h3>Order Tracking</h3>
<p>Jaise hi order ship hota hai, aap ko email aur SMS par <strong>tracking number</strong> bhej diya jata hai.</p>

<h3>Cash on Delivery</h3>
<p>COD poore ${c.country} mein available hai. Rider ko saman lete waqt paise dein.</p>

<h3>Der ho jaye to?</h3>
<p>Kabhi kabhi mausam ya courier ki wajah se der ho sakti hai. Aisi soorat mein hum se raabta karein — hum courier se follow up kar ke aap ko update denge.</p>

<h3>Ghalat Address</h3>
<p>Baraye meherbani address aur phone number theek se likhein. Ghalat maloomat ki wajah se order wapas aa jaye to dobara bhejne ka charge lag sakta hai.</p>`;
  },

  refund(x) {
    return `<h2>Return aur Refund Policy</h2>
<p>Hum chahte hain ke aap poori tarah mutmain hon. Agar kuch theek na lage, hum theek karenge.</p>

<h3>Return ki Muddat</h3>
<p>Saman milne ke <strong>7 din</strong> ke andar return kiya ja sakta hai.</p>

<h3>Shartein</h3>
<ul>
  <li>Product istemal na kiya gaya ho</li>
  <li>Original packing, tags aur accessories mojood hon</li>
  <li>Order ka saboot (order number ya receipt) ho</li>
</ul>

<h3>Kya return nahi ho sakta</h3>
<ul>
  <li>Sale / clearance items (jab tak kharab na hon)</li>
  <li>Personal care ya hygiene products jo khol diye gaye hon</li>
  <li>Custom ya personalised items</li>
</ul>

<h3>Kharab ya Ghalat Saman</h3>
<p>Agar product tota hua, kharab, ya ghalat aaya hai — <strong>48 ghanton</strong> ke andar tasveer/video ke saath raabta karein. Hum poora refund ya free replacement denge, aur return shipping bhi hum bhugtenge.</p>

<h3>Refund ka Tareeqa</h3>
<ol>
  <li>Hum se raabta karein aur wajah batayein</li>
  <li>Hum return ka tareeqa batayenge</li>
  <li>Saman wapas milne par hum check karenge</li>
  <li><strong>3-5 kaam ke din</strong> mein refund aap ke account/bank mein</li>
</ol>

<h3>Exchange</h3>
<p>Size ya rang badalna ho to raabta karein — stock ke mutabiq hum exchange kar denge.</p>

<h3>Order Cancel</h3>
<p>Ship hone se pehle order cancel karwa sakte hain — poora refund milega.</p>`;
  },

  privacy(x) {
    const c = x || ctxOf();
    return `<h2>Privacy Policy</h2>
<p>${c.name} par hum aap ki maloomat ki hifazat ko sanjeeda leta hai. Yeh policy batati hai ke hum kya data lete hain aur kyun.</p>

<h3>Hum kya maloomat lete hain</h3>
<ul>
  <li><strong>Order ke liye:</strong> naam, email, phone, delivery address</li>
  <li><strong>Payment:</strong> payment secure gateway ke zariye hota hai — hum aap ke card ki tafseel <em>save nahi karte</em></li>
  <li><strong>Website use:</strong> browser, device aur kaunse page dekhe (behtari ke liye)</li>
</ul>

<h3>Is ka istemal kis liye</h3>
<ul>
  <li>Aap ka order process aur deliver karne ke liye</li>
  <li>Order ka update aur support dene ke liye</li>
  <li>Website behtar banane ke liye</li>
  <li>Aap ki ijazat se offers bhejne ke liye (kabhi bhi unsubscribe kar sakte hain)</li>
</ul>

<h3>Hum data bechte nahi</h3>
<p>Hum aap ki zaati maloomat kabhi kisi ko <strong>bechte ya kiraye par nahi dete</strong>. Sirf courier aur payment partner ko utni maloomat jati hai jitni order poora karne ke liye zaroori ho.</p>

<h3>Hifazat</h3>
<p>Hamari website SSL encryption istemal karti hai. Aap ka data mehfooz servers par rakha jata hai.</p>

<h3>Cookies</h3>
<p>Cart yaad rakhne aur experience behtar banane ke liye cookies istemal hoti hain. Aap browser se inhein band kar sakte hain.</p>

<h3>Aap ke Huqooq</h3>
<p>Aap kabhi bhi apna data dekhne, theek karwane, ya delete karwane ki darkhwast kar sakte hain — bas hum se raabta karein.</p>

<h3>Sawalat</h3>
<p>Privacy se mutalliq kisi bhi sawal ke liye${c.email ? ' <strong>' + c.email + '</strong> par' : ''} raabta karein.</p>`;
  },

  terms(x) {
    const c = x || ctxOf();
    return `<h2>Terms of Service</h2>
<p>${c.name} istemal kar ke aap in shartein se ittefaq karte hain.</p>

<h3>1. Website ka Istemal</h3>
<p>Yeh website sirf jaiz maqasid ke liye hai. Aap ki umar 18 saal se zyada honi chahiye ya walidain ki ijazat honi chahiye.</p>

<h3>2. Products aur Qeematein</h3>
<p>Hum products ki durust tafseel dene ki poori koshish karte hain. Rang screen ke mutabiq thora mukhtalif lag sakta hai. Qeematein bina ittila badal sakti hain, magar order confirm hone ke baad wahi qeemat lagoo hoti hai.</p>

<h3>3. Orders</h3>
<p>Hum kisi bhi order ko cancel karne ka haq rakhte hain (jaise stock khatam ho ya maloomat ghalat ho). Aisi soorat mein poora refund diya jayega.</p>

<h3>4. Payment</h3>
<p>COD, bank transfer aur online payment available hain. Online payment secure gateway se hoti hai.</p>

<h3>5. Shipping</h3>
<p>Delivery ka waqt andazan hai. Courier ki der par hamara ikhtiyar mehdood hai, magar hum poori madad karte hain.</p>

<h3>6. Returns</h3>
<p>Return Policy alag se diya gaya hai aur unhi shartein ke tehat return qabool hota hai.</p>

<h3>7. Milkiyat</h3>
<p>Website ka content, tasveerein aur logo ${c.name} ki milkiyat hain. Bina ijazat istemal nahi kiya ja sakta.</p>

<h3>8. Zimmedari</h3>
<p>Hamari zimmedari order ki qeemat tak mehdood hai.</p>

<h3>9. Tabdeeli</h3>
<p>Hum yeh shartein kabhi bhi update kar sakte hain. Nayi shartein website par lagte hi lagoo ho jati hain.</p>

<h3>10. Raabta</h3>
<p>Kisi bhi sawal ke liye Contact page se hum se raabta karein.</p>`;
  },

  /* ---------- product description ---------- */
  productDesc(title, price, currency, category) {
    const t = title || 'Product';
    return `<h2>${t}</h2>
<p><strong>${t}</strong> — mayaar aur qeemat ka behtareen sangam. Rozana ke istemal ke liye banaya gaya, taake aap ko har baar bharosa mile.</p>

<h3>✨ Khaas Baatein</h3>
<ul>
  <li><strong>Behtareen mayaar</strong> — chuni hui material se tayar</li>
  <li><strong>Payedar</strong> — lambe arse tak sath dene wala</li>
  <li><strong>Aasan istemal</strong> — koi jhanjhat nahi</li>
  <li><strong>Munasib qeemat</strong> — bazaar se behtar rate</li>
</ul>

<h3>📦 Aap ko kya milega</h3>
<ul>
  <li>1 x ${t}</li>
  <li>Mehfooz packing</li>
  <li>Mayaar ki zamanat</li>
</ul>

<h3>🚚 Delivery aur Wapsi</h3>
<ul>
  <li>Poore mulk mein tez delivery</li>
  <li>Cash on Delivery available</li>
  <li>7 din ki aasan return policy</li>
</ul>

<h3>❓ Sawal?</h3>
<p>Order karne se pehle koi confusion ho to hum se raabta karein — hum sahi mashwara denge.</p>

<p><em>Stock mehdood hai — abhi order karein.</em></p>`;
  },

  /* ---------- hashtags ---------- */
  hashtags(category, country) {
    const cat = String(category || 'shopping').toLowerCase().replace(/[^a-z0-9 ]/g, '').trim();
    const w = cat.split(/\s+/).filter(Boolean);
    const cc = (country || 'Pakistan').toLowerCase().replace(/\s+/g, '');
    const camel = s => s.split(' ').map(x => x.charAt(0).toUpperCase() + x.slice(1)).join('');

    const niche = [
      '#' + w.join(''), '#' + camel(cat), '#' + w.join('') + 'lover',
      '#' + w.join('') + 'style', '#best' + w.join(''), '#' + w.join('') + 'shop',
      '#' + w.join('') + 'online', '#new' + w.join('')
    ];
    const local = [
      '#' + cc, '#' + cc + 'business', '#' + cc + 'shopping', '#madein' + cc,
      '#online' + cc, '#karachi', '#lahore', '#islamabad', '#multan',
      '#' + w.join('') + cc, '#shop' + cc
    ];
    const broad = [
      '#onlineshopping', '#shoppingonline', '#smallbusiness', '#supportsmallbusiness',
      '#shopsmall', '#onlinestore', '#ecommerce', '#shopnow', '#newarrival',
      '#trending', '#musthave', '#dailydeals', '#bestprice', '#freedelivery',
      '#cashondelivery', '#instashop', '#shoppingaddict', '#deals'
    ];
    const engage = [
      '#explore', '#explorepage', '#fyp', '#foryou', '#viral', '#trendingnow',
      '#reels', '#instagood', '#instadaily', '#followforfollow'
    ];
    const buyer = [
      '#buynow', '#orderonline', '#limitedstock', '#sale', '#discount',
      '#offer', '#giftideas', '#unboxing'
    ];
    const clean = a => [...new Set(a.map(x => x.replace(/[^#a-z0-9]/gi, '').toLowerCase()))].filter(x => x.length > 3);
    return {
      niche: clean(niche), local: clean(local), broad: clean(broad),
      engagement: clean(engage), buyer_intent: clean(buyer),
      instagram_set: clean([...niche.slice(0, 6), ...local.slice(0, 6), ...broad.slice(0, 9), ...engage.slice(0, 5), ...buyer.slice(0, 4)]).slice(0, 30),
      tiktok_set: clean([...engage.slice(0, 4), ...niche.slice(0, 3), ...local.slice(0, 2), ...broad.slice(0, 3)]).slice(0, 8),
      tip: 'Instagram: 25-30 tags. TikTok: 5-8. Har post par mix badlein — same set repeat karne se reach girti hai.'
    };
  },

  /* ---------- ad copy templates ---------- */
  adCopy(product, price, currency, category) {
    const p = product || 'hamara product';
    const pr = price ? currency + ' ' + price : '';
    return [
      {
        angle: 'Problem → Solution',
        hook: 'Kya aap bhi ' + (category || 'is masle') + ' se pareshan hain? 😩',
        body: `Hum ne wahi masla hal kiya hai.\n\n${p} — jo waqai kaam karta hai.\n\n✅ Behtareen mayaar\n✅ ${pr ? 'Sirf ' + pr : 'Munasib qeemat'}\n✅ Cash on Delivery\n✅ Poore mulk mein delivery\n\nAaj hi order karein — stock mehdood hai.`,
        headline: p + (pr ? ' — ' + pr : ''),
        cta: 'Shop Now'
      },
      {
        angle: 'Social Proof',
        hook: '1000+ khush customers ne yeh khareeda ⭐⭐⭐⭐⭐',
        body: `Log baar baar ${p} kyun mangwa rahe hain?\n\n"Mayaar bohat achha hai, delivery bhi tez thi" — Ayesha, Lahore\n\n💚 Asli mayaar\n💚 Bharosemand seller\n💚 7 din return policy\n\n${pr ? 'Sirf ' + pr + ' mein. ' : ''}Aap bhi try karein.`,
        headline: 'Sab ka pasandeeda — ' + p,
        cta: 'Order Now'
      },
      {
        angle: 'Urgency / Offer',
        hook: '⚡ Sirf aaj ke liye — stock khatam hone wala hai!',
        body: `${p} par special offer.\n\n${pr ? '🔥 Ab sirf ' + pr : '🔥 Special discount'}\n🚚 Free delivery\n💵 Cash on Delivery\n↩️ 7 din wapsi ki suhulat\n\nJaldi karein — pichli baar 2 din mein stock khatam ho gaya tha.`,
        headline: 'Limited Stock — ' + p,
        cta: 'Buy Now'
      },
      {
        angle: 'Curiosity',
        hook: 'Yeh ek cheez jo har ghar mein honi chahiye 👀',
        body: `Zyada tar log nahi jante ke ${p} ka kitna faida hai.\n\nEk baar istemal karne ke baad aap sochenge — "pehle kyun nahi liya?"\n\n${pr ? '👉 ' + pr : '👉 Munasib qeemat'}\n👉 COD available\n👉 Tez delivery\n\nKhud dekh lein.`,
        headline: 'Aap ne yeh try kiya?',
        cta: 'Learn More'
      },
      {
        angle: 'Before / After',
        hook: 'Pehle: pareshani 😖 → Baad mein: sukoon 😍',
        body: `${p} ne bohat logon ki rozmarra zindagi aasan bana di.\n\nFarq khud dekhein:\n❌ Pehle — waqt aur paisa zaya\n✅ Ab — aasan, tez, bharosemand\n\n${pr ? 'Sirf ' + pr + '. ' : ''}Cash on Delivery.\nAaj order karein, ${'2-4'} din mein aap ke paas.`,
        headline: 'Farq khud mehsoos karein',
        cta: 'Shop Now'
      }
    ];
  }
};

/* ============================================================
   OFFLINE INTENT ROUTER
   Bina AI ke sawal samajh kar jawab deta hai.
   ============================================================ */

const INTENTS = [
  { id: 'greet', re: /^(salam|assalam|hi|hello|hey|aoa|السلام)/i },
  { id: 'help', re: /(kya kar sakt|what can you|madad|help|kaise use|how to use)/i },
  { id: 'audit', re: /(audit|scan|check store|store check|problem|masail|masla|kya kharab|gaps)/i },
  { id: 'autofix', re: /(auto ?fix|theek kar|fix kar|sudhar|repair|correct)/i },
  { id: 'footer', re: /(footer)/i },
  { id: 'about', re: /(about us|about page|hamari kahani)/i },
  { id: 'contact', re: /(contact page|contact us|raabta page)/i },
  { id: 'faq', re: /(faq|sawal.*jawab|questions page)/i },
  { id: 'policy', r: 1, re: /(polic|shipping policy|refund|return policy|privacy|terms)/i },
  { id: 'pages', re: /(pages? bana|essential pages|missing pages|zaroori pages)/i },
  { id: 'launch', re: /(launch|live kar|shuru kar|start store|open store|ready)/i },
  { id: 'hashtag', re: /(hashtag|#|tags)/i },
  { id: 'whatsapp', re: /(whatsapp|wa |status message|broadcast)/i },
  { id: 'tiktok', re: /(tiktok|reel|video script|short video)/i },
  { id: 'collab', re: /(collab|influencer|creator|barter)/i },
  { id: 'fbgroup', re: /(facebook group|group post|marketplace)/i },
  { id: 'calendar', re: /(calendar|roz kya post|posting schedule|30 din|daily post)/i },
  { id: 'socialsetup', re: /(social.*setup|account.*khali|bio |profile bana|accounts bana)/i },
  { id: 'rules', re: /(rule|ban|safe hai|violate|policy tor|compliance)/i },
  { id: 'viral', re: /(viral|trending kaise|famous|mashhoor)/i },
  { id: 'ads', re: /(ad |ads|ishtihar|facebook ad|tiktok|campaign|marketing)/i },
  { id: 'grow', re: /(barha|grow|zyada order|business|double|kaise bech|profit barha|scale)/i },
  { id: 'desc', re: /(description|tafseel likh)/i },
  { id: 'briefing', re: /(briefing|daily check|subah)/i },
  { id: 'orders', re: /(order|orders)/i },
  { id: 'products', re: /(product|products|saman)/i },
  { id: 'stock', re: /(stock|inventory|khatam)/i },
  { id: 'sales', re: /(sales|revenue|kamai|report|kitna kamaya)/i }
];

function detectIntent(text) {
  const t = String(text || '').toLowerCase().trim();
  for (const i of INTENTS) if (i.re.test(t)) return i.id;
  return null;
}

/* offline responses */
function offlineAnswer(text) {
  const intent = detectIntent(text);
  const c = ctxOf();
  const on = isOnline();
  const shopReady = Shop.ok();
  const hdr = '📴 **Offline Mode** — AI key ya internet ke baghair chal raha hun. Jo kaam bina internet ho sakta hai wo kar deta hun.\n\n';

  const cached = k => {
    const o = Cache.get(k);
    return o ? { data: o.v, when: Cache.ago(o.age) } : null;
  };

  switch (intent) {
    case 'greet':
      return `**Assalam-o-Alaikum!** 👋 Main **ECHO** hun.\n\n${on ? '' : '📴 Abhi offline hun, magar phir bhi bohat kuch kar sakta hun:\n\n'}` +
        `• 📄 Pages ka content banana (About, Contact, FAQ, policies)\n` +
        `• #️⃣ Hashtags banana\n` +
        `• 📢 Ad copy templates\n` +
        `• 📝 Product descriptions\n` +
        `• 📊 Purana store data dekhna\n\n` +
        `Internet aur AI key ke saath main **poori store khud sambhalta hun**. Niche 🚀 **Grow** tab dekhein.`;

    case 'help':
      return `**ECHO kya kar sakta hai:**\n\n` +
        `**🩺 Store sambhalna**\nDeep scan, masail dhoondna, khud theek karna, hamesha nazar rakhna\n\n` +
        `**📄 Content**\nAbout Us, Contact, FAQ, saari policies, product descriptions\n\n` +
        `**🎨 Design**\nFooter align, CSS fix, theme sudharna\n\n` +
        `**📢 Marketing**\nFacebook/TikTok/Google ads, email campaigns, hashtags\n\n` +
        `**📱 Social Media**\nWhatsApp kit, TikTok scripts, content calendar, collab plans, FB groups\n\n` +
        `**🚀 Launch**\nLaunch checklist, viral plan, Product Hunt, growth strategy\n\n` +
        `**🧠 Strategy**\nSales barhane ka plan, pricing, competitor analysis, SEO\n\n` +
        `Sab se aasan tareeqa: 🚀 **Grow** tab kholein aur kisi bhi button par tap karein.`;

    case 'about':
      return hdr + `Yeh raha **About Us** ka content — ${c.name} ke liye:\n\n---\n\n` + htmlToText(GEN.about(c)) +
        `\n\n---\n\n💡 Internet aane par kahein *"About Us page banao"* — main khud publish kar dunga.`;

    case 'contact':
      return hdr + `Yeh raha **Contact Us** ka content:\n\n---\n\n` + htmlToText(GEN.contact(c)) +
        `\n\n---\n\n💡 Online hone par main yeh khud page bana kar publish kar dunga.`;

    case 'faq':
      return hdr + `Yeh rahi **FAQ**:\n\n---\n\n` + htmlToText(GEN.faq(c)) +
        `\n\n---\n\n💡 Online hone par khud publish kar dunga.`;

    case 'policy': {
      const t = String(text).toLowerCase();
      let which = 'refund', body = GEN.refund(c);
      if (/ship/.test(t)) { which = 'Shipping'; body = GEN.shipping(c); }
      else if (/privacy/.test(t)) { which = 'Privacy'; body = GEN.privacy(c); }
      else if (/terms/.test(t)) { which = 'Terms of Service'; body = GEN.terms(c); }
      else which = 'Return & Refund';
      return hdr + `**${which} Policy**:\n\n---\n\n` + htmlToText(body) +
        `\n\n---\n\n💡 Online hone par kahein *"policies set karo"* — main saari 4 policies khud laga dunga.`;
    }

    case 'hashtag': {
      const h = GEN.hashtags(c.category, c.country);
      return `#️⃣ **${c.category}** ke liye hashtags${on ? '' : ' (offline)'}\n\n` +
        `**📸 Instagram (copy paste karein):**\n\`\`\`\n${h.instagram_set.join(' ')}\n\`\`\`\n\n` +
        `**🎵 TikTok:**\n\`\`\`\n${h.tiktok_set.join(' ')}\n\`\`\`\n\n` +
        `**Categories:**\n` +
        `• **Niche:** ${h.niche.join(' ')}\n` +
        `• **Local:** ${h.local.slice(0, 8).join(' ')}\n` +
        `• **Buyer intent:** ${h.buyer_intent.join(' ')}\n\n` +
        `💡 ${h.tip}`;
    }

    case 'ads': {
      const ads = GEN.adCopy(c.samples[0], null, c.currency, c.category);
      return hdr + `📢 **5 Ready Ad Copies** — copy kar ke chala dein:\n\n` +
        ads.map((a, i) => `---\n\n**${i + 1}. ${a.angle}**\n\n**Hook:** ${a.hook}\n\n**Body:**\n${a.body}\n\n**Headline:** ${a.headline}\n**CTA:** ${a.cta}`).join('\n\n') +
        `\n\n---\n\n💡 Internet + AI key ke saath main **live research** kar ke aap ke asli product par custom campaign banata hun — targeting aur budget plan ke saath.`;
    }

    case 'desc':
      return hdr + `📝 **Product description template**:\n\n---\n\n` +
        htmlToText(GEN.productDesc(c.samples[0] || 'Aap ka Product', null, c.currency, c.category)) +
        `\n\n---\n\n💡 Online hone par main aap ke har product ki apni description likh kar khud lagata hun.`;

    case 'whatsapp': {
      const t = PACKS.whatsapp(c.name, c.category, c.currency);
      return hdr + `💬 **WhatsApp Kit — ${c.name}**\n\n` +
        `**1. Launch message (doston ko personally)**\n\`\`\`\n${t.launch_personal}\n\`\`\`\n\n` +
        `**2. Status — launch**\n\`\`\`\n${t.status_launch}\n\`\`\`\n\n` +
        `**3. Status — product**\n\`\`\`\n${t.status_product}\n\`\`\`\n\n` +
        `**4. Status — offer**\n\`\`\`\n${t.status_offer}\n\`\`\`\n\n` +
        `**5. Order confirm**\n\`\`\`\n${t.order_confirm}\n\`\`\`\n\n` +
        `**6. Cart recovery**\n\`\`\`\n${t.abandoned_cart}\n\`\`\`\n\n` +
        `💡 **Rozana 2-3 status** — subah 9-11, raat 8-11. Sab se sasta marketing hai.\n` +
        `📱 **Social tab** se ek tap mein WhatsApp par bhej sakte hain.`;
    }

    case 'tiktok': {
      const vs = PACKS.videoScripts(c.name, c.category);
      const t = GEN.hashtags(c.category, c.country);
      return hdr + `🎬 **Video Scripts — TikTok / Reels**\n\n` +
        vs.map((v, i) => `---\n\n**${i + 1}. ${v.title}** · ${v.len}\n\n` +
          v.shots.map(x => '• ' + x).join('\n') +
          `\n\n**Caption:**\n${v.caption}\n\n**Audio:** ${v.audio}`).join('\n\n') +
        `\n\n---\n\n**Hashtags:**\n\`\`\`\n${t.tiktok_set.join(' ')}\n\`\`\`\n\n` +
        `💡 TikTok par 0 followers se bhi viral ho sakte hain — zero budget ka sab se bara hathiyar.`;
    }

    case 'collab': {
      const cb = PACKS.collab(c.name, c.category);
      return hdr + `🤝 **Collab Plan — bina paise ke**\n\n` +
        `**Creators kahan dhoondein:**\n` + cb.finding.map(x => '• ' + x).join('\n') +
        `\n\n**DM Template:**\n\`\`\`\n${cb.dm_template}\n\`\`\`\n\n` +
        `**Follow-up (3 din baad):**\n\`\`\`\n${cb.followup}\n\`\`\`\n\n` +
        `**Jab haan kahein:**\n\`\`\`\n${cb.barter}\n\`\`\`\n\n` +
        `**Content aane ke baad:**\n\`\`\`\n${cb.after}\n\`\`\`\n\n` +
        `💡 **1k-10k followers** wale micro creators best hain — engagement 5-10%, aur free product par maan jate hain. 20 DM bhejein, 3-5 haan kahenge.`;
    }

    case 'fbgroup': {
      const g = PACKS.groups(c.name, c.category, c.city);
      return hdr + `📘 **Facebook Groups — free orders**\n\n` +
        `**Tareeqa:**\n` + g.how.map(x => '• ' + x).join('\n') +
        `\n\n**Intro post:**\n\`\`\`\n${g.intro_post}\n\`\`\`\n\n` +
        `**Product post:**\n\`\`\`\n${g.product_post}\n\`\`\`\n\n` +
        `**Value post (best — spam nahi lagta):**\n\`\`\`\n${g.value_post}\n\`\`\`\n\n` +
        `💡 **Facebook Marketplace** bhi zaroor — bilkul free aur Pakistan mein bohat chalta hai.`;
    }

    case 'calendar': {
      const cal = PACKS.calendar(c.name, c.category, c.country);
      return hdr + `📅 **30-Din Content Calendar — ${c.name}**\n\n` +
        cal.slice(0, 30).map(x => `**Din ${x.d}** · ${(PLATFORMS[x.p]?.icon || '📱')} ${x.p === 'all' ? 'Sab jagah' : (PLATFORMS[x.p]?.name || x.p)} · *${x.t}*\n"${x.hook}"\n→ ${x.note}`).join('\n\n') +
        `\n\n---\n💡 Online hone par kahein **"content calendar banao"** — main har din ka POORA caption likh kar Social tab ke queue mein daal dunga, phir aap ek tap se post karte jayenge.`;
    }

    case 'socialsetup':
      return hdr + `🆕 **Social Accounts Setup — ${c.name}**\n\n` +
        `**📸 Instagram bio:**\n\`\`\`\n${c.name} 🛍️\n${c.category} | ${c.country}\n✅ Cash on Delivery\n🚚 Poore mulk mein delivery\n👇 Order karein\n\`\`\`\n\n` +
        `**🎵 TikTok bio:**\n\`\`\`\n${c.name} | ${c.category}\nCOD available 📦\nLink 👇\n\`\`\`\n\n` +
        `**📘 Facebook page:** Category "Shopping & Retail", About mein wahi bio + WhatsApp number\n\n` +
        `**💬 WhatsApp Business:** app install karein → catalog banayein → greeting message on\n\n` +
        `**Pehle 9 posts ka grid (Instagram):**\n` +
        `1. Store intro/logo · 2. Product · 3. Behind scenes\n4. Product · 5. Offer/discount · 6. Product\n7. Customer review · 8. Product · 9. Team/kahani\n\n` +
        `💡 Sab jagah **same username** rakhein — dhoondna aasan hota hai.`;

    case 'rules':
      return `⚖️ **Rules — main hamesha safe rehta hun**\n\n` +
        `**Jo main KABHI nahi karta:**\n` +
        `❌ Auto-posting (yeh Meta/TikTok ToS violation hai — account ban ho jata hai)\n` +
        `❌ Followers/likes kharidna\n` +
        `❌ Fake reviews\n` +
        `❌ Bots ya engagement pods\n` +
        `❌ Jhoote dawe (cure, guaranteed, miracle)\n` +
        `❌ Replica / first copy products\n` +
        `❌ Bulk unsolicited WhatsApp\n\n` +
        `**Mera tareeqa:**\n` +
        `✅ Main content banata hun → **aap ek tap se post karte hain**\n` +
        `✅ Yeh 100% legal hai, koi ban ka khatra nahi\n` +
        `✅ Sirf 10 second lagte hain per post\n\n` +
        `Is tarah aapki store aur accounts hamesha mehfooz rehte hain. 🛡️`;

    case 'launch':
      return hdr + launchChecklistText(c);

    case 'viral':
      return hdr + viralPlanText(c);

    case 'audit':
    case 'autofix': {
      const a = cached('audit');
      if (!a) return hdr + `Store ka data abhi cache mein nahi hai.\n\n**Internet on karein** aur *"Store ka audit karo"* kahein — main poora deep scan kar ke saare masail dhoond dunga, phir khud theek bhi kar dunga.`;
      const d = a.data;
      return hdr + `🩺 **Aakhri Scan** (${a.when})\n\n**Health Score: ${d.health_score}/100**\n\n` +
        (d.issues_found?.length
          ? `**Masail:**\n` + d.issues_found.slice(0, 10).map(i => `• ${sevIcon(i.sev)} ${i.issue}\n  → *${i.fix}*`).join('\n') +
            `\n\n💡 Internet on kar ke *"sab theek karo"* kahein — main khud fix kar dunga.`
          : '✅ Koi bara masla nahi tha.');
    }

    case 'orders': case 'products': case 'stock': case 'sales': case 'briefing': {
      const key = { orders: 'orders', products: 'products', stock: 'low', sales: 'sales', briefing: 'sales' }[intent];
      const o = cached(key);
      if (!o) return hdr + `Yeh data live chahiye hota hai. **Internet on karein** phir dobara poochein.\n\n(Ek baar data aa jane ke baad main offline bhi purana data dikha sakta hun.)`;
      return hdr + `📊 **Aakhri data** (${o.when}) — live nahi:\n\n\`\`\`\n${JSON.stringify(o.data, null, 1).slice(0, 1400)}\n\`\`\`\n\n💡 Taza data ke liye internet on karein.`;
    }

    case 'footer':
      return hdr + `🔧 Footer theek karne ke liye **internet zaroori hai** (theme mein CSS lagani parti hai).\n\nInternet on kar ke sirf itna kahein: **"Footer theek karo"**\n\nMain khud:\n• Columns barabar karunga\n• Mobile par center align\n• Spacing aur links theek\n\n⚡ Ek tap, 10 second.`;

    case 'grow':
      return hdr + growPlanText(c);

    case 'pages':
      return hdr + `📄 **Har store ko yeh 7 pages chahiye:**\n\n` +
        `1. **About Us** — bharosa banata hai\n2. **Contact Us** — ⚠️ bina iske Facebook/Google ads reject\n3. **FAQ** — support kam, sales zyada\n4. **Shipping Policy** — cart abandonment kam\n5. **Refund Policy** — ⚠️ ads ke liye lazmi\n6. **Privacy Policy** — legal\n7. **Terms of Service** — legal\n\n` +
        `Main in sab ka content **abhi offline** bana sakta hun — bas naam batayein (jaise "About Us banao").\n\n` +
        `Internet on ho to main yeh **khud bana kar publish** kar deta hun — ek hi command mein saare 7.`;

    default:
      return `📴 **Offline Mode**\n\n` +
        (on ? `Internet to hai magar **AI key nahi mili**. ⚙️ Settings mein free key daalein — 1 minute ka kaam.\n\n` : `Abhi internet nahi hai.\n\n`) +
        `**Filhaal main yeh kar sakta hun:**\n` +
        `• "About Us banao" / "Contact page" / "FAQ" / "Policies"\n` +
        `• "Hashtags do"\n• "Ad copy do"\n• "Product description"\n• "Launch checklist"\n• "Viral plan"\n\n` +
        `Bas yeh alfaz likh dein — main foran ready content de dunga.`;
  }
}

const sevIcon = s => ({ critical: '🔴', high: '🟠', medium: '🟡', low: '⚪' }[s] || '•');

function htmlToText(h) {
  return String(h)
    .replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, '\n## $1\n')
    .replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, '\n### $1\n')
    .replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, '- $1\n')
    .replace(/<\/?(ul|ol)[^>]*>/gi, '')
    .replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, '$1\n\n')
    .replace(/<strong>([\s\S]*?)<\/strong>/gi, '**$1**')
    .replace(/<em>([\s\S]*?)<\/em>/gi, '*$1*')
    .replace(/<hr\s*\/?>/gi, '\n---\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/\n{3,}/g, '\n\n').trim();
}

function launchChecklistText(c) {
  return `🚀 **LAUNCH CHECKLIST — ${c.name}**\n\n` +
    `**🔴 Launch se pehle LAZMI (warna ads reject/sales zero)**\n` +
    `☐ Contact page (email + WhatsApp)\n☐ Refund/Return policy\n☐ Shipping policy\n☐ Privacy policy\n☐ Har product par kam az kam 3 saaf tasveerein\n☐ Har product ki description (150+ alfaz)\n☐ Payment method test — khud ek order karein\n☐ Mobile par poori store check (80% traffic mobile se)\n\n` +
    `**🟠 Bharosa banane ke liye**\n` +
    `☐ About Us page (asli kahani)\n☐ FAQ page\n☐ Footer mein saare links\n☐ Trust badges (COD, 7-day return, secure)\n☐ Social media accounts bane hue\n☐ Store ka logo aur favicon\n\n` +
    `**🟡 Pehli sale ke liye**\n` +
    `☐ Launch discount code (jaise WELCOME10)\n☐ Free shipping threshold set\n☐ Abandoned cart email on\n☐ WhatsApp button lagayein\n☐ Instagram/TikTok par 9 posts pehle se\n☐ 20 doston ko personally message\n\n` +
    `**Day 1 par:**\n1. Instagram/Facebook par launch post + story\n2. WhatsApp status\n3. Har local group mein share\n4. Doston se pehla order + review\n5. ${c.currency} 500-1000 ka chhota ad test\n\n` +
    `💡 Online hone par kahein **"launch plan banao"** — main aap ki asli store check kar ke batata hun ke exactly kya kya baaki hai.`;
}

function viralPlanText(c) {
  const h = GEN.hashtags(c.category, c.country);
  return `🔥 **VIRAL PLAN — ${c.category}**\n\n` +
    `**Asal usool:** viral "luck" nahi — **volume + hook + consistency** hai.\n\n` +
    `**📱 Content Plan (rozana 1-3 post)**\n` +
    `• **Unboxing** — packing kholte hue (sab se zyada chalta hai)\n` +
    `• **Before/After** — masla → hal\n` +
    `• **POV** — "POV: jab aap ne akhirkar sahi ${c.category} dhoond liya"\n` +
    `• **Behind the scenes** — order pack karte hue\n` +
    `• **Customer reviews** — screenshot + product\n` +
    `• **Price reveal** — "guess karein kitne ka hai?"\n\n` +
    `**🎣 Hooks (pehle 3 second)**\n` +
    `• "Yeh mat khareedein jab tak..."\n` +
    `• "Mujhe kaash pehle pata hota"\n` +
    `• "3 cheezein jo koi nahi batata"\n` +
    `• "${c.currency} 500 mein yeh mil gaya 😱"\n\n` +
    `**#️⃣ Hashtags**\n\`\`\`\n${h.instagram_set.slice(0, 20).join(' ')}\n\`\`\`\n\n` +
    `**⏰ Best posting time (${c.country}):** subah 8-10, shaam 7-11\n\n` +
    `**🤝 Free reach ke tareeqe**\n` +
    `• 5 micro-influencers ko free product (10-50k followers — inka engagement bara hota hai)\n` +
    `• Local Facebook groups mein value dein, spam nahi\n` +
    `• Trending audio par apna product\n` +
    `• Comments ka jawab 1 ghante mein — algorithm boost deta hai\n` +
    `• Customer se video review mangein, discount ke badle\n\n` +
    `**📊 30-din target:** 60 posts. 3-5 chalengi. Wahi kaafi hain.\n\n` +
    `💡 Online hone par **"viral plan banao"** kahein — main live trends dekh kar aap ke product ka custom plan banata hun.`;
}

function growPlanText(c) {
  return `📈 **SALES BARHANE KA PLAN**\n\n` +
    `**Hafta 1 — Buniyad (bina paise ke)**\n` +
    `• Store ka full audit + saare masail fix\n• Har product ki description theek\n• Trust signals lagayein (COD, return, reviews)\n• Abandoned cart email on karein — 10-15% sales wapas aati hain\n\n` +
    `**Hafta 2 — Muft Traffic**\n` +
    `• Rozana 2 posts (Instagram + TikTok)\n• 5 micro-influencers ko free product\n• WhatsApp broadcast apni contact list ko\n• Local FB groups\n\n` +
    `**Hafta 3 — Paid Test**\n` +
    `• ${c.currency} 1000/din se shuru\n• 3 alag ads, 3 din chalayein\n• Jo chale usko double, baaki band\n• Facebook + TikTok dono test karein\n\n` +
    `**Hafta 4 — Scale**\n` +
    `• Winner ad ka budget rozana 20% barhayein\n• Retargeting on karein (jinho ne dekha magar khareeda nahi)\n• Upsell/bundle banayein — AOV barhta hai\n\n` +
    `**Har order ki qeemat kam karne ke 3 tareeqe:**\n` +
    `1. **Bundle** — "2 lein, 15% off" (AOV +40%)\n` +
    `2. **Free shipping threshold** — AOV se 20% upar rakhein\n` +
    `3. **Repeat customers** — naya customer 5x mehenga parta hai. Purane ko WhatsApp par offer bhejein.\n\n` +
    `💡 Online hone par **"sales double karo"** kahein — main aap ke asli numbers dekh kar exact plan banata hun.`;
}
