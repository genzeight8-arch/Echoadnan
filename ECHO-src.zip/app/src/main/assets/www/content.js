/* ============================================================
   content.js — Theme editing, Pages, Menus, Policies, Blog, SEO
   Agent khud footer align kar sakta hai, About/Contact bana sakta hai.
   ============================================================ */

async function liveThemeId() {
  const d = await Shop.rest('/themes.json');
  const t = d.themes.find(x => x.role === 'main');
  if (!t) throw new Error('Live theme nahi mili.');
  return t.id;
}

async function getAsset(themeId, key) {
  const d = await Shop.rest('/themes/' + themeId + '/assets.json?asset[key]=' + encodeURIComponent(key));
  return d.asset;
}

async function putAsset(themeId, key, value) {
  return await Shop.rest('/themes/' + themeId + '/assets.json', 'PUT',
    { asset: { key, value } });
}

Object.assign(TOOLS, {

  /* ================= THEME FILES ================= */

  read_theme_file: {
    desc: 'Theme ki koi file parhein — footer.liquid, header, product template, CSS. Edit se pehle hamesha parhein.',
    params: { key: 'required, e.g. sections/footer.liquid', theme_id: 'khali chhorein to live theme' },
    run: async (a = {}) => {
      if (!a.key) throw new Error('key zaroori hai, e.g. sections/footer.liquid');
      const id = a.theme_id || await liveThemeId();
      const as = await getAsset(id, a.key);
      return { theme_id: id, key: as.key, size: as.size, content: (as.value || '').slice(0, 12000) };
    }
  },

  write_theme_file: {
    desc: 'Theme file likhein/update karein. EHTIYAT: pehle read_theme_file se parhein, phir poora naya content bhejein.',
    params: { key: 'required file path', content: 'required full new file content', theme_id: 'default live' },
    run: async (a = {}) => {
      if (!a.key || a.content == null) throw new Error('key aur content dono zaroori hain');
      const id = a.theme_id || await liveThemeId();
      const r = await putAsset(id, a.key, a.content);
      return { ok: true, theme_id: id, key: r.asset.key, size: r.asset.size, updated: r.asset.updated_at };
    }
  },

  add_theme_css: {
    desc: 'Theme mein custom CSS add karein — footer alignment, spacing, colors, fonts theek karne ke liye. Safe: sirf CSS file ke aakhir mein add hota hai.',
    params: { css: 'required CSS rules', label: 'comment label, e.g. footer alignment fix' },
    run: async (a = {}) => {
      if (!a.css) throw new Error('css zaroori hai');
      const id = await liveThemeId();
      const list = await Shop.rest('/themes/' + id + '/assets.json');
      const cands = ['assets/base.css', 'assets/theme.css', 'assets/styles.css',
                     'assets/application.css', 'assets/custom.css', 'assets/theme.scss.liquid'];
      let key = cands.find(k => list.assets.some(x => x.key === k));
      if (!key) key = list.assets.find(x => /^assets\/.*\.css$/.test(x.key))?.key;
      if (!key) { key = 'assets/custom.css'; }

      let cur = '';
      try { cur = (await getAsset(id, key)).value || ''; } catch (_) { }

      const tag = '/* === APSA AGENT: ' + (a.label || 'custom') + ' === */';
      // remove previous block with same label
      const rx = new RegExp(tag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\\s\\S]*?/\\* === APSA END === \\*/', 'g');
      cur = cur.replace(rx, '');
      const block = '\n\n' + tag + '\n' + a.css + '\n/* === APSA END === */\n';
      const r = await putAsset(id, key, cur + block);
      return { ok: true, file: key, theme_id: id, added_bytes: block.length, updated: r.asset.updated_at,
               note: 'CSS live theme mein add ho gaya. Store refresh kar ke dekhein.' };
    }
  },

  fix_footer_alignment: {
    desc: 'Footer ko automatically theek align karein — columns barabar, mobile par center, spacing sudharna. Ek click fix.',
    params: { style: 'centered | left | grid — default grid', mobile_center: 'true/false, default true' },
    run: async (a = {}) => {
      const style = a.style || 'grid';
      const mc = a.mobile_center !== false;
      let css = `
/* Footer layout normalise */
.footer .footer__content-top,
footer .footer__content-top,
.site-footer__content,
.footer-block__wrapper {
  display: grid !important;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)) !important;
  gap: 32px 28px !important;
  align-items: start !important;
}
.footer .footer-block,
.site-footer__item,
.footer__block-item {
  text-align: ${style === 'centered' ? 'center' : 'left'} !important;
  min-width: 0 !important;
}
.footer .footer-block__heading,
.site-footer__linklist-title,
.footer-block__details h2 {
  margin-bottom: 12px !important;
  font-size: 1rem !important;
  letter-spacing: .02em !important;
}
.footer ul, footer ul { list-style: none !important; padding-left: 0 !important; margin: 0 !important; }
.footer li, footer .site-footer li { margin: 0 0 8px 0 !important; line-height: 1.6 !important; }
.footer a, footer a { text-decoration: none !important; }
.footer a:hover, footer a:hover { text-decoration: underline !important; opacity: .85 !important; }
.footer__content-bottom, .site-footer__bottom {
  display: flex !important; flex-wrap: wrap !important;
  justify-content: space-between !important; align-items: center !important;
  gap: 14px !important; padding-top: 20px !important; margin-top: 24px !important;
  border-top: 1px solid rgba(128,128,128,.22) !important;
}
.footer__list-social, .site-footer__social-icons {
  display: flex !important; gap: 14px !important; align-items: center !important;
  ${style === 'centered' ? 'justify-content: center !important;' : ''}
  padding: 0 !important; margin: 8px 0 0 0 !important;
}`;
      if (mc) css += `
@media screen and (max-width: 749px) {
  .footer .footer__content-top,
  footer .footer__content-top,
  .site-footer__content {
    grid-template-columns: 1fr !important;
    gap: 26px !important;
    text-align: center !important;
  }
  .footer .footer-block, .site-footer__item { text-align: center !important; }
  .footer__list-social, .site-footer__social-icons { justify-content: center !important; }
  .footer__content-bottom, .site-footer__bottom {
    flex-direction: column !important; text-align: center !important;
  }
}`;
      const r = await TOOLS.add_theme_css.run({ css, label: 'footer alignment' });
      return { ok: true, style, mobile_centered: mc, file: r.file,
               note: 'Footer align ho gaya. Store kholein aur refresh karein. Pasand na aaye to style "centered" ya "left" se dobara chalayein.' };
    }
  },

  /* ================= PAGES ================= */

  list_pages: {
    desc: 'Store ke saare pages (About Us, Contact, FAQ waghera) ki list.',
    params: { limit: 'default 50' },
    run: async (a = {}) => {
      const d = await Shop.rest('/pages.json?limit=' + (a.limit || 50));
      return {
        count: d.pages.length,
        pages: d.pages.map(p => ({ id: p.id, title: p.title, handle: p.handle,
          published: !!p.published_at, words: stripTags(p.body_html).split(/\s+/).length, updated: p.updated_at }))
      };
    }
  },

  create_page: {
    desc: 'Naya page banayein — About Us, Contact, FAQ, Shipping Policy, Size Guide, kuch bhi. HTML content ke saath.',
    params: { title: 'required', body_html: 'required full HTML content', handle: 'url slug', published: 'true/false default true' },
    run: async (a = {}) => {
      if (!a.title || !a.body_html) throw new Error('title aur body_html dono zaroori hain');
      const body = { page: { title: a.title, body_html: a.body_html, published: a.published !== false } };
      if (a.handle) body.page.handle = a.handle;
      const p = (await Shop.rest('/pages.json', 'POST', body)).page;
      return { ok: true, id: p.id, title: p.title, url: 'https://' + Shop.cfg.domain + '/pages/' + p.handle };
    }
  },

  update_page: {
    desc: 'Maujooda page ka content update karein.',
    params: { id: 'page id (ya handle dein)', handle: 'page handle', title: '', body_html: '' },
    run: async (a = {}) => {
      let id = a.id;
      if (!id && a.handle) {
        const d = await Shop.rest('/pages.json?limit=250');
        id = d.pages.find(p => p.handle === a.handle || p.title.toLowerCase() === String(a.handle).toLowerCase())?.id;
      }
      if (!id) throw new Error('page id ya handle zaroori hai');
      const pg = { id };
      if (a.title) pg.title = a.title;
      if (a.body_html) pg.body_html = a.body_html;
      const p = (await Shop.rest('/pages/' + id + '.json', 'PUT', { page: pg })).page;
      return { ok: true, id: p.id, title: p.title, url: 'https://' + Shop.cfg.domain + '/pages/' + p.handle };
    }
  },

  setup_essential_pages: {
    desc: 'Store ke zaroori pages ek saath check karein — kaunse mojood hain, kaunse missing (About, Contact, FAQ, Shipping, Returns, Privacy, Terms).',
    params: {},
    run: async () => {
      const need = [
        { h: 'about-us', n: 'About Us', why: 'Trust — customer jaanna chahta hai aap kaun hain' },
        { h: 'contact', n: 'Contact Us', why: 'Trust + Facebook/Google ads approval ke liye lazmi' },
        { h: 'faq', n: 'FAQ', why: 'Support tickets 40% kam, conversion barhta hai' },
        { h: 'shipping-policy', n: 'Shipping Policy', why: 'Cart abandonment kam karta hai' },
        { h: 'refund-policy', n: 'Refund / Return Policy', why: 'Ad platforms ke liye zaroori' },
        { h: 'privacy-policy', n: 'Privacy Policy', why: 'Legal requirement' },
        { h: 'terms-of-service', n: 'Terms of Service', why: 'Legal protection' }
      ];
      const [pg, sh] = await Promise.all([
        Shop.rest('/pages.json?limit=250'),
        Shop.rest('/shop.json')
      ]);
      const have = pg.pages.map(p => ({ h: p.handle, t: p.title.toLowerCase() }));
      const missing = [], present = [];
      need.forEach(x => {
        const f = have.find(p => p.h === x.h || p.h.includes(x.h.split('-')[0]) || p.t.includes(x.n.toLowerCase().split(' ')[0]));
        (f ? present : missing).push(f ? { page: x.n, handle: f.h } : x);
      });
      return {
        store: sh.shop.name, currency: sh.shop.currency, country: sh.shop.country_name,
        existing_pages: present, missing_pages: missing,
        note: 'Har missing page ke liye create_page tool chalayein — professional, store-specific content likh kar. Store ka naam aur niche zaroor use karein.'
      };
    }
  },

  /* ================= NAVIGATION / MENU ================= */

  list_menus: {
    desc: 'Store ke navigation menus (main menu, footer menu) aur unke links dekhein.',
    params: {},
    run: async () => {
      const d = await Shop.gql(`{ menus(first: 12) { nodes { id handle title
        items { id title url type items { id title url } } } } }`);
      return {
        menus: d.menus.nodes.map(m => ({
          handle: m.handle, title: m.title, id: m.id,
          links: m.items.map(i => ({ title: i.title, url: i.url,
            sub: i.items?.map(s => s.title) || [] }))
        })),
        note: 'footer menu ka handle aksar "footer" hota hai.'
      };
    }
  },

  update_menu: {
    desc: 'Menu ke links set karein — footer menu mein About/Contact/FAQ add karne ke liye. Note: yeh poora menu replace karta hai, pehle list_menus chalayein.',
    params: { handle: 'menu handle e.g. footer', title: 'menu title', items: 'array of {title, url} — url jaise /pages/about-us' },
    run: async (a = {}) => {
      if (!a.handle || !a.items) throw new Error('handle aur items zaroori hain');
      const d = await Shop.gql(`query($h:String!){ menus(first:20, query:$h){ nodes{ id handle title } } }`, { h: a.handle });
      const menu = d.menus.nodes.find(m => m.handle === a.handle);
      if (!menu) throw new Error('Menu "' + a.handle + '" nahi mila. list_menus chalayein.');
      const items = (typeof a.items === 'string' ? JSON.parse(a.items) : a.items)
        .map(i => ({ title: i.title, type: 'HTTP', url: i.url }));
      const r = await Shop.gql(`mutation($id:ID!,$t:String!,$h:String!,$i:[MenuItemUpdateInput!]!){
        menuUpdate(id:$id, title:$t, handle:$h, items:$i){
          menu{ id handle items{ title url } } userErrors{ field message } } }`,
        { id: menu.id, t: a.title || menu.title, h: a.handle, i: items });
      const e = r.menuUpdate.userErrors;
      if (e?.length) throw new Error(e.map(x => x.message).join('; '));
      return { ok: true, handle: a.handle, links: r.menuUpdate.menu.items };
    }
  },

  /* ================= POLICIES ================= */

  update_policy: {
    desc: 'Store ki legal policy set karein — refund, privacy, terms, shipping. Checkout par khud dikhti hain.',
    params: { type: 'REFUND_POLICY | PRIVACY_POLICY | TERMS_OF_SERVICE | SHIPPING_POLICY | CONTACT_INFORMATION', body: 'required HTML' },
    run: async (a = {}) => {
      if (!a.type || !a.body) throw new Error('type aur body zaroori hain');
      const r = await Shop.gql(`mutation($p:ShopPolicyInput!){
        shopPolicyUpdate(shopPolicy:$p){ shopPolicy{ type url } userErrors{ message } } }`,
        { p: { type: a.type.toUpperCase(), body: a.body } });
      const e = r.shopPolicyUpdate.userErrors;
      if (e?.length) throw new Error(e.map(x => x.message).join('; '));
      return { ok: true, type: a.type, url: r.shopPolicyUpdate.shopPolicy.url };
    }
  },

  /* ================= PRODUCT CONTENT / SEO ================= */

  write_product_description: {
    desc: 'Product ki description professional, SEO-friendly HTML mein likh kar update karein.',
    params: { product_id: 'required', body_html: 'required full HTML description', seo_title: '', seo_description: '' },
    run: async (a = {}) => {
      if (!a.product_id || !a.body_html) throw new Error('product_id aur body_html zaroori hain');
      const p = (await Shop.rest('/products/' + a.product_id + '.json', 'PUT',
        { product: { id: a.product_id, body_html: a.body_html } })).product;
      const out = { ok: true, id: p.id, title: p.title };
      if (a.seo_title || a.seo_description) {
        const mf = [];
        if (a.seo_title) mf.push({ key: 'title_tag', namespace: 'global', value: a.seo_title, type: 'single_line_text_field' });
        if (a.seo_description) mf.push({ key: 'description_tag', namespace: 'global', value: a.seo_description, type: 'single_line_text_field' });
        await Shop.rest('/products/' + a.product_id + '.json', 'PUT',
          { product: { id: a.product_id, metafields: mf } }).catch(() => { });
        out.seo_updated = true;
      }
      return out;
    }
  },

  audit_store: {
    desc: 'Poori store ka health audit — kya missing hai, kya theek karna hai. Store ko professional banane ka pehla qadam.',
    params: {},
    run: async () => {
      const [shop, pages, prods, themes, menus] = await Promise.all([
        Shop.rest('/shop.json').then(r => r.shop),
        Shop.rest('/pages.json?limit=250').then(r => r.pages).catch(() => []),
        Shop.rest('/products.json?limit=250').then(r => r.products).catch(() => []),
        Shop.rest('/themes.json').then(r => r.themes).catch(() => []),
        Shop.gql('{ menus(first:10){ nodes{ handle items{ title url } } } }').then(d => d.menus.nodes).catch(() => [])
      ]);
      const issues = [], good = [];
      const ph = pages.map(p => p.handle);
      const chk = (h, label) => ph.some(x => x.includes(h));

      chk('about', 1) ? good.push('About page mojood') : issues.push({ sev: 'high', issue: 'About Us page nahi', fix: 'create_page se About Us banayein — trust ke liye zaroori' });
      chk('contact', 1) ? good.push('Contact page mojood') : issues.push({ sev: 'critical', issue: 'Contact page nahi', fix: 'Facebook/Google ads approve nahi honge. Foran banayein.' });
      chk('faq', 1) ? good.push('FAQ mojood') : issues.push({ sev: 'medium', issue: 'FAQ page nahi', fix: 'Support load kam karega' });
      chk('refund', 1) || chk('return', 1) ? good.push('Refund policy mojood') : issues.push({ sev: 'critical', issue: 'Refund/Return policy nahi', fix: 'Ad platforms reject karenge' });
      chk('privacy', 1) ? good.push('Privacy policy mojood') : issues.push({ sev: 'high', issue: 'Privacy policy nahi', fix: 'Legal requirement' });
      chk('shipping', 1) ? good.push('Shipping policy mojood') : issues.push({ sev: 'high', issue: 'Shipping policy nahi', fix: 'Cart abandonment barhta hai' });

      const noDesc = prods.filter(p => stripTags(p.body_html).length < 60);
      if (noDesc.length) issues.push({ sev: 'high', issue: noDesc.length + ' products ki description khali/choti hai',
        fix: 'write_product_description se likhein', examples: noDesc.slice(0, 5).map(p => p.title) });

      const noImg = prods.filter(p => !p.image);
      if (noImg.length) issues.push({ sev: 'critical', issue: noImg.length + ' products bina image ke',
        fix: 'Images add karein — bina image ke koi nahi kharidta', examples: noImg.slice(0, 5).map(p => p.title) });

      const drafts = prods.filter(p => p.status === 'draft');
      if (drafts.length) issues.push({ sev: 'medium', issue: drafts.length + ' products draft mein hain (bikk nahi rahe)', fix: 'Ready hain to active karein' });

      const noVendor = prods.filter(p => !p.vendor);
      if (noVendor.length > prods.length * 0.5) issues.push({ sev: 'low', issue: 'Zyada tar products mein vendor/brand nahi', fix: 'Filtering aur SEO behtar hoti hai' });

      const fm = menus.find(m => m.handle === 'footer');
      if (!fm || fm.items.length < 3) issues.push({ sev: 'medium', issue: 'Footer menu khali ya adhoora',
        fix: 'update_menu se About, Contact, FAQ, policies add karein' });

      return {
        store: shop.name, domain: shop.domain, currency: shop.currency, plan: shop.plan_display_name,
        products: prods.length, active_products: prods.filter(p => p.status === 'active').length,
        pages: pages.length, live_theme: themes.find(t => t.role === 'main')?.name,
        health_score: Math.max(0, 100 - issues.reduce((s, i) => s + ({ critical: 20, high: 12, medium: 6, low: 3 }[i.sev] || 5), 0)),
        working_well: good, issues_found: issues.sort((a, b) => ({ critical: 0, high: 1, medium: 2, low: 3 }[a.sev] - { critical: 0, high: 1, medium: 2, low: 3 }[b.sev])),
        note: 'Priority order mein issues fix karein. Har fix ke liye mutabiq tool chalayein.'
      };
    }
  }
});
