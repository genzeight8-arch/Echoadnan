/* ============================================================
   growth.js — Ads, Marketing, Strategy, Think-Tank, Autopilot
   ============================================================ */

Object.assign(TOOLS, {

  /* ---------- niche discovery ---------- */
  detect_store_niche: {
    desc: 'Store ka niche, target audience aur positioning khud detect karein — products aur content parh kar. Ads/strategy se pehle chalayein.',
    params: {},
    run: async () => {
      const [sh, pr] = await Promise.all([
        Shop.rest('/shop.json').then(r => r.shop),
        Shop.rest('/products.json?limit=100').then(r => r.products).catch(() => [])
      ]);
      const types = {}, vendors = {}, tags = {};
      let pmin = Infinity, pmax = 0, psum = 0, pn = 0;
      pr.forEach(p => {
        if (p.product_type) types[p.product_type] = (types[p.product_type] || 0) + 1;
        if (p.vendor) vendors[p.vendor] = (vendors[p.vendor] || 0) + 1;
        String(p.tags || '').split(',').map(t => t.trim()).filter(Boolean)
          .forEach(t => tags[t] = (tags[t] || 0) + 1);
        p.variants?.forEach(v => { const x = parseFloat(v.price); if (x > 0) { pmin = Math.min(pmin, x); pmax = Math.max(pmax, x); psum += x; pn++; } });
      });
      const top = o => Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => k + ' (' + v + ')');
      return {
        store: sh.name, country: sh.country_name, currency: sh.currency, timezone: sh.iana_timezone,
        total_products: pr.length,
        categories: top(types), brands: top(vendors), common_tags: top(tags),
        price_band: pn ? { min: pmin.toFixed(2), max: pmax.toFixed(2), avg: (psum / pn).toFixed(2) } : null,
        sample_products: pr.slice(0, 12).map(p => p.title),
        note: 'Is data se store ka niche, ideal customer avatar, aur market positioning nikalein.'
      };
    }
  },

  /* ---------- ad creation ---------- */
  create_ad_campaign: {
    desc: 'Poora ad campaign banayein — Facebook/Instagram/TikTok/Google. Live niche research ke saath: hooks, copy, targeting, budget. Text/creative brief deta hai jo aap copy-paste kar sakein.',
    params: {
      platform: 'facebook | instagram | tiktok | google — default facebook',
      product_id: 'kis product ka ad (ya product_name)',
      product_name: '',
      budget: 'daily budget e.g. 2000',
      goal: 'sales | traffic | awareness | leads'
    },
    run: async (a = {}) => {
      const plat = (a.platform || 'facebook').toLowerCase();
      let product = null;
      if (a.product_id || a.product_name) {
        try { product = await TOOLS.get_product.run({ id: a.product_id, title: a.product_name }); } catch (_) { }
      }
      const niche = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const q = product ? product.title : (niche.categories?.[0] || 'ecommerce').replace(/\s*\(\d+\)/, '');
      const [ads, trends, kw] = await Promise.all([
        TOOLS.ad_intelligence.run({ niche: q, country: niche.country }).catch(() => ({})),
        TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({})),
        TOOLS.keyword_ideas.run({ seed: q }).catch(() => ({}))
      ]);
      return {
        platform: plat, goal: a.goal || 'sales',
        daily_budget: a.budget || 'user se poochein',
        currency: niche.currency, country: niche.country,
        product: product ? { title: product.title, price: product.variants?.[0]?.price, desc: product.description?.slice(0, 400), image: product.image } : null,
        store_context: { categories: niche.categories, price_band: niche.price_band },
        live_ad_research: ads.ad_research, creative_research: ads.creative_research,
        ad_library_link: ads.ad_library,
        trending_topics: trends.trending_now?.slice(0, 6),
        search_demand: kw.suggestions?.slice(0, 12),
        deliverable: `Ab ${plat} ke liye COMPLETE campaign likhein:
1. Campaign objective + structure (kitne ad sets)
2. TARGETING — age, gender, locations, detailed interests (5-8 asli interest names), lookalikes
3. 3 alag ANGLES (problem-solution, social proof, offer/urgency)
4. Har angle ke liye: 3 HOOKS (pehli line, scroll rokne wali), primary text (125 words), headline (40 chars), description, CTA button
5. CREATIVE BRIEF — image/video mein kya dikhe, shot-by-shot, text overlay
6. BUDGET split + testing plan (kitne din, kab scale, kab band)
7. KPIs — target CPC, CTR, CPA, ROAS aur break-even calculate karein product price se
Copy ${niche.country || 'Pakistan'} ke market ke mutabiq ho. Roman Urdu/English mix jo audience ko suit kare.`
      };
    }
  },

  ad_creative_variants: {
    desc: 'Ek product ke liye bohat saare ad copy variants banane ka data — A/B testing ke liye hooks aur angles.',
    params: { product_name: 'required', count: 'kitne variants, default 5' },
    run: async (a = {}) => {
      const p = await TOOLS.get_product.run({ title: a.product_name }).catch(() => null);
      const kw = await TOOLS.keyword_ideas.run({ seed: a.product_name }).catch(() => ({}));
      const res = await ddg(a.product_name + ' benefits why buy customer problems', 5).catch(() => []);
      return {
        product: p ? { title: p.title, price: p.variants?.[0]?.price, description: p.description } : { title: a.product_name },
        customer_language: kw.long_tail, search_terms: kw.suggestions,
        market_insight: res,
        deliverable: `${a.count || 5} alag ad copy variants likhein. Har ek mein: HOOK (scroll-stopper), BODY (benefit-driven, feature nahi), CTA. Har variant ka angle alag ho — curiosity, fear-of-missing-out, social proof, problem-agitate-solve, before-after, testimonial style. Customer ki apni zabaan use karein (upar diye keywords se).`
      };
    }
  },

  /* ---------- email / SMS ---------- */
  marketing_campaign: {
    desc: 'Email/SMS/WhatsApp marketing campaign plan — abandoned cart, welcome series, sale announcement, win-back.',
    params: { type: 'abandoned_cart | welcome | sale | winback | launch | newsletter', occasion: 'e.g. Eid, Black Friday' },
    run: async (a = {}) => {
      const [niche, orders, prods] = await Promise.all([
        TOOLS.detect_store_niche.run().catch(() => ({})),
        TOOLS.sales_summary.run({ days: 60 }).catch(() => ({})),
        TOOLS.list_products.run({ limit: 12, status: 'active' }).catch(() => ({}))
      ]);
      return {
        campaign_type: a.type || 'sale', occasion: a.occasion || null,
        store: niche.store, currency: niche.currency, country: niche.country,
        best_sellers: orders.top_products?.slice(0, 5),
        products_available: prods.products?.map(p => ({ title: p.title, price: p.price })),
        avg_order_value: orders.avg_order_value,
        deliverable: `Poora ${a.type || 'sale'} campaign likhein:
1. SEQUENCE — kitne messages, kab kab bhejne hain (timing)
2. Har message: SUBJECT LINE (3 options, A/B ke liye), preview text, poora body copy, CTA
3. SMS/WhatsApp version — 160 characters mein punchy
4. OFFER strategy — kitna discount, urgency kaise banayein
5. Segmentation — kis customer ko kya bhejein
6. Expected results — open rate, CTR, revenue estimate`
      };
    }
  },

  /* ---------- think tank ---------- */
  think_tank: {
    desc: 'Deep strategic analysis — business problem solve karein CEO/consultant ki tarah. Store data + live market research mila kar action plan banata hai.',
    params: { question: 'required — e.g. "sales kaise double karein" ya "kaunsa product launch karun"', depth: 'quick | deep — default deep' },
    run: async (a = {}) => {
      if (!a.question) throw new Error('question zaroori hai');
      const deep = a.depth !== 'quick';
      const jobs = [
        TOOLS.detect_store_niche.run().catch(e => ({ error: e.message })),
        TOOLS.sales_summary.run({ days: 90 }).catch(e => ({ error: e.message })),
        ddg(a.question + ' shopify ecommerce strategy ' + new Date().getFullYear(), 6).catch(() => [])
      ];
      if (deep) {
        jobs.push(TOOLS.audit_store.run().catch(e => ({ error: e.message })));
        jobs.push(TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({})));
        jobs.push(TOOLS.low_stock.run({ threshold: 5 }).catch(() => ({})));
      }
      const [niche, sales, web, audit, trends, low] = await Promise.all(jobs);
      return {
        question: a.question,
        store_reality: { niche: niche.categories, country: niche.country, currency: niche.currency,
          products: niche.total_products, price_band: niche.price_band },
        performance_90d: { revenue: sales.revenue, orders: sales.orders, aov: sales.avg_order_value,
          top_products: sales.top_products?.slice(0, 5), unfulfilled: sales.unfulfilled },
        store_health: audit ? { score: audit.health_score, critical_issues: audit.issues_found?.filter(i => i.sev === 'critical' || i.sev === 'high') } : null,
        inventory_risk: low?.count ? low.count + ' items low stock' : 'theek hai',
        market_trends: trends?.trending_now?.slice(0, 6),
        expert_research: web,
        deliverable: `Ab THINK TANK ki tarah jawab dein — ek tajurbakaar ecommerce consultant jo laakhon ki stores chala chuka ho:

**1. SEEDHI BAAT** — asli masla kya hai (data se, andaze se nahi)
**2. TASHKHEES** — numbers kya keh rahe hain, kahan paisa leak ho raha hai
**3. 3 STRATEGIC OPTIONS** — har ek ke saath: effort, cost, expected result, risk
**4. MERI SIFARISH** — kaunsa option aur kyun
**5. ACTION PLAN** — 7 din / 30 din / 90 din, har kaam ke saath kis din
**6. NUMBERS** — realistic projection: kitna invest, kitna wapas, kab tak
**7. KHATRAT** — kya galat ho sakta hai aur bachao

Seedha, imandarana, aur specific rahein. "Marketing barhayein" jaisi bakwas nahi — batayein exactly kya karna hai.`
      };
    }
  },

  competitor_battle_plan: {
    desc: 'Competitor se muqabla karne ka plan — unki store analyse kar ke aapke liye strategy.',
    params: { competitor: 'required domain e.g. rival.com' },
    run: async (a = {}) => {
      if (!a.competitor) throw new Error('competitor domain zaroori hai');
      const [comp, mine, web] = await Promise.all([
        TOOLS.spy_competitor.run({ domain: a.competitor, limit: 50 }).catch(e => ({ error: e.message })),
        TOOLS.detect_store_niche.run().catch(() => ({})),
        ddg(a.competitor + ' reviews complaints customers', 5).catch(() => [])
      ]);
      return {
        competitor: comp, my_store: { categories: mine.categories, price_band: mine.price_band, products: mine.total_products },
        their_reputation: web,
        deliverable: `Competitor battle plan banayein:
1. PRICE COMPARISON — hum mehenge/saste hain, kitna, kya karna chahiye
2. PRODUCT GAPS — unke paas hai humare paas nahi (opportunity)
3. HAMARI TAAQAT — kahan hum behtar hain, ise kaise highlight karein
4. UNKI KAMZORI — reviews/complaints se, ise apna USP banayein
5. POSITIONING — hum market mein kahan khare hon
6. 30-DIN KA PLAN — concrete steps`
      };
    }
  },

  seo_plan: {
    desc: 'SEO strategy — keywords, content plan, product optimization. Muft organic traffic ke liye.',
    params: { focus: 'kis cheez par focus, khali chhorein to poori store' },
    run: async (a = {}) => {
      const niche = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const seed = a.focus || (niche.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const [kw, comp, prods] = await Promise.all([
        TOOLS.keyword_ideas.run({ seed }).catch(() => ({})),
        ddg(seed + ' buy online ' + (niche.country || 'Pakistan'), 8).catch(() => []),
        TOOLS.list_products.run({ limit: 20 }).catch(() => ({}))
      ]);
      return {
        focus: seed, country: niche.country,
        keyword_opportunities: kw.suggestions, question_keywords: kw.long_tail,
        who_ranks_now: comp,
        my_products: prods.products?.map(p => p.title),
        deliverable: `SEO plan banayein:
1. PRIMARY keywords (5) + LONG-TAIL (15) — search intent ke saath
2. Har product ka behtar TITLE + META DESCRIPTION (character limits ka khayal)
3. 10 BLOG POST ideas — title + target keyword + outline
4. COLLECTION page strategy
5. Technical fixes — alt text, URL structure, internal linking
6. 90-din ka content calendar`
      };
    }
  },

  pricing_strategy: {
    desc: 'Pricing analysis — kya hum sahi price par bech rahe hain? Profit barhane ke liye.',
    params: { product_name: 'khali chhorein to poori store' },
    run: async (a = {}) => {
      const [niche, sales, prods] = await Promise.all([
        TOOLS.detect_store_niche.run().catch(() => ({})),
        TOOLS.sales_summary.run({ days: 60 }).catch(() => ({})),
        TOOLS.list_products.run({ limit: 100 }).catch(() => ({}))
      ]);
      const q = a.product_name || (niche.categories?.[0] || '').replace(/\s*\(\d+\)/, '');
      const market = await ddg(q + ' price ' + (niche.country || 'Pakistan') + ' online', 8).catch(() => []);
      return {
        my_prices: prods.products?.map(p => ({ title: p.title, price: p.price, stock: p.inventory })),
        price_band: niche.price_band, aov: sales.avg_order_value, currency: niche.currency,
        best_sellers: sales.top_products?.slice(0, 5),
        market_prices: market,
        deliverable: `Pricing strategy dein:
1. Har best-seller ka price sahi hai ya nahi — market se compare
2. Kaunse products ka price BARHANA chahiye (aur kitna)
3. Kaunse par discount/bundle chalega
4. AOV barhane ke tareeqe — bundles, upsell, free shipping threshold
5. Psychological pricing (999 vs 1000) ka faida
6. Expected profit impact numbers ke saath`
      };
    }
  },

  daily_briefing: {
    desc: 'Aaj ka full briefing — store ki halat, kya urgent hai, aaj kya karna chahiye. Har subah chalayein.',
    params: {},
    run: async () => {
      const [today, week, low, unf, trends] = await Promise.all([
        TOOLS.sales_summary.run({ days: 1 }).catch(() => ({})),
        TOOLS.sales_summary.run({ days: 7 }).catch(() => ({})),
        TOOLS.low_stock.run({ threshold: 5 }).catch(() => ({})),
        TOOLS.list_orders.run({ limit: 30, fulfillment_status: 'unshipped', status: 'open' }).catch(() => ({})),
        TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({}))
      ]);
      const prev = await TOOLS.sales_summary.run({ days: 14 }).catch(() => ({}));
      const w1 = parseFloat(week.revenue || 0);
      const w2 = parseFloat(prev.revenue || 0) - w1;
      return {
        date: new Date().toDateString(),
        today: { orders: today.orders, revenue: today.revenue, currency: today.currency },
        this_week: { orders: week.orders, revenue: week.revenue, aov: week.avg_order_value },
        vs_last_week: w2 > 0 ? (((w1 - w2) / w2) * 100).toFixed(1) + '%' : 'data kam hai',
        needs_shipping: unf.count || 0,
        low_stock_items: low.count || 0,
        low_stock_list: low.items?.slice(0, 5),
        top_this_week: week.top_products?.slice(0, 3),
        trending_now: trends.trending_now?.slice(0, 5),
        deliverable: `Ek chhota, tez DAILY BRIEFING likhein jaise ek achha manager subah deta hai:
- 📊 Numbers (kal/aaj kaisa raha, trend upar ya neeche)
- 🚨 URGENT — aaj kya karna hi hai
- 💡 1 OPPORTUNITY — aaj ka ek mauqa (trends ya data se)
- ✅ Aaj ke top 3 kaam, priority order mein
Mukhtasar rakhein — 30 second mein parha ja sake.`
      };
    }
  },

  /* ---------- AUTOPILOT ---------- */
  autopilot: {
    desc: 'AUTOPILOT — store khud scan karein, saare masail dhoondein, aur poora fix plan banayein. Insaan ki tarah store sambhalna.',
    params: { mode: 'audit | fix | grow — default audit' },
    run: async (a = {}) => {
      const mode = a.mode || 'audit';
      const [audit, niche, sales, pages, low, unf] = await Promise.all([
        TOOLS.audit_store.run().catch(e => ({ error: e.message })),
        TOOLS.detect_store_niche.run().catch(() => ({})),
        TOOLS.sales_summary.run({ days: 30 }).catch(() => ({})),
        TOOLS.setup_essential_pages.run().catch(() => ({})),
        TOOLS.low_stock.run({ threshold: 5 }).catch(() => ({})),
        TOOLS.list_orders.run({ limit: 50, fulfillment_status: 'unshipped', status: 'open' }).catch(() => ({}))
      ]);
      return {
        mode,
        health_score: audit.health_score,
        store: { name: audit.store, niche: niche.categories, products: audit.products, country: niche.country },
        critical_issues: audit.issues_found?.filter(i => i.sev === 'critical'),
        high_issues: audit.issues_found?.filter(i => i.sev === 'high'),
        other_issues: audit.issues_found?.filter(i => i.sev === 'medium' || i.sev === 'low'),
        missing_pages: pages.missing_pages,
        operations: { unfulfilled_orders: unf.count, low_stock: low.count },
        performance: { revenue_30d: sales.revenue, orders: sales.orders, aov: sales.avg_order_value },
        available_tools: Object.keys(TOOLS),
        deliverable: mode === 'fix'
          ? `AUTOPILOT FIX MODE: Ek numbered ACTION LIST banayein — har item ke saath exact tool aur parameters jo main abhi chala sakta hun. Critical se shuru karein. Phir user se poochein: "Main yeh sab abhi kar dun?" Ijazat milne par ek ek kar ke tools chalayein.`
          : mode === 'grow'
          ? `AUTOPILOT GROW MODE: Store ki halat dekh kar ek GROWTH PLAN banayein — is hafte kya karna hai sales barhane ke liye. Ads, content, pricing, offers — sab specific. Har kaam ke saath expected impact.`
          : `AUTOPILOT AUDIT: Store ka poora scorecard pesh karein — health score, kya theek hai, kya kharab, priority order mein fix list. Aakhir mein poochein ke kya main yeh masail khud theek kar dun.`
      };
    }
  }
});
