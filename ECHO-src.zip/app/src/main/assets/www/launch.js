/* ============================================================
   launch.js — Deep Scan, AUTO-FIX, Launch Kit, Viral Growth
   ECHO ka sab se taaqatwar hissa.
   ============================================================ */

Object.assign(TOOLS, {

  /* ================= DEEP SCAN ================= */
  deep_scan: {
    desc: 'POORI store ka gehra scan — har cheez check karta hai: products, images, descriptions, SEO, pages, policies, menus, theme, inventory, orders, pricing. Har masla dhoond kar priority ke saath deta hai. Yeh sab se ahem tool hai.',
    params: {},
    run: async () => {
      const [shop, prods, pages, themes, menus, orders, colls, disc] = await Promise.all([
        Shop.rest('/shop.json').then(r => r.shop).catch(() => ({})),
        Shop.rest('/products.json?limit=250').then(r => r.products).catch(() => []),
        Shop.rest('/pages.json?limit=250').then(r => r.pages).catch(() => []),
        Shop.rest('/themes.json').then(r => r.themes).catch(() => []),
        Shop.gql('{ menus(first:10){ nodes{ handle title items{ title url } } } }').then(d => d.menus.nodes).catch(() => []),
        Shop.rest('/orders.json?status=any&limit=250').then(r => r.orders).catch(() => []),
        Shop.rest('/custom_collections.json?limit=50').then(r => r.custom_collections).catch(() => []),
        Shop.rest('/price_rules.json?limit=20').then(r => r.price_rules).catch(() => [])
      ]);

      const P = [];   // problems
      const add = (sev, area, issue, fix, tool, args, extra) =>
        P.push({ sev, area, issue, fix, auto_fix_tool: tool || null, auto_fix_args: args || null, ...(extra || {}) });

      /* ---- PAGES ---- */
      const ph = pages.map(p => (p.handle || '').toLowerCase());
      const hasPage = k => ph.some(x => x.includes(k));
      if (!hasPage('contact')) add('critical', 'Pages', 'Contact page nahi hai',
        'Bina Contact page ke Facebook/Google ads REJECT ho jate hain aur customer bharosa nahi karta',
        'create_page', { title: 'Contact Us', handle: 'contact', generate: 'contact' });
      if (!hasPage('refund') && !hasPage('return')) add('critical', 'Policies', 'Refund/Return policy nahi',
        'Ad platforms ke liye lazmi. Iske bina account ban bhi ho sakta hai',
        'update_policy', { type: 'REFUND_POLICY', generate: 'refund' });
      if (!hasPage('about')) add('high', 'Pages', 'About Us page nahi',
        'Customer jaanna chahta hai aap kaun hain — bharosa yahin banta hai',
        'create_page', { title: 'About Us', handle: 'about-us', generate: 'about' });
      if (!hasPage('shipping')) add('high', 'Policies', 'Shipping policy nahi',
        'Log delivery ka waqt aur charges jaanna chahte hain — warna cart chhor dete hain',
        'update_policy', { type: 'SHIPPING_POLICY', generate: 'shipping' });
      if (!hasPage('privacy')) add('high', 'Policies', 'Privacy policy nahi',
        'Legal requirement + ad platforms check karte hain',
        'update_policy', { type: 'PRIVACY_POLICY', generate: 'privacy' });
      if (!hasPage('terms')) add('medium', 'Policies', 'Terms of Service nahi',
        'Legal hifazat ke liye zaroori',
        'update_policy', { type: 'TERMS_OF_SERVICE', generate: 'terms' });
      if (!hasPage('faq')) add('medium', 'Pages', 'FAQ page nahi',
        'Support messages 40% kam ho jate hain aur conversion barhta hai',
        'create_page', { title: 'FAQ', handle: 'faq', generate: 'faq' });

      /* ---- PRODUCTS ---- */
      const active = prods.filter(p => p.status === 'active');
      if (!prods.length) add('critical', 'Products', 'Store mein koi product nahi', 'Products add karein');
      if (prods.length && !active.length) add('critical', 'Products', 'Koi product active nahi — kuch bikk nahi sakta',
        'Products ko active karein');

      const noImg = prods.filter(p => !p.image);
      if (noImg.length) add('critical', 'Products', noImg.length + ' products bina tasveer ke',
        'Bina image ke koi nahi kharidta. Har product par 3+ tasveerein chahiye', null, null,
        { items: noImg.slice(0, 10).map(p => ({ id: p.id, title: p.title })) });

      const oneImg = prods.filter(p => p.images && p.images.length === 1);
      if (oneImg.length) add('medium', 'Products', oneImg.length + ' products par sirf 1 tasveer',
        '3-5 tasveerein (alag angles, istemal karte hue) conversion 30% barhati hain', null, null,
        { items: oneImg.slice(0, 8).map(p => p.title) });

      const shortDesc = prods.filter(p => stripTags(p.body_html || '').length < 100);
      if (shortDesc.length) add('high', 'Content', shortDesc.length + ' products ki description khali ya bohat choti',
        'Achhi description sales aur Google ranking dono barhati hai',
        'bulk_fix_descriptions', {}, { items: shortDesc.slice(0, 10).map(p => ({ id: p.id, title: p.title })) });

      const noPrice = prods.filter(p => !p.variants?.[0]?.price || parseFloat(p.variants[0].price) <= 0);
      if (noPrice.length) add('critical', 'Products', noPrice.length + ' products ki price 0 ya khali',
        'Price set karein', null, null, { items: noPrice.slice(0, 8).map(p => p.title) });

      const noCompare = active.filter(p => !p.variants?.[0]?.compare_at_price);
      if (noCompare.length > active.length * 0.6 && active.length > 2)
        add('medium', 'Pricing', 'Zyada tar products par "compare at" price nahi',
          'Cut price dikhane se (₨2000 ~~₨2999~~) urgency banti hai aur sales barhti hain');

      const noVendor = prods.filter(p => !p.vendor);
      if (noVendor.length > prods.length * 0.5 && prods.length > 3)
        add('low', 'SEO', 'Zyada tar products mein brand/vendor khali', 'Filtering aur SEO behtar hota hai');

      const noType = prods.filter(p => !p.product_type);
      if (noType.length > prods.length * 0.5 && prods.length > 3)
        add('low', 'SEO', 'Product type set nahi', 'Categories aur collections ke liye zaroori');

      const noTags = prods.filter(p => !p.tags);
      if (noTags.length > prods.length * 0.6 && prods.length > 3)
        add('low', 'SEO', 'Products par tags nahi', 'Search aur filtering behtar hoti hai');

      const drafts = prods.filter(p => p.status === 'draft');
      if (drafts.length) add('medium', 'Products', drafts.length + ' products draft mein (bikk nahi rahe)',
        'Tayar hain to active karein', null, null, { items: drafts.slice(0, 8).map(p => p.title) });

      /* ---- INVENTORY ---- */
      const oos = [], low = [];
      prods.forEach(p => p.variants?.forEach(v => {
        if (v.inventory_management === 'shopify') {
          const q = v.inventory_quantity || 0;
          if (q <= 0) oos.push(p.title + (v.title !== 'Default Title' ? ' / ' + v.title : ''));
          else if (q <= 5) low.push(p.title + ' (' + q + ')');
        }
      }));
      if (oos.length) add('high', 'Inventory', oos.length + ' items stock mein nahi',
        'Restock karein ya hide karein — out of stock product par ad chalana paisa zaya hai', null, null,
        { items: oos.slice(0, 10) });
      if (low.length) add('medium', 'Inventory', low.length + ' items ka stock kam (≤5)',
        'Restock karein warna sales ruk jayengi', null, null, { items: low.slice(0, 10) });

      /* ---- COLLECTIONS ---- */
      if (!colls.length && prods.length > 5) add('medium', 'Navigation', 'Koi collection nahi bani',
        'Collections se log products aasani se dhoondte hain');

      /* ---- MENUS ---- */
      const fm = menus.find(m => m.handle === 'footer');
      if (!fm || (fm.items || []).length < 4) add('high', 'Navigation', 'Footer menu khali ya adhoora',
        'Footer mein About, Contact, FAQ, policies ke links hone chahiyen — trust signal hai',
        'auto_fix_footer_menu', {});
      const mm = menus.find(m => m.handle === 'main-menu');
      if (mm && (mm.items || []).length < 3) add('medium', 'Navigation', 'Main menu mein bohat kam links',
        'Home, Shop, About, Contact hone chahiyen');

      /* ---- DISCOUNTS ---- */
      if (!disc.length) add('medium', 'Marketing', 'Koi discount code nahi',
        'Welcome discount se pehli sale aasan hoti hai',
        'create_discount', { code: 'WELCOME10', type: 'percentage', value: 10 });

      /* ---- ORDERS ---- */
      const unf = orders.filter(o => !o.fulfillment_status && !o.cancelled_at);
      if (unf.length) add(unf.length > 5 ? 'high' : 'medium', 'Operations',
        unf.length + ' orders abhi tak ship nahi hue',
        'Foran bhejein — der se customer nakhush hota hai aur refund maangta hai', null, null,
        { items: unf.slice(0, 10).map(o => o.name) });

      const pending = orders.filter(o => o.financial_status === 'pending' && !o.cancelled_at);
      if (pending.length > 3) add('medium', 'Operations', pending.length + ' orders ki payment pending',
        'Follow up karein');

      /* ---- THEME ---- */
      const live = themes.find(t => t.role === 'main');
      if (!live) add('critical', 'Theme', 'Koi live theme nahi', 'Theme publish karein');

      /* ---- SHOP SETTINGS ---- */
      if (!shop.email) add('medium', 'Settings', 'Store ka email set nahi', 'Settings mein email add karein');
      if (shop.myshopify_domain === shop.domain) add('medium', 'Branding', 'Custom domain nahi (abhi .myshopify.com par)',
        'Apna domain lein — bharosa bohat barh jata hai (saal ka ~$10-15)');

      /* ---- SCORE ---- */
      const w = { critical: 22, high: 11, medium: 5, low: 2 };
      const score = Math.max(0, 100 - P.reduce((s, i) => s + (w[i.sev] || 4), 0));
      const order = { critical: 0, high: 1, medium: 2, low: 3 };
      P.sort((a, b) => order[a.sev] - order[b.sev]);

      const result = {
        store: shop.name, domain: shop.domain, currency: shop.currency, country: shop.country_name,
        health_score: score,
        grade: score >= 90 ? 'A — launch ke liye tayar 🚀' : score >= 75 ? 'B — thora kaam baqi' :
               score >= 55 ? 'C — kaafi kaam chahiye' : score >= 35 ? 'D — abhi launch na karein' : 'F — buniyadi cheezein missing',
        stats: {
          products: prods.length, active: active.length, drafts: drafts.length,
          pages: pages.length, collections: colls.length,
          orders_total: orders.length, unfulfilled: unf.length,
          out_of_stock: oos.length, low_stock: low.length,
          live_theme: live?.name
        },
        counts: {
          critical: P.filter(x => x.sev === 'critical').length,
          high: P.filter(x => x.sev === 'high').length,
          medium: P.filter(x => x.sev === 'medium').length,
          low: P.filter(x => x.sev === 'low').length
        },
        problems: P,
        auto_fixable: P.filter(x => x.auto_fix_tool).length,
        deliverable: `Scan result ko user ke saamne SAAF pesh karein:
1. **Health Score /100** aur grade (bara likhein)
2. **🔴 Critical** masail — inke baghair store nahi chal sakti
3. **🟠 High** — sales par asar
4. **🟡 Medium / ⚪ Low** — mukhtasar
5. Aakhir mein poochein: **"Main yeh sab abhi khud theek kar dun?"**
Agar user haan kahe to \`auto_fix_all\` chalayein.`
      };
      if (typeof Cache !== 'undefined') Cache.put('audit', { health_score: score, issues_found: P.slice(0, 20) });
      return result;
    }
  },

  /* ================= AUTO FIX ================= */
  auto_fix_all: {
    desc: 'AUTO-FIX — jo bhi masail khud theek ho sakte hain, sab theek kar deta hai: pages banata hai, policies lagata hai, footer align karta hai, menu bharta hai, discount banata hai. User ki ijazat ke baad chalayein.',
    params: { skip: 'comma separated jo skip karne hain, e.g. discount' },
    run: async (a = {}) => {
      const skip = String(a.skip || '').toLowerCase().split(',').map(s => s.trim());
      const done = [], failed = [];
      const c = (typeof ctxOf === 'function') ? ctxOf() : {};

      // refresh context so generated content uses real store data
      try {
        const sh = await Shop.rest('/shop.json').then(r => r.shop);
        if (typeof Cache !== 'undefined') Cache.put('shop', sh);
        Object.assign(c, { name: sh.name, domain: sh.domain, email: sh.email,
          country: sh.country_name, currency: sh.currency, city: sh.city });
      } catch (_) { }
      try {
        const n = await TOOLS.detect_store_niche.run();
        if (typeof Cache !== 'undefined') Cache.put('niche', n);
        c.category = (n.categories?.[0] || '').replace(/\s*\(\d+\)/, '') || 'products';
        c.samples = n.sample_products || [];
      } catch (_) { }

      const pages = await Shop.rest('/pages.json?limit=250').then(r => r.pages).catch(() => []);
      const has = k => pages.some(p => (p.handle || '').includes(k));

      /* 1. PAGES */
      const wantPages = [
        { k: 'contact', title: 'Contact Us', handle: 'contact', gen: 'contact' },
        { k: 'about', title: 'About Us', handle: 'about-us', gen: 'about' },
        { k: 'faq', title: 'FAQ', handle: 'faq', gen: 'faq' }
      ];
      for (const p of wantPages) {
        if (skip.includes(p.k) || has(p.k)) continue;
        try {
          const html = GEN[p.gen](c);
          const r = await TOOLS.create_page.run({ title: p.title, handle: p.handle, body_html: html, published: true });
          done.push({ task: p.title + ' page banaya', url: r.url });
        } catch (e) { failed.push({ task: p.title + ' page', error: e.message }); }
      }

      /* 2. POLICIES */
      const pol = [
        { t: 'REFUND_POLICY', g: 'refund', n: 'Refund Policy' },
        { t: 'SHIPPING_POLICY', g: 'shipping', n: 'Shipping Policy' },
        { t: 'PRIVACY_POLICY', g: 'privacy', n: 'Privacy Policy' },
        { t: 'TERMS_OF_SERVICE', g: 'terms', n: 'Terms of Service' }
      ];
      for (const p of pol) {
        if (skip.includes('policy') || skip.includes('policies')) break;
        try {
          await TOOLS.update_policy.run({ type: p.t, body: GEN[p.g](c) });
          done.push({ task: p.n + ' set ki' });
        } catch (e) { failed.push({ task: p.n, error: e.message }); }
      }

      /* 3. FOOTER ALIGNMENT */
      if (!skip.includes('footer')) {
        try {
          const r = await TOOLS.fix_footer_alignment.run({ style: 'grid', mobile_center: true });
          done.push({ task: 'Footer align kiya (desktop + mobile)', file: r.file });
        } catch (e) { failed.push({ task: 'Footer alignment', error: e.message }); }
      }

      /* 4. FOOTER MENU */
      if (!skip.includes('menu')) {
        try {
          const r = await TOOLS.auto_fix_footer_menu.run({});
          done.push({ task: 'Footer menu mein links add kiye', links: r.links_added });
        } catch (e) { failed.push({ task: 'Footer menu', error: e.message }); }
      }

      /* 5. WELCOME DISCOUNT */
      if (!skip.includes('discount')) {
        try {
          const d = await Shop.rest('/price_rules.json?limit=20').then(r => r.price_rules).catch(() => []);
          if (!d.length) {
            const r = await TOOLS.create_discount.run({ code: 'WELCOME10', type: 'percentage', value: 10 });
            done.push({ task: 'Welcome discount banaya: ' + r.code + ' (10% off)' });
          }
        } catch (e) { failed.push({ task: 'Discount', error: e.message }); }
      }

      /* 6. TRUST BADGES CSS */
      if (!skip.includes('trust')) {
        try {
          await TOOLS.add_theme_css.run({
            label: 'echo polish',
            css: `/* ECHO: buttons, spacing, mobile polish */
.button, .btn, button[type="submit"], .shopify-payment-button__button {
  border-radius: 8px !important; font-weight: 600 !important; letter-spacing: .01em !important;
  transition: transform .12s ease, box-shadow .12s ease !important;
}
.button:hover, .btn:hover, .shopify-payment-button__button:hover {
  transform: translateY(-1px) !important; box-shadow: 0 6px 18px rgba(0,0,0,.14) !important;
}
.product__title, .product-single__title { line-height: 1.25 !important; }
.price, .product__price { font-weight: 700 !important; }
img { image-rendering: auto !important; }
@media screen and (max-width: 749px) {
  .product__info-container, .product-single__meta { padding: 0 14px !important; }
  h1, .h1 { font-size: 1.5rem !important; line-height: 1.3 !important; }
  .button, .btn { width: 100% !important; padding: 14px !important; font-size: 16px !important; }
}`
          });
          done.push({ task: 'Store polish CSS lagayi (buttons, mobile spacing)' });
        } catch (e) { failed.push({ task: 'Polish CSS', error: e.message }); }
      }

      return {
        completed: done.length, failed: failed.length,
        done, failed,
        deliverable: `Batayein ke kya kya theek ho gaya (✅ list) aur kya reh gaya (❌ + wajah).
Phir batayein ke jo cheezein SIRF INSAAN kar sakta hai wo kya hain:
- Product ki tasveerein upload karna
- Custom domain kharidna
- Payment gateway connect karna
- Social media accounts banana
Aakhir mein poochein: "Ab main product descriptions likh dun?" ya "Launch plan banaun?"`
      };
    }
  },

  auto_fix_footer_menu: {
    desc: 'Footer menu mein zaroori links khud add karta hai — jo pages mojood hain unke.',
    params: {},
    run: async () => {
      const pages = await Shop.rest('/pages.json?limit=250').then(r => r.pages).catch(() => []);
      const links = [];
      const want = [
        ['about', 'About Us'], ['contact', 'Contact'], ['faq', 'FAQ'],
        ['shipping', 'Shipping'], ['refund', 'Returns'], ['return', 'Returns'],
        ['privacy', 'Privacy Policy'], ['terms', 'Terms']
      ];
      const seen = new Set();
      want.forEach(([k, label]) => {
        const p = pages.find(x => (x.handle || '').includes(k));
        if (p && !seen.has(label)) { seen.add(label); links.push({ title: label, url: '/pages/' + p.handle }); }
      });
      // policies live at /policies/*
      const pol = [['/policies/refund-policy', 'Refund Policy'], ['/policies/shipping-policy', 'Shipping Policy'],
                   ['/policies/privacy-policy', 'Privacy Policy'], ['/policies/terms-of-service', 'Terms of Service']];
      pol.forEach(([u, t]) => { if (!seen.has(t) && links.length < 8) { seen.add(t); links.push({ title: t, url: u }); } });

      if (!links.length) throw new Error('Koi page nahi mila — pehle pages banayein.');
      const r = await TOOLS.update_menu.run({ handle: 'footer', title: 'Footer menu', items: links });
      return { ok: true, links_added: links.length, links: r.links };
    }
  },

  bulk_fix_descriptions: {
    desc: 'Jin products ki description khali/choti hai, unki list deta hai taake ek ek ki achhi description likhi ja sake.',
    params: { limit: 'kitne products, default 10' },
    run: async (a = {}) => {
      const prods = await Shop.rest('/products.json?limit=250').then(r => r.products);
      const bad = prods.filter(p => stripTags(p.body_html || '').length < 100)
        .slice(0, parseInt(a.limit) || 10);
      const niche = await TOOLS.detect_store_niche.run().catch(() => ({}));
      return {
        needs_description: bad.length,
        products: bad.map(p => ({
          id: p.id, title: p.title, type: p.product_type, vendor: p.vendor,
          price: p.variants?.[0]?.price, current_words: stripTags(p.body_html || '').split(/\s+/).filter(Boolean).length
        })),
        store_context: { name: niche.store, currency: niche.currency, country: niche.country, category: niche.categories?.[0] },
        deliverable: `Har product ke liye ek PROFESSIONAL description likhein aur \`write_product_description\` se save karein.
Format: <h2>title</h2>, hook paragraph, <h3>✨ Khaas Baatein</h3> (4-5 benefit bullets — feature nahi, BENEFIT),
<h3>📦 Aap ko kya milega</h3>, <h3>🚚 Delivery aur Wapsi</h3>, aakhir mein halka urgency line.
Zabaan customer wali ho. SEO title aur meta description bhi dein. Ek ek kar ke karein.`
      };
    }
  },

  /* ================= LAUNCH ================= */
  launch_readiness: {
    desc: 'Store launch ke liye tayar hai ya nahi — poori checklist score ke saath. Launch se pehle yeh zaroor chalayein.',
    params: {},
    run: async () => {
      const scan = await TOOLS.deep_scan.run();
      const blockers = scan.problems.filter(p => p.sev === 'critical');
      const shouldFix = scan.problems.filter(p => p.sev === 'high');
      return {
        store: scan.store, health_score: scan.health_score, grade: scan.grade,
        ready_to_launch: blockers.length === 0 && scan.health_score >= 70,
        blockers: blockers.map(b => ({ issue: b.issue, why: b.fix, auto_fixable: !!b.auto_fix_tool })),
        should_fix_first: shouldFix.map(b => ({ issue: b.issue, why: b.fix, auto_fixable: !!b.auto_fix_tool })),
        auto_fixable_count: scan.auto_fixable,
        stats: scan.stats,
        human_tasks: [
          'Product ki asli tasveerein upload karein (3-5 per product)',
          'Payment gateway connect + test order karein',
          'Custom domain lagayein (bharosa barhta hai)',
          'Instagram / TikTok / Facebook page banayein',
          'Store ka logo aur favicon lagayein',
          'Mobile par khud poori store check karein'
        ],
        deliverable: `LAUNCH READINESS REPORT dein:
1. **Score /100 + kya launch kar sakte hain?** (haan/nahi saaf batayein)
2. 🚫 **BLOCKERS** — jab tak yeh theek na hon launch na karein
3. ⚠️ **Pehle theek karein** — sales par asar
4. 👤 **Aap ko khud karna hoga** — jo main nahi kar sakta
5. **Timeline** — kitne din mein tayar ho sakti hai
Aakhir mein: "Main abhi ${scan.auto_fixable} cheezein khud theek kar sakta hun. Karun?"`
      };
    }
  },

  launch_plan: {
    desc: 'Store launch ka poora plan — day by day, kya karna hai pehli sale ke liye. Live trends aur research ke saath.',
    params: { launch_date: 'kab launch karna hai, e.g. "1 hafte mein"' },
    run: async (a = {}) => {
      const [ready, niche, trends] = await Promise.all([
        TOOLS.launch_readiness.run().catch(e => ({ error: e.message })),
        TOOLS.detect_store_niche.run().catch(() => ({})),
        TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({}))
      ]);
      const cat = (niche.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const res = await ddg(cat + ' shopify store launch marketing first sales strategy', 6).catch(() => []);
      return {
        store: niche.store, category: cat, country: niche.country, currency: niche.currency,
        readiness: { score: ready.health_score, ready: ready.ready_to_launch, blockers: ready.blockers?.length },
        target_date: a.launch_date || 'jaldi se jaldi',
        trending_now: trends.trending_now?.slice(0, 5),
        market_research: res,
        deliverable: `Poora LAUNCH PLAN banayein — bilkul specific, day by day:

**PHASE 1 — Tayari (Din 1-3)**
Har din ke kaam, kaunsa main kar sakta hun aur kaunsa user

**PHASE 2 — Soft Launch (Din 4-5)**
Doston/family ko, pehle 5 orders, feedback, bugs

**PHASE 3 — LAUNCH DAY**
Ghanta ba ghanta: kya post karna hai, kahan, kya likhna hai (asli text dein)

**PHASE 4 — Pehla Hafta**
Rozana content plan, ad budget, kya monitor karna

**Pehli 10 sales kaise layein** — 7 concrete tareeqe jo ${niche.country || 'Pakistan'} mein chalte hain

**Budget** — ${niche.currency || 'PKR'} mein: kam se kam, theek, aur behtareen — teeno options

Har cheez actionable ho. "Marketing karein" nahi — "Instagram par yeh post karein, yeh caption, yeh hashtags".`
      };
    }
  },

  /* ================= VIRAL ================= */
  viral_kit: {
    desc: 'Viral hone ka poora kit — content ideas, hooks, hashtags, posting schedule. Live trends ke saath.',
    params: { platform: 'instagram | tiktok | facebook | all — default all', product: 'kis product par focus' },
    run: async (a = {}) => {
      const niche = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const cat = a.product || (niche.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const [trends, kw, viral] = await Promise.all([
        TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({})),
        TOOLS.keyword_ideas.run({ seed: cat }).catch(() => ({})),
        ddg(cat + ' viral tiktok instagram reels ideas hooks ' + new Date().getFullYear(), 6).catch(() => [])
      ]);
      const tags = (typeof GEN !== 'undefined') ? GEN.hashtags(cat, niche.country) : {};
      return {
        store: niche.store, category: cat, country: niche.country,
        platform: a.platform || 'all',
        products: niche.sample_products?.slice(0, 8),
        trending_topics: trends.trending_now?.slice(0, 8),
        what_people_search: kw.suggestions?.slice(0, 12),
        viral_research: viral,
        ready_hashtags: tags,
        deliverable: `VIRAL KIT banayein:

**1. 15 CONTENT IDEAS** — har ek ke saath:
   - Hook (pehle 3 second ka text/scene)
   - Kya dikhana hai (shot by shot)
   - Caption (asli text, copy-paste ready)
   - Best hashtags us post ke liye
   - Kyun chalega (wajah)

**2. 30-DIN CALENDAR** — kis din kya post karna hai

**3. HOOKS LIBRARY** — 20 hooks jo scroll rokte hain (${niche.country || 'Pakistan'} audience ke liye)

**4. INFLUENCER PLAN** — kaise dhoondein, kya message bhejein (asli template dein), kitna dein

**5. FREE REACH HACKS** — 10 tareeqe bina paise ke

Sab kuch copy-paste ready ho. Roman Urdu/English mix jo local audience samjhe.`
      };
    }
  },

  hashtag_generator: {
    desc: 'Product ya niche ke liye best hashtags — Instagram, TikTok, Facebook. Copy-paste ready sets.',
    params: { topic: 'product ya niche, khali chhorein to store ka niche', platform: 'instagram | tiktok | all' },
    run: async (a = {}) => {
      let topic = a.topic;
      let country = 'Pakistan';
      if (!topic) {
        const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
        topic = (n.categories?.[0] || 'shopping').replace(/\s*\(\d+\)/, '');
        country = n.country || country;
      }
      const kw = await TOOLS.keyword_ideas.run({ seed: topic }).catch(() => ({}));
      const base = GEN.hashtags(topic, country);
      // keyword-derived tags
      const derived = (kw.suggestions || []).slice(0, 12)
        .map(s => '#' + s.replace(/[^a-z0-9 ]/gi, '').trim().split(/\s+/).join('').toLowerCase())
        .filter(x => x.length > 4 && x.length < 26);
      return {
        topic, country, platform: a.platform || 'all',
        instagram_ready: base.instagram_set.join(' '),
        tiktok_ready: base.tiktok_set.join(' '),
        by_category: { niche: base.niche, local: base.local, broad: base.broad, buyer_intent: base.buyer_intent, engagement: base.engagement },
        from_real_searches: [...new Set(derived)],
        strategy: base.tip,
        deliverable: 'Hashtags saaf blocks mein pesh karein — user seedha copy kar sake. Batayein kaunsa set kis post ke liye hai.'
      };
    }
  },

  product_hunt_kit: {
    desc: 'Product Hunt / Reddit / directories par launch karne ka poora kit — tagline, description, comments.',
    params: { product: 'kya launch kar rahe hain, khali chhorein to store' },
    run: async (a = {}) => {
      const niche = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const what = a.product || niche.store || 'store';
      const res = await ddg('product hunt launch checklist tips successful launch ' + new Date().getFullYear(), 6).catch(() => []);
      return {
        launching: what, store: niche.store, category: niche.categories?.[0], country: niche.country,
        research: res,
        directories: [
          { name: 'Product Hunt', url: 'https://www.producthunt.com/posts/new', note: 'Best din: Tue-Thu, 12:01 AM PST par post karein' },
          { name: 'Reddit r/shopify', url: 'https://reddit.com/r/shopify', note: 'Feedback maangein, promote na karein' },
          { name: 'Reddit r/entrepreneur', url: 'https://reddit.com/r/entrepreneur', note: 'Apni kahani share karein' },
          { name: 'Indie Hackers', url: 'https://www.indiehackers.com', note: 'Journey post karein' },
          { name: 'Betalist', url: 'https://betalist.com', note: 'Early stage ke liye' },
          { name: 'Hacker News (Show HN)', url: 'https://news.ycombinator.com/showhn.html', note: 'Technical audience' },
          { name: 'Facebook Groups', url: '', note: 'Local business + niche groups — sab se zyada asar' },
          { name: 'WhatsApp Groups', url: '', note: 'Pakistan mein sab se taaqatwar channel' }
        ],
        deliverable: `PRODUCT HUNT / LAUNCH KIT banayein:
1. **Tagline** — 60 characters, 5 options
2. **Description** — 260 characters, punchy
3. **Full description** — kahani ke saath
4. **First comment** (maker comment) — sab se ahem, poora likhein
5. **Gallery plan** — kaunsi 5 images/screenshots
6. **Reddit post** — title + body, har subreddit ke liye alag (promotional na lage)
7. **Facebook/WhatsApp group message** — copy paste ready
8. **Launch day timeline** — ghanta ba ghanta
Sab copy-paste ready ho.`
      };
    }
  },

  /* ================= WATCHDOG ================= */
  store_watch: {
    desc: 'Store par nazar — pichli baar se kya badla, kya naya masla aaya, kya urgent hai. Rozana chalayein.',
    params: {},
    run: async () => {
      const scan = await TOOLS.deep_scan.run();
      const prev = (typeof Cache !== 'undefined') ? Cache.get('watch') : null;
      const now = {
        score: scan.health_score, critical: scan.counts.critical, high: scan.counts.high,
        products: scan.stats.products, orders: scan.stats.orders_total,
        unfulfilled: scan.stats.unfulfilled, oos: scan.stats.out_of_stock
      };
      const changes = [];
      if (prev?.v) {
        const p = prev.v;
        const d = (a, b, label, good) => {
          if (a !== b) changes.push({ metric: label, from: b, to: a, direction: (a > b) === !!good ? 'behtar' : 'kharab' });
        };
        d(now.score, p.score, 'Health score', true);
        d(now.orders, p.orders, 'Total orders', true);
        d(now.unfulfilled, p.unfulfilled, 'Bhejne wale orders', false);
        d(now.oos, p.oos, 'Out of stock', false);
        d(now.critical, p.critical, 'Critical masail', false);
      }
      if (typeof Cache !== 'undefined') Cache.put('watch', now);
      const urgent = scan.problems.filter(p => p.sev === 'critical' || p.sev === 'high').slice(0, 6);
      return {
        checked_at: new Date().toLocaleString(),
        since_last_check: prev ? Cache.ago(prev.age) : 'pehli baar',
        current: now,
        changes: changes.length ? changes : 'koi tabdeeli nahi',
        urgent_now: urgent,
        auto_fixable: scan.auto_fixable,
        deliverable: `Ek mukhtasar WATCH REPORT dein — jaise ek manager 30 second mein batata hai:
- 📊 Score aur kya badla (upar/neeche arrow ke saath)
- 🚨 Kya urgent hai abhi
- ✅ Kya theek chal raha hai
- 👉 Aaj ka 1 sab se ahem kaam
Mukhtasar rakhein. Agar auto-fixable masail hain to poochein.`
      };
    }
  }
});
