/* ============================================================
   research.js — Live web intelligence
   Web search, Google Trends, page reading, competitor analysis.
   Sab free endpoints, koi API key nahi chahiye.
   Native bridge se calls jati hain (CORS free).
   ============================================================ */

/* ---------- helpers ---------- */
const stripTags = h => String(h || '')
  .replace(/<script[\s\S]*?<\/script>/gi, ' ')
  .replace(/<style[\s\S]*?<\/style>/gi, ' ')
  .replace(/<[^>]+>/g, ' ')
  .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"')
  .replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/\s+/g, ' ').trim();

const UA = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
  'Accept-Language': 'en-US,en;q=0.9'
};

const xtag = (block, tag) => {
  const m = block.match(new RegExp('<' + tag + '>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?<\\/' + tag + '>'));
  return m ? stripTags(m[1]) : '';
};

/* ---------- Engine 1: Bing RSS (sabse reliable, no key) ---------- */
async function bingRss(query, max) {
  const url = 'https://www.bing.com/search?q=' + encodeURIComponent(query) +
    '&format=rss&count=' + (max || 8);
  const r = await nreq('GET', url, UA, null);
  const out = [];
  const re = /<item>([\s\S]*?)<\/item>/g; let m;
  while ((m = re.exec(r.body || '')) && out.length < (max || 8)) {
    const b = m[1];
    const t = xtag(b, 'title'), l = xtag(b, 'link');
    if (t && l) out.push({ title: t, url: l, snippet: xtag(b, 'description').slice(0, 320), date: xtag(b, 'pubDate') });
  }
  return out;
}

/* ---------- Engine 2: DuckDuckGo HTML ---------- */
async function ddgHtml(query, max) {
  const out = [];
  for (const ep of ['https://html.duckduckgo.com/html/?q=', 'https://lite.duckduckgo.com/lite/?q=']) {
    try {
      const r = await nreq('GET', ep + encodeURIComponent(query), UA, null);
      const html = r.body || '';
      const re = /<a[^>]+class="result[_-][al][^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
      let m;
      while ((m = re.exec(html)) && out.length < (max || 8)) {
        let link = m[1];
        const u = link.match(/uddg=([^&]+)/); if (u) link = decodeURIComponent(u[1]);
        if (!/^https?:/.test(link)) continue;
        const title = stripTags(m[2]);
        if (title) out.push({ title, url: link, snippet: '' });
      }
      // attach snippets if present
      const sn = [...html.matchAll(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g)].map(x => stripTags(x[1]));
      out.forEach((o, i) => { if (sn[i]) o.snippet = sn[i].slice(0, 320); });
      if (out.length) break;
    } catch (_) { }
  }
  return out;
}

/* ---------- Engine 3: Google News RSS (khabrein / taza) ---------- */
async function newsRss(query, max) {
  const url = 'https://news.google.com/rss/search?q=' + encodeURIComponent(query) + '&hl=en&gl=PK&ceid=PK:en';
  const r = await nreq('GET', url, UA, null);
  const out = [];
  const re = /<item>([\s\S]*?)<\/item>/g; let m;
  while ((m = re.exec(r.body || '')) && out.length < (max || 8)) {
    const b = m[1];
    out.push({ title: xtag(b, 'title'), url: xtag(b, 'link'), snippet: xtag(b, 'description').slice(0, 250), date: xtag(b, 'pubDate') });
  }
  return out;
}

/* ---------- unified search with fallbacks ---------- */
const JUNK = /^(?:https?:\/\/)?(?:www\.)?(bestbuy|ebay|walmart|target|aliexpress|wikipedia|pinterest|indeed|linkedin)\.[a-z.]+\/?$/i;

async function ddg(query, max) {
  const n = max || 8;
  const [a, b] = await Promise.all([
    bingRss(query, n + 4).catch(() => []),
    ddgHtml(query, n + 4).catch(() => [])
  ]);
  let res = [...a, ...b];
  if (res.length < 3) { try { res = res.concat(await newsRss(query, n)); } catch (_) { } }

  // drop homepage-only junk results
  res = res.filter(x => x.url && !JUNK.test(x.url.replace(/\/$/, '')));

  // rank: how many query words appear in title+snippet
  const words = query.toLowerCase().replace(/["']/g, '').split(/\s+/).filter(w => w.length > 2);
  res.forEach(x => {
    const hay = (x.title + ' ' + (x.snippet || '')).toLowerCase();
    x._s = words.reduce((s, w) => s + (hay.includes(w) ? 1 : 0), 0) + (x.snippet ? 0.5 : 0);
  });
  res.sort((x, y) => y._s - x._s);

  // agar achhe results mil rahe hain to bilkul ghair-mutalliq (score 0-1) phenk dein
  const best = res[0] ? res[0]._s : 0;
  if (best >= 2) res = res.filter(x => x._s >= Math.min(2, best * 0.4));

  const seen = new Set();
  return res.filter(x => !seen.has(x.url) && seen.add(x.url))
            .slice(0, n)
            .map(({ _s, ...r }) => r);
}

/* ---------- read any page as clean text ---------- */
async function readPage(url, limit) {
  if (!/^https?:\/\//.test(url)) url = 'https://' + url;
  const lim = limit || 6000;
  // 1) direct fetch (fastest, works for most stores)
  try {
    const r = await nreq('GET', url, UA, null);
    if (r.status >= 200 && r.status < 400 && r.body) {
      const t = stripTags(r.body);
      if (t.length > 40) return t.slice(0, lim);
    }
  } catch (_) { }
  // 2) jina reader fallback (clean markdown)
  try {
    const r = await nreq('GET', 'https://r.jina.ai/' + url, UA, null);
    if (r.status >= 200 && r.status < 300 && r.body && r.body.length > 60 && !/^\s*<!doctype/i.test(r.body))
      return r.body.slice(0, lim);
  } catch (_) { }
  throw new Error('Page parh nahi saka: ' + url);
}

/* ============================================================
   RESEARCH TOOLS
   ============================================================ */
Object.assign(TOOLS, {

  web_search: {
    desc: 'Live internet search — koi bhi maloomat, competitor, product idea, market info, khabrein. Hamesha taza data.',
    params: { query: 'required search text', max: 'kitne results, default 8' },
    run: async (a = {}) => {
      if (!a.query) throw new Error('query zaroori hai');
      const res = await ddg(a.query, parseInt(a.max) || 8);
      if (!res.length) return { query: a.query, note: 'Koi result nahi mila, dusre alfaz try karein', results: [] };
      return { query: a.query, count: res.length, results: res };
    }
  },

  read_webpage: {
    desc: 'Kisi bhi webpage/competitor store ka pura text parhein — pricing, product info, copy, policies.',
    params: { url: 'required', limit: 'characters, default 6000' },
    run: async (a = {}) => {
      if (!a.url) throw new Error('url zaroori hai');
      const t = await readPage(a.url, parseInt(a.limit) || 6000);
      return { url: a.url, length: t.length, content: t };
    }
  },

  google_trends: {
    desc: 'Google par abhi kya trend kar raha hai — country wise. Naye product ideas aur ad angles ke liye.',
    params: { geo: 'country code: PK, US, GB, IN, AE — default PK' },
    run: async (a = {}) => {
      const geo = (a.geo || 'PK').toUpperCase();
      const r = await nreq('GET', 'https://trends.google.com/trending/rss?geo=' + geo, UA, null);
      const xml = r.body || '';
      const items = [];
      const re = /<item>([\s\S]*?)<\/item>/g; let m;
      while ((m = re.exec(xml)) && items.length < 20) {
        const b = m[1];
        const g = t => { const x = b.match(new RegExp('<' + t + '>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?<\\/' + t + '>')); return x ? stripTags(x[1]) : ''; };
        items.push({
          topic: g('title'),
          traffic: g('ht:approx_traffic') || b.match(/approx_traffic>([^<]+)/)?.[1] || '',
          news: g('ht:news_item_title')
        });
      }
      if (!items.length) throw new Error('Trends load nahi hue. Dusra geo try karein (US/PK/IN).');
      return { geo, count: items.length, trending_now: items };
    }
  },

  keyword_ideas: {
    desc: 'Kisi keyword par log Google/Amazon par aur kya search karte hain — SEO aur ad targeting ke liye.',
    params: { seed: 'required base keyword', market: 'google|amazon|youtube, default google' },
    run: async (a = {}) => {
      if (!a.seed) throw new Error('seed keyword zaroori hai');
      const src = { google: 'chrome', amazon: 'amazon-intl', youtube: 'yt' }[a.market || 'google'] || 'chrome';
      const url = 'https://suggestqueries.google.com/complete/search?client=' + src +
        '&q=' + encodeURIComponent(a.seed) + '&hl=en';
      const r = await nreq('GET', url, UA, null);
      let ideas = [];
      try {
        const j = JSON.parse(r.body.replace(/^[^\[]*/, ''));
        ideas = (j[1] || []).slice(0, 20);
      } catch (_) {
        ideas = [...(r.body || '').matchAll(/"([^"]{3,60})"/g)].map(x => x[1]).slice(0, 20);
      }
      // question modifiers
      const qs = [];
      for (const p of ['how to ', 'best ', 'cheap ', 'why ']) {
        try {
          const rr = await nreq('GET', 'https://suggestqueries.google.com/complete/search?client=chrome&q=' +
            encodeURIComponent(p + a.seed), UA, null);
          const jj = JSON.parse(rr.body.replace(/^[^\[]*/, ''));
          qs.push(...(jj[1] || []).slice(0, 5));
        } catch (_) { }
      }
      return { seed: a.seed, market: a.market || 'google', suggestions: ideas, long_tail: [...new Set(qs)].slice(0, 20) };
    }
  },

  spy_competitor: {
    desc: 'Kisi competitor Shopify store ko analyse karein — unke products, prices, best sellers. Public JSON se.',
    params: { domain: 'required, e.g. allbirds.com', limit: 'products, default 30' },
    run: async (a = {}) => {
      if (!a.domain) throw new Error('domain zaroori hai');
      let d = a.domain.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      const lim = Math.min(parseInt(a.limit) || 30, 250);
      const r = await nreq('GET', 'https://' + d + '/products.json?limit=' + lim, UA, null);
      let j; try { j = JSON.parse(r.body); } catch { throw new Error(d + ' Shopify store nahi lagti (ya products.json band hai).'); }
      if (!j.products) throw new Error('Products nahi mile — shayad yeh Shopify store nahi.');
      const ps = j.products.map(p => ({
        title: p.title, type: p.product_type, vendor: p.vendor,
        price: p.variants?.[0]?.price, compare_at: p.variants?.[0]?.compare_at_price,
        variants: p.variants?.length, tags: (p.tags || []).slice(0, 6), published: p.published_at
      }));
      const prices = ps.map(p => parseFloat(p.price)).filter(x => x > 0);
      const types = {}; ps.forEach(p => { if (p.type) types[p.type] = (types[p.type] || 0) + 1; });
      return {
        store: d, products_found: ps.length,
        price_range: prices.length ? { min: Math.min(...prices).toFixed(2), max: Math.max(...prices).toFixed(2), avg: (prices.reduce((x, y) => x + y, 0) / prices.length).toFixed(2) } : null,
        top_categories: Object.entries(types).sort((x, y) => y[1] - x[1]).slice(0, 8).map(([k, v]) => k + ' (' + v + ')'),
        newest_products: ps.slice(0, 10),
        note: 'Naye products aksar unke winning tests hote hain.'
      };
    }
  },

  find_winning_products: {
    desc: 'Trending / winning product ideas dhoondein — niche ke hisaab se, live web data se.',
    params: { niche: 'e.g. skincare, fitness, home decor', geo: 'country, default PK' },
    run: async (a = {}) => {
      const n = a.niche || 'ecommerce';
      const yr = new Date().getFullYear();
      const [s1, s2, kw] = await Promise.all([
        ddg('best selling ' + n + ' products ' + yr + ' trending dropshipping', 6).catch(() => []),
        ddg('"' + n + '" viral products tiktok ' + yr + ' shopify winning', 6).catch(() => []),
        TOOLS.keyword_ideas.run({ seed: 'buy ' + n }).catch(() => ({ suggestions: [] }))
      ]);
      let trends = [];
      try { trends = (await TOOLS.google_trends.run({ geo: a.geo || 'PK' })).trending_now.slice(0, 10); } catch (_) { }
      return {
        niche: n, year: yr,
        market_research: [...s1, ...s2].slice(0, 10),
        demand_keywords: kw.suggestions,
        trending_in_country: trends,
        note: 'In signals ko mila kar 5-7 solid product ideas tajweez karein, har ek ke saath wajah, target audience, aur price point.'
      };
    }
  },

  ad_intelligence: {
    desc: 'Kisi niche/brand ke chalte hue ads aur ad angles research karein — Facebook Ad Library aur web se.',
    params: { niche: 'required niche ya brand', country: 'default PK' },
    run: async (a = {}) => {
      const n = a.niche || 'ecommerce';
      const [r1, r2] = await Promise.all([
        ddg(n + ' facebook ads examples high converting copy ' + new Date().getFullYear(), 6).catch(() => []),
        ddg(n + ' tiktok ad hook script viral ugc', 6).catch(() => [])
      ]);
      return {
        niche: n, country: a.country || 'PK',
        ad_research: r1, creative_research: r2,
        ad_library: 'https://www.facebook.com/ads/library/?q=' + encodeURIComponent(n) + '&country=' + (a.country || 'PK'),
        note: 'In insights se winning hooks, angles aur offers nikalein.'
      };
    }
  }
});
