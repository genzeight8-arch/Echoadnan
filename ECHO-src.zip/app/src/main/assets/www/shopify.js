/* ============================================================
   shopify.js — Shopify Admin API layer + agent TOOLS
   All calls go through the native bridge (no CORS problems).
   ============================================================ */

/* ---------- native fetch bridge ---------- */
const __pending = {};
let __seq = 0;
window.__nativeResolve = function (payloadStr) {
  try {
    const p = JSON.parse(payloadStr);
    const cb = __pending[p.id];
    if (cb) { delete __pending[p.id]; cb({ status: p.status, body: p.body }); }
  } catch (e) { console.error(e); }
};
const HAS_NATIVE = typeof Native !== 'undefined' && Native.request;

function nreq(method, url, headers, body) {
  return new Promise((resolve, reject) => {
    if (!HAS_NATIVE) {
      // browser fallback (works for AI providers, Shopify will hit CORS)
      fetch(url, { method, headers, body })
        .then(async r => resolve({ status: r.status, body: await r.text() }))
        .catch(e => reject(new Error(e.message)));
      return;
    }
    const id = 'r' + (++__seq) + '_' + Date.now();
    __pending[id] = resolve;
    setTimeout(() => { if (__pending[id]) { delete __pending[id]; reject(new Error('Request timeout')); } }, 130000);
    Native.request(id, method, url, JSON.stringify(headers || {}), body || '');
  });
}

/* ---------- Shopify client ---------- */
const API_VERSION = '2024-10';

const Shop = {
  get cfg() { return Store.get().shop; },

  ok() { const c = this.cfg; return !!(c.domain && c.token); },

  base() {
    let d = (this.cfg.domain || '').trim()
      .replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (d && !d.includes('.')) d += '.myshopify.com';
    return 'https://' + d + '/admin/api/' + API_VERSION;
  },

  headers() {
    return {
      'X-Shopify-Access-Token': this.cfg.token.trim(),
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  },

  async rest(path, method = 'GET', body = null) {
    if (!this.ok()) throw new Error('Shopify store connected nahi hai. Settings mein domain + admin token daalein.');
    const url = this.base() + path;
    const r = await nreq(method, url, this.headers(), body ? JSON.stringify(body) : null);
    let j; try { j = JSON.parse(r.body || '{}'); } catch { j = { raw: r.body }; }
    if (r.status < 200 || r.status >= 300) {
      const msg = j.errors ? (typeof j.errors === 'string' ? j.errors : JSON.stringify(j.errors))
                           : (j.error || ('HTTP ' + r.status));
      throw new Error('Shopify: ' + msg);
    }
    return j;
  },

  async gql(query, variables) {
    if (!this.ok()) throw new Error('Shopify store connected nahi hai.');
    const r = await nreq('POST', this.base() + '/graphql.json', this.headers(),
      JSON.stringify({ query, variables: variables || {} }));
    const j = JSON.parse(r.body || '{}');
    if (j.errors) throw new Error('Shopify GraphQL: ' + JSON.stringify(j.errors));
    return j.data;
  }
};

/* ---------- helpers ---------- */
const money = (a, c) => (c || '') + ' ' + Number(a || 0).toLocaleString(undefined, { minimumFractionDigits: 2 });
const dt = s => s ? new Date(s).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const short = (s, n) => !s ? '' : (s.length > n ? s.slice(0, n) + '…' : s);

/* ============================================================
   TOOLS — the agent can call these
   ============================================================ */
const TOOLS = {

  /* ---------- SHOP ---------- */
  get_shop_info: {
    desc: 'Store ki basic maloomat: naam, email, currency, plan, address, timezone.',
    params: {},
    run: async () => {
      const s = (await Shop.rest('/shop.json')).shop;
      return {
        name: s.name, domain: s.domain, myshopify: s.myshopify_domain, email: s.email,
        currency: s.currency, plan: s.plan_display_name, country: s.country_name,
        city: s.city, timezone: s.iana_timezone, created: s.created_at
      };
    }
  },

  /* ---------- PRODUCTS ---------- */
  list_products: {
    desc: 'Products ki list. Filters: limit (max 250), status (active/draft/archived), vendor, product_type, title search.',
    params: { limit: 'number 1-250, default 20', status: 'active|draft|archived', vendor: 'string', product_type: 'string', title: 'search text' },
    run: async (a = {}) => {
      const q = new URLSearchParams();
      q.set('limit', Math.min(Math.max(parseInt(a.limit) || 20, 1), 250));
      ['status', 'vendor', 'product_type', 'title'].forEach(k => { if (a[k]) q.set(k, a[k]); });
      const d = await Shop.rest('/products.json?' + q);
      return {
        count: d.products.length,
        products: d.products.map(p => ({
          id: p.id, title: p.title, status: p.status, vendor: p.vendor, type: p.product_type,
          price: p.variants?.[0]?.price, sku: p.variants?.[0]?.sku,
          inventory: p.variants?.reduce((s, v) => s + (v.inventory_quantity || 0), 0),
          variants: p.variants?.length, image: p.image?.src, handle: p.handle, updated: p.updated_at
        }))
      };
    }
  },

  get_product: {
    desc: 'Ek product ki poori tafseel — id ya title se.',
    params: { id: 'product id', title: 'exact ya partial title' },
    run: async (a = {}) => {
      let p;
      if (a.id) p = (await Shop.rest('/products/' + a.id + '.json')).product;
      else {
        const d = await Shop.rest('/products.json?limit=250');
        p = d.products.find(x => x.title.toLowerCase().includes(String(a.title || '').toLowerCase()));
        if (!p) throw new Error('Product nahi mila: ' + a.title);
      }
      return {
        id: p.id, title: p.title, status: p.status, description: short(String(p.body_html || '').replace(/<[^>]+>/g, ''), 500),
        vendor: p.vendor, type: p.product_type, tags: p.tags, handle: p.handle,
        images: p.images?.length, image: p.image?.src,
        variants: p.variants?.map(v => ({
          id: v.id, title: v.title, sku: v.sku, price: v.price, compare_at: v.compare_at_price,
          stock: v.inventory_quantity, inventory_item_id: v.inventory_item_id, barcode: v.barcode
        })),
        created: p.created_at, updated: p.updated_at
      };
    }
  },

  create_product: {
    desc: 'Naya product banayein.',
    params: { title: 'required', body_html: 'description', price: 'string', sku: 'string', vendor: 'string', product_type: 'string', tags: 'comma separated', status: 'active|draft', inventory: 'number' },
    run: async (a = {}) => {
      if (!a.title) throw new Error('title zaroori hai');
      const v = { price: String(a.price || '0.00') };
      if (a.sku) v.sku = a.sku;
      if (a.inventory != null) { v.inventory_management = 'shopify'; v.inventory_quantity = parseInt(a.inventory) || 0; }
      const body = { product: { title: a.title, body_html: a.body_html || '', vendor: a.vendor || '', product_type: a.product_type || '', tags: a.tags || '', status: a.status || 'draft', variants: [v] } };
      const p = (await Shop.rest('/products.json', 'POST', body)).product;
      return { ok: true, id: p.id, title: p.title, status: p.status, admin_url: 'https://' + Shop.cfg.domain + '/admin/products/' + p.id };
    }
  },

  update_product: {
    desc: 'Product update karein — title, description, status, tags, ya price.',
    params: { id: 'required product id', title: '', body_html: '', status: 'active|draft|archived', tags: '', vendor: '', price: 'variant price' },
    run: async (a = {}) => {
      if (!a.id) throw new Error('id zaroori hai');
      const prod = { id: a.id };
      ['title', 'body_html', 'status', 'tags', 'vendor', 'product_type'].forEach(k => { if (a[k] != null) prod[k] = a[k]; });
      const r = (await Shop.rest('/products/' + a.id + '.json', 'PUT', { product: prod })).product;
      if (a.price != null && r.variants?.[0]) {
        await Shop.rest('/variants/' + r.variants[0].id + '.json', 'PUT', { variant: { id: r.variants[0].id, price: String(a.price) } });
      }
      return { ok: true, id: r.id, title: r.title, status: r.status };
    }
  },

  delete_product: {
    desc: 'Product delete karein (permanent). Sirf tab jab user saaf kahe.',
    params: { id: 'required' },
    run: async (a = {}) => { await Shop.rest('/products/' + a.id + '.json', 'DELETE'); return { ok: true, deleted: a.id }; }
  },

  /* ---------- ORDERS ---------- */
  list_orders: {
    desc: 'Orders ki list. status: open/closed/any. financial_status: paid/pending/refunded. fulfillment_status: shipped/unshipped/any.',
    params: { limit: 'default 20', status: 'open|closed|cancelled|any', financial_status: '', fulfillment_status: '', created_at_min: 'ISO date' },
    run: async (a = {}) => {
      const q = new URLSearchParams();
      q.set('limit', Math.min(parseInt(a.limit) || 20, 250));
      q.set('status', a.status || 'any');
      ['financial_status', 'fulfillment_status', 'created_at_min', 'created_at_max'].forEach(k => { if (a[k]) q.set(k, a[k]); });
      const d = await Shop.rest('/orders.json?' + q);
      return {
        count: d.orders.length,
        orders: d.orders.map(o => ({
          id: o.id, order: o.name, customer: o.customer ? (o.customer.first_name + ' ' + (o.customer.last_name || '')).trim() : 'Guest',
          email: o.email, total: o.total_price, currency: o.currency,
          payment: o.financial_status, fulfillment: o.fulfillment_status || 'unfulfilled',
          items: o.line_items?.length, created: o.created_at, cancelled: o.cancelled_at
        }))
      };
    }
  },

  track_order: {
    desc: 'Order track karein — order number (#1001), order id, ya customer email se. Tracking number aur shipping status deta hai.',
    params: { order_number: 'e.g. 1001 ya #1001', id: 'order id', email: 'customer email' },
    run: async (a = {}) => {
      let o;
      if (a.id) o = (await Shop.rest('/orders/' + a.id + '.json')).order;
      else {
        const q = new URLSearchParams({ status: 'any', limit: '250' });
        if (a.email) q.set('email', a.email);
        if (a.order_number) q.set('name', String(a.order_number).replace('#', ''));
        const d = await Shop.rest('/orders.json?' + q);
        o = d.orders[0];
        if (!o && a.order_number) {
          const all = await Shop.rest('/orders.json?status=any&limit=250');
          const n = String(a.order_number).replace('#', '');
          o = all.orders.find(x => x.name.replace('#', '') === n || String(x.order_number) === n);
        }
        if (!o) throw new Error('Order nahi mila.');
      }
      const sa = o.shipping_address || {};
      const fl = (o.fulfillments || []).map(f => ({
        status: f.status, shipment_status: f.shipment_status || 'info nahi',
        tracking_company: f.tracking_company, tracking_number: f.tracking_number,
        tracking_url: (f.tracking_urls && f.tracking_urls[0]) || f.tracking_url,
        created: f.created_at, items: f.line_items?.length
      }));
      return {
        order: o.name, id: o.id, placed: o.created_at,
        customer: o.customer ? (o.customer.first_name + ' ' + (o.customer.last_name || '')).trim() : 'Guest',
        email: o.email, phone: o.phone || sa.phone,
        payment_status: o.financial_status,
        fulfillment_status: o.fulfillment_status || 'unfulfilled',
        total: o.total_price + ' ' + o.currency,
        items: o.line_items?.map(l => ({ title: l.title, qty: l.quantity, price: l.price, sku: l.sku })),
        shipping_to: [sa.name, sa.address1, sa.city, sa.province, sa.country, sa.zip].filter(Boolean).join(', '),
        shipments: fl.length ? fl : 'Abhi tak ship nahi hua',
        cancelled: o.cancelled_at || false,
        admin_url: 'https://' + Shop.cfg.domain + '/admin/orders/' + o.id
      };
    }
  },

  fulfill_order: {
    desc: 'Order ko fulfilled mark karein, tracking number ke saath.',
    params: { id: 'order id required', tracking_number: '', tracking_company: '', notify: 'true/false' },
    run: async (a = {}) => {
      if (!a.id) throw new Error('order id zaroori hai');
      const fo = await Shop.rest('/orders/' + a.id + '/fulfillment_orders.json');
      const list = fo.fulfillment_orders?.filter(f => f.status === 'open' || f.status === 'in_progress');
      if (!list?.length) throw new Error('Koi open fulfillment order nahi.');
      const body = {
        fulfillment: {
          line_items_by_fulfillment_order: list.map(f => ({ fulfillment_order_id: f.id })),
          notify_customer: a.notify !== false
        }
      };
      if (a.tracking_number) body.fulfillment.tracking_info = { number: a.tracking_number, company: a.tracking_company || 'Other' };
      const r = await Shop.rest('/fulfillments.json', 'POST', body);
      return { ok: true, status: r.fulfillment?.status, tracking: r.fulfillment?.tracking_number };
    }
  },

  /* ---------- THEMES ---------- */
  list_themes: {
    desc: 'Store ke saare themes ki list — kaunsa live (main) hai, kaunsa unpublished.',
    params: {},
    run: async () => {
      const d = await Shop.rest('/themes.json');
      return {
        count: d.themes.length,
        themes: d.themes.map(t => ({
          id: t.id, name: t.name, role: t.role, live: t.role === 'main',
          theme_store_id: t.theme_store_id, previewable: t.previewable,
          processing: t.processing, created: t.created_at, updated: t.updated_at
        }))
      };
    }
  },

  get_theme_assets: {
    desc: 'Ek theme ki files/assets list karein (liquid templates, css, js).',
    params: { theme_id: 'required', filter: 'e.g. .liquid ya sections/' },
    run: async (a = {}) => {
      if (!a.theme_id) throw new Error('theme_id zaroori hai');
      const d = await Shop.rest('/themes/' + a.theme_id + '/assets.json');
      let list = d.assets.map(x => ({ key: x.key, size: x.size, updated: x.updated_at }));
      if (a.filter) list = list.filter(x => x.key.includes(a.filter));
      return { count: list.length, assets: list.slice(0, 120) };
    }
  },

  publish_theme: {
    desc: 'Kisi theme ko live (main) kar dein.',
    params: { theme_id: 'required' },
    run: async (a = {}) => {
      const t = (await Shop.rest('/themes/' + a.theme_id + '.json', 'PUT', { theme: { id: a.theme_id, role: 'main' } })).theme;
      return { ok: true, id: t.id, name: t.name, role: t.role };
    }
  },

  /* ---------- CUSTOMERS ---------- */
  list_customers: {
    desc: 'Customers ki list ya search (naam/email/phone se).',
    params: { limit: 'default 20', query: 'search text' },
    run: async (a = {}) => {
      const path = a.query
        ? '/customers/search.json?query=' + encodeURIComponent(a.query) + '&limit=' + (a.limit || 20)
        : '/customers.json?limit=' + (a.limit || 20);
      const d = await Shop.rest(path);
      return {
        count: d.customers.length,
        customers: d.customers.map(c => ({
          id: c.id, name: (c.first_name + ' ' + (c.last_name || '')).trim() || '(no name)',
          email: c.email, phone: c.phone, orders: c.orders_count,
          spent: c.total_spent, currency: c.currency, tags: c.tags, created: c.created_at
        }))
      };
    }
  },

  /* ---------- INVENTORY ---------- */
  low_stock: {
    desc: 'Kam stock wale products dhoondein (default threshold 5).',
    params: { threshold: 'number, default 5' },
    run: async (a = {}) => {
      const th = parseInt(a.threshold) || 5;
      const d = await Shop.rest('/products.json?limit=250');
      const low = [];
      d.products.forEach(p => p.variants.forEach(v => {
        if (v.inventory_management === 'shopify' && (v.inventory_quantity || 0) <= th)
          low.push({ product: p.title, variant: v.title, sku: v.sku, stock: v.inventory_quantity, price: v.price, product_id: p.id });
      }));
      low.sort((x, y) => x.stock - y.stock);
      return { threshold: th, count: low.length, items: low.slice(0, 60) };
    }
  },

  /* ---------- ANALYTICS ---------- */
  sales_summary: {
    desc: 'Sales report — total revenue, order count, average order value, top products. days: kitne din ka (default 30).',
    params: { days: 'number, default 30' },
    run: async (a = {}) => {
      const days = parseInt(a.days) || 30;
      const since = new Date(Date.now() - days * 864e5).toISOString();
      const d = await Shop.rest('/orders.json?status=any&limit=250&created_at_min=' + since);
      const os = d.orders.filter(o => !o.cancelled_at);
      const rev = os.reduce((s, o) => s + parseFloat(o.total_price || 0), 0);
      const prod = {};
      os.forEach(o => o.line_items?.forEach(l => {
        const k = l.title;
        prod[k] = prod[k] || { qty: 0, revenue: 0 };
        prod[k].qty += l.quantity;
        prod[k].revenue += parseFloat(l.price) * l.quantity;
      }));
      const top = Object.entries(prod).sort((x, y) => y[1].revenue - x[1].revenue).slice(0, 10)
        .map(([t, v]) => ({ product: t, units: v.qty, revenue: v.revenue.toFixed(2) }));
      const unf = os.filter(o => !o.fulfillment_status).length;
      return {
        period_days: days, currency: os[0]?.currency || '',
        orders: os.length, revenue: rev.toFixed(2),
        avg_order_value: os.length ? (rev / os.length).toFixed(2) : '0',
        paid: os.filter(o => o.financial_status === 'paid').length,
        pending_payment: os.filter(o => o.financial_status === 'pending').length,
        unfulfilled: unf, top_products: top
      };
    }
  },

  /* ---------- DISCOUNTS ---------- */
  create_discount: {
    desc: 'Discount code banayein — percentage ya fixed amount.',
    params: { code: 'required', type: 'percentage|fixed_amount', value: 'number e.g. 10', usage_limit: '', ends_at: 'ISO date' },
    run: async (a = {}) => {
      if (!a.code) throw new Error('code zaroori hai');
      const val = a.type === 'fixed_amount' ? '-' + Math.abs(parseFloat(a.value || 0))
                                            : '-' + Math.abs(parseFloat(a.value || 0));
      const pr = (await Shop.rest('/price_rules.json', 'POST', {
        price_rule: {
          title: a.code, target_type: 'line_item', target_selection: 'all',
          allocation_method: 'across', value_type: a.type === 'fixed_amount' ? 'fixed_amount' : 'percentage',
          value: String(val), customer_selection: 'all',
          usage_limit: a.usage_limit ? parseInt(a.usage_limit) : null,
          starts_at: new Date().toISOString(), ends_at: a.ends_at || null
        }
      })).price_rule;
      const dc = (await Shop.rest('/price_rules/' + pr.id + '/discount_codes.json', 'POST',
        { discount_code: { code: a.code } })).discount_code;
      return { ok: true, code: dc.code, value: pr.value, type: pr.value_type, price_rule_id: pr.id };
    }
  },

  list_discounts: {
    desc: 'Maujooda discount codes / price rules ki list.',
    params: { limit: 'default 20' },
    run: async (a = {}) => {
      const d = await Shop.rest('/price_rules.json?limit=' + (a.limit || 20));
      return {
        count: d.price_rules.length,
        discounts: d.price_rules.map(p => ({
          id: p.id, title: p.title, value: p.value, type: p.value_type,
          starts: p.starts_at, ends: p.ends_at, usage_limit: p.usage_limit
        }))
      };
    }
  },

  /* ---------- COLLECTIONS ---------- */
  list_collections: {
    desc: 'Custom aur smart collections ki list.',
    params: { limit: 'default 30' },
    run: async (a = {}) => {
      const lim = a.limit || 30;
      const [c, s] = await Promise.all([
        Shop.rest('/custom_collections.json?limit=' + lim).catch(() => ({ custom_collections: [] })),
        Shop.rest('/smart_collections.json?limit=' + lim).catch(() => ({ smart_collections: [] }))
      ]);
      const map = x => ({ id: x.id, title: x.title, handle: x.handle, products: x.products_count, published: !!x.published_at });
      return {
        custom: c.custom_collections.map(map),
        smart: s.smart_collections.map(map),
        total: c.custom_collections.length + s.smart_collections.length
      };
    }
  },

  /* ---------- RAW ESCAPE HATCH ---------- */
  shopify_api: {
    desc: 'Koi bhi Shopify Admin REST endpoint call karein jab upar wala tool kaafi na ho. path example: /products/count.json',
    params: { path: 'required, e.g. /orders/count.json', method: 'GET|POST|PUT|DELETE', body: 'JSON object' },
    run: async (a = {}) => {
      if (!a.path) throw new Error('path zaroori hai');
      const p = a.path.startsWith('/') ? a.path : '/' + a.path;
      return await Shop.rest(p, a.method || 'GET', a.body || null);
    }
  }
};

/* tool schema string for the LLM */
function toolsPrompt() {
  return Object.entries(TOOLS).map(([n, t]) => {
    const keys = Object.keys(t.params || {});
    const ps = keys.length ? ' [' + keys.join(', ') + ']' : '';
    const d = String(t.desc || '').split('.')[0].slice(0, 110);
    return `- ${n}${ps}: ${d}`;
  }).join('\n');
}
