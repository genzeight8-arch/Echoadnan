/* ============================================================
   social.js — SOCIAL MEDIA COMMAND CENTER
   WhatsApp · TikTok · Instagram · Facebook
   One-tap posting (100% ToS compliant), collab outreach, ad plans.
   ============================================================ */

/* ---------- which apps are on the phone ---------- */
let APPS = {};
try { APPS = window.Native?.installedApps ? JSON.parse(Native.installedApps()) : {}; } catch (_) { APPS = {}; }

const PLATFORMS = {
  whatsapp:  { name: 'WhatsApp',  icon: '💬', color: '#25D366', best: 'Status + broadcast — Pakistan mein sab se taaqatwar' },
  instagram: { name: 'Instagram', icon: '📸', color: '#E1306C', best: 'Reels + carousel — discovery ke liye' },
  tiktok:    { name: 'TikTok',    icon: '🎵', color: '#000000', best: 'Sab se tez organic reach — 0 followers se bhi viral' },
  facebook:  { name: 'Facebook',  icon: '📘', color: '#1877F2', best: 'Groups + marketplace — Pakistan mein bara buyer base' }
};

/* ---------- post queue (saved locally) ---------- */
const Queue = {
  all() { try { return JSON.parse(localStorage.getItem('echo_queue') || '[]'); } catch { return []; } },
  save(q) { localStorage.setItem('echo_queue', JSON.stringify(q.slice(0, 200))); },
  add(post) {
    const q = this.all();
    q.unshift(Object.assign({ id: 'p' + Date.now() + Math.random().toString(36).slice(2, 6), created: Date.now(), status: 'pending' }, post));
    this.save(q); return q[0];
  },
  addMany(posts) { posts.forEach(p => this.add(p)); return this.all(); },
  mark(id, status) { const q = this.all(); const p = q.find(x => x.id === id); if (p) { p.status = status; p.posted_at = Date.now(); } this.save(q); },
  remove(id) { this.save(this.all().filter(x => x.id !== id)); },
  clear() { localStorage.removeItem('echo_queue'); },
  pending() { return this.all().filter(x => x.status === 'pending'); },
  posted() { return this.all().filter(x => x.status === 'posted'); }
};

/* ---------- ready content packs (work offline) ---------- */
const PACKS = {

  /* 30-day launch calendar — day, platform, type, hook, caption skeleton */
  calendar(store, cat, country) {
    const S = store || 'GENZ8';
    const C = cat || 'products';
    const items = [
      { d: 1,  p: 'all',       t: 'Announcement', title: 'Store launch reveal',      hook: `${S} ab LIVE hai 🚀`, note: 'Pehla post — store ka intro, logo, tagline' },
      { d: 1,  p: 'whatsapp',  t: 'Status',       title: 'WhatsApp status blast',    hook: `Bhai/behen, apna store launch ho gaya 🎉`, note: 'Personal tone — sab contacts dekhenge' },
      { d: 2,  p: 'tiktok',    t: 'Video',        title: 'Behind the scenes',        hook: 'Ye dekho maine kya banaya hai 👀', note: 'Store screen recording + trending audio' },
      { d: 2,  p: 'instagram', t: 'Carousel',     title: 'Top 5 products',           hook: 'Ye 5 cheezein sab se zyada pasand ki ja rahi hain', note: '5 slides, har product 1 slide' },
      { d: 3,  p: 'tiktok',    t: 'Video',        title: 'Packing an order',         hook: 'POV: pehla order aa gaya 📦', note: 'Satisfying packing video — sab se zyada chalta hai' },
      { d: 3,  p: 'facebook',  t: 'Group post',   title: 'Local groups intro',       hook: 'Assalam-o-Alaikum, apna chhota business shuru kiya hai', note: '5 local buy/sell groups mein' },
      { d: 4,  p: 'instagram', t: 'Reel',         title: 'Price reveal',             hook: 'Guess karein ye kitne ka hai? 🤔', note: 'Comments mein guess mangwayein — engagement boost' },
      { d: 4,  p: 'whatsapp',  t: 'Status',       title: 'Product spotlight',        hook: 'Aaj ka pick 👇', note: 'Ek product + price + order link' },
      { d: 5,  p: 'tiktok',    t: 'Video',        title: 'Problem → solution',       hook: `Agar aap bhi ${C} dhoondh dhoondh ke thak gaye hain...`, note: 'Masla dikhayein phir apna hal' },
      { d: 5,  p: 'instagram', t: 'Story',        title: 'Poll: kaunsa behtar?',     hook: 'Aap kaunsa lein ge — A ya B?', note: 'Story poll sticker — algorithm ko pasand hai' },
      { d: 6,  p: 'all',       t: 'Offer',        title: 'Launch discount',          hook: 'WELCOME10 se 10% off — sirf is hafte 🎁', note: 'Urgency ke saath' },
      { d: 7,  p: 'tiktok',    t: 'Video',        title: 'Unboxing',                 hook: 'Unboxing hamara best seller 📦✨', note: 'Close-up shots, ASMR sound' },
      { d: 8,  p: 'instagram', t: 'Reel',         title: 'Before / After',           hook: 'Pehle ye... ab ye 😍', note: 'Transformation content' },
      { d: 9,  p: 'facebook',  t: 'Post',         title: 'Customer question',        hook: 'Aap log kya chahte hain hum next launch karein?', note: 'Engagement bait — comments barhte hain' },
      { d: 10, p: 'whatsapp',  t: 'Broadcast',    title: 'First week thank you',     hook: 'Sab ka shukriya 🙏 pehle hafte mein...', note: 'Social proof' },
      { d: 11, p: 'tiktok',    t: 'Video',        title: 'Day in the life',          hook: 'Ek din chhote business owner ki zindagi mein', note: 'Relatable — log follow karte hain' },
      { d: 12, p: 'instagram', t: 'Carousel',     title: '5 tips',                   hook: `${C} khareedte waqt ye 5 baatein zaroor dekhein`, note: 'Value content — save aur share hota hai' },
      { d: 13, p: 'all',       t: 'UGC',          title: 'Customer review',          hook: 'Hamare customer ne kya kaha 💬', note: 'Screenshot + product photo' },
      { d: 14, p: 'tiktok',    t: 'Video',        title: 'Trending audio',           hook: '(trending sound par apna product)', note: 'Jo audio trend kar raha ho use karein' },
      { d: 15, p: 'instagram', t: 'Reel',         title: 'Restock alert',            hook: 'Wapas aa gaya! Pichli baar 2 din mein khatam 🔥', note: 'Scarcity' },
      { d: 16, p: 'facebook',  t: 'Marketplace',  title: 'Marketplace listing',      hook: '(products marketplace par list karein)', note: 'Bilkul free traffic' },
      { d: 17, p: 'whatsapp',  t: 'Status',       title: 'Mini sale',                hook: 'Aaj sirf — 15% off 🏃‍♂️', note: '24 ghante ka offer' },
      { d: 18, p: 'tiktok',    t: 'Video',        title: 'Myth busting',             hook: `Ye jo sab ${C} ke bare mein kehte hain, ghalat hai`, note: 'Controversial hooks chalte hain' },
      { d: 19, p: 'instagram', t: 'Carousel',     title: 'How to use / style',       hook: 'Isko 3 tareeqon se use karein', note: 'Educational' },
      { d: 20, p: 'all',       t: 'Giveaway',     title: 'Giveaway launch',          hook: '🎁 GIVEAWAY — free product jeetein!', note: 'Follow + tag 2 dost + share = entry' },
      { d: 21, p: 'tiktok',    t: 'Video',        title: 'Comparison',               hook: 'Sasta vs mehnga — farq dekh lein', note: 'Apna product achha dikhayein' },
      { d: 22, p: 'instagram', t: 'Reel',         title: 'Fast delivery proof',      hook: 'Order se delivery — 48 ghante ⚡', note: 'Trust building' },
      { d: 23, p: 'whatsapp',  t: 'Broadcast',    title: 'Loyal customer offer',     hook: 'Sirf hamare purane customers ke liye 💚', note: 'Repeat sales' },
      { d: 24, p: 'facebook',  t: 'Post',         title: 'Behind the scenes',        hook: 'Aaj ke orders pack ho rahe hain 📦', note: 'Authenticity' },
      { d: 25, p: 'tiktok',    t: 'Video',        title: 'Reply to comment',         hook: '(kisi comment ka video reply)', note: 'TikTok isko boost deta hai' },
      { d: 26, p: 'instagram', t: 'Story',        title: 'Q&A sticker',              hook: 'Kuch bhi poochein! 💬', note: 'Direct engagement' },
      { d: 27, p: 'all',       t: 'Milestone',    title: 'Thank you post',           hook: 'X orders complete 🎉 shukriya!', note: 'Social proof' },
      { d: 28, p: 'tiktok',    t: 'Video',        title: 'Top 3 best sellers',       hook: 'Sab se zyada bikne wali 3 cheezein', note: 'Bandwagon effect' },
      { d: 29, p: 'instagram', t: 'Reel',         title: 'Weekend offer',            hook: 'Weekend special — sirf 2 din 🎊', note: 'Urgency' },
      { d: 30, p: 'all',       t: 'Recap',        title: 'First month recap',        hook: 'Pehla mahina mukammal 🥳', note: 'Kahani sunayein — log jurte hain' }
    ];
    return items;
  },

  /* WhatsApp message templates */
  whatsapp(store, cat, currency) {
    const S = store || 'GENZ8';
    return {
      launch_personal: `Assalam-o-Alaikum! 👋\n\nMain ne apna online store shuru kiya hai — *${S}* 🎉\n\nAgar aap ko ${cat || 'kuch'} chahiye ho to zaroor dekhein. Cash on Delivery bhi hai, poore Pakistan mein delivery.\n\n🔗 [store link]\n\nAap ka support hi meri sab se bari madad hai 🙏\nEk baar dekh lein — pasand aaye to share bhi kar dein!`,

      status_launch: `🚀 *${S}* — ab LIVE!\n\n✅ Asli mayaar\n✅ Cash on Delivery\n✅ Poore Pakistan mein delivery\n✅ 7 din wapsi ki suhulat\n\n🎁 Launch offer: WELCOME10 se 10% OFF\n\n🔗 [store link]`,

      status_product: `Aaj ka pick 👇\n\n[Product ka naam]\n💰 ${currency || 'PKR'} [price]\n\n📦 COD available\n🚚 2-4 din mein delivery\n\nOrder karne ke liye message karein 💬`,

      status_offer: `⚡ *SIRF AAJ* ⚡\n\n15% OFF har cheez par!\n\nCode: TODAY15\nRaat 12 baje tak\n\n🔗 [store link]\n\nStock mehdood hai 🏃‍♂️`,

      broadcast_thanks: `Shukriya! 🙏\n\nAap logon ke support se ${S} ko pehle hafte mein zabardast response mila.\n\nAap ke liye ek chhota tohfa: *THANKS15* — 15% off, 3 din ke liye.\n\n🔗 [store link]`,

      order_confirm: `Assalam-o-Alaikum [naam]! 👋\n\nAap ka order confirm ho gaya hai ✅\n\n📦 Order: #[number]\n💰 Total: ${currency || 'PKR'} [amount]\n🚚 Delivery: 2-4 kaam ke din\n\nShip hote hi tracking bhej dunga.\n\nShukriya ke aap ne ${S} ko chuna 💚`,

      order_shipped: `Khushkhabri! 🚚\n\nAap ka order *#[number]* ship ho gaya hai.\n\n📍 Tracking: [number]\n🔗 [tracking link]\n\n2-3 din mein aap ke paas pohanch jayega.\n\nKoi sawal ho to message karein 💬`,

      abandoned_cart: `Assalam-o-Alaikum! 👋\n\nAap ne kuch cheezein cart mein chhori theen — abhi tak available hain 🛒\n\nAgar koi sawal ho to poochein, main madad karunga.\n\n🎁 Chhota sa tohfa: *COMEBACK10* — 10% off\n\n🔗 [cart link]`,

      review_request: `Assalam-o-Alaikum [naam]! 👋\n\nUmeed hai aap ko order pasand aaya hoga 😊\n\nAgar 30 second nikal sakein to ek chhota sa review/photo bhej dein — hamare jaise naye business ke liye bohat maayne rakhta hai 🙏\n\nAgli baar ke liye *REVIEW10* — 10% off aap ke liye 💚`,

      collab_dm: `Assalam-o-Alaikum [naam]! 👋\n\nMain [aap ka naam] hun, *${S}* chalata/chalati hun.\n\nAap ka content bohat pasand aaya — khaas kar [specific post ka zikr karein].\n\nMain aap ko apna [product] *bilkul free* bhejna chahta hun. Pasand aaye to ek honest review/story bana dein — na aaye to koi baat nahi, product aap ka 😊\n\nKoi paisa nahi maangta, sirf asli feedback.\n\nDilchaspi ho to bata dein — main details bhej dunga 🙏`
    };
  },

  /* short-form video scripts */
  videoScripts(store, cat) {
    const S = store || 'GENZ8', C = cat || 'products';
    return [
      { title: 'Unboxing (sab se zyada chalta hai)', len: '15-20s',
        shots: ['0-3s: Band parcel haath mein, "Dekhtay hain andar kya hai 👀"', '3-8s: Dheere dheere kholna — ASMR sound', '8-14s: Product close-up, har angle', '14-18s: Product istemal karte hue', '18-20s: Text overlay "Link bio mein 🔗"'],
        caption: `Unboxing hamara best seller 📦✨\n\nAap ko kaisa laga? Comment karein 👇`, audio: 'Trending calm/satisfying sound' },
      { title: 'Price reveal (engagement king)', len: '10-15s',
        shots: ['0-3s: Product dikhayein, "Guess karein ye kitne ka hai? 🤔"', '3-8s: Product ke features dikhayein', '8-12s: Price reveal — bara text', '12-15s: "Sasta hai na? Link bio mein"'],
        caption: `Guess karein 👇 Sahi jawab dene wale ko 10% off! 🎁`, audio: 'Suspense/drop sound' },
      { title: 'POV / Relatable', len: '10-15s',
        shots: [`0-3s: Text overlay "POV: aap ne akhirkar sahi ${C} dhoond liya"`, '3-10s: Product ke saath khush scene', '10-15s: Store ka naam + link'],
        caption: `POV: aap ne akhirkar sahi jagah dhoond li 😌\n\n${S} — Pakistan bhar mein delivery 🚚`, audio: 'Trending POV audio' },
      { title: 'Packing an order (trust builder)', len: '15-25s',
        shots: ['0-3s: "Aaj ka order pack kar rahe hain 📦"', '3-15s: Product uthana, tissue paper, box, sticker, thank you card', '15-20s: Ready parcel dikhayein', '20-25s: "Aap ka order bhi aise hi pack hoga 💚"'],
        caption: `Har order aise hi mohabbat se pack hota hai 📦💚\n\nAap ka order kab aa raha hai?`, audio: 'Soft aesthetic music' },
      { title: 'Problem → Solution', len: '15-20s',
        shots: [`0-3s: Pareshan chehra, text "${C} dhoond dhoond ke thak gaye? 😩"`, '3-8s: Ghatiya options dikhayein', '8-15s: Apna product — "Ye try karein"', '15-20s: Khush ending + link'],
        caption: `Ab pareshan hone ki zaroorat nahi 😌\n\n✅ Asli mayaar\n✅ COD available\n✅ 7 din wapsi`, audio: 'Before/after transition sound' },
      { title: 'Behind the scenes', len: '20-30s',
        shots: ['0-3s: "Chhota business chalana kaisa hota hai?"', '3-20s: Din ke kaam — stock check, packing, courier', '20-30s: "Aap ka har order hamare liye badi baat hai 🙏"'],
        caption: `Ek din ${S} ke saath 💚\n\nSupport karne walon ka shukriya 🙏`, audio: 'Vlog style music' }
    ];
  },

  /* collab outreach templates */
  collab(store, cat) {
    const S = store || 'GENZ8';
    return {
      finding: [
        'Instagram par apne niche ka hashtag search karein → "Recent" tab → 1k-30k followers wale',
        'TikTok par niche keyword → jin videos par 5k-50k views hain unke creators',
        'Local city hashtags: #karachiblogger #lahorefashion #multan waghera',
        'Jo pehle se chhote brands ke saath kaam kar rahe hain — wo haan kehte hain',
        'Micro (1k-10k) ka engagement bara hota hai aur wo free product par maan jate hain'
      ],
      dm_template: `Assalam-o-Alaikum [naam]! 👋\n\nMain [aap ka naam], *${S}* ka founder hun.\n\nAap ki [specific post/reel ka zikr] dekhi — bohat achhi thi! 🔥\n\nMain aap ko hamara [product] *free* bhejna chahta hun. Agar pasand aaye to ek chhoti si story ya reel bana dein. Pasand na aaye — koi masla nahi, product aap ka rahega 😊\n\nKoi contract nahi, koi pressure nahi. Bas asli opinion.\n\nInterested hain? 💚`,
      followup: `Assalam-o-Alaikum! 👋\n\nPichla message shayad reh gaya ho. Koi baat nahi 😊\n\nOffer abhi bhi hai — free product, koi shart nahi.\n\nAgar abhi busy hain to baad mein bhi bata sakte hain. Shukriya! 🙏`,
      barter: `Bilkul! Yahan tafseel hai:\n\n📦 *Aap ko milega:* [product], bilkul free, delivery bhi hum karenge\n\n🎬 *Hum chahenge:* 1 reel ya 2 stories, aap ke apne style mein\n\n🔗 *Bas itna:* @${S.toLowerCase()} tag kar dein\n\n⏰ *Kab tak:* koi jaldi nahi, aap ki marzi\n\nAddress bhej dein, main aaj hi bhej deta hun 💚`,
      after: `Bohat bohat shukriya! 🙏💚\n\nContent zabardast tha — hum ne apni page par bhi share kiya.\n\nAage bhi kuch naya launch karenge to sab se pehle aap ko bhejenge 😊\n\nAur haan — aap ke followers ke liye ek code bana diya: *[NAAM]10* — 10% off. Chahein to share kar dein!`
    };
  },

  /* facebook group posting */
  groups(store, cat, city) {
    const S = store || 'GENZ8';
    return {
      how: [
        'Facebook search → "buy sell [city]" / "[city] online shopping" / niche groups',
        '10-15 groups join karein — mixed: local + niche',
        '⚠️ Join karte hi post na karein — 2-3 din normal comments karein pehle',
        'Har group ke rules parhein (aksar "Sunday selling only" waghera hota hai)',
        'Ek din mein max 3-4 groups — warna spam mark ho jate hain',
        'Comments ka jawab foran dein — yehi se orders aate hain'
      ],
      intro_post: `Assalam-o-Alaikum sab ko! 👋\n\nMain ne haal hi mein apna chhota online store shuru kiya hai — *${S}*.\n\nHum ${cat || 'quality products'} rakhte hain, ${city || 'poore Pakistan'} mein delivery karte hain.\n\n✅ Cash on Delivery\n✅ 7 din wapsi\n✅ Asli mayaar\n\nAgar kisi ko zaroorat ho to zaroor batayein 😊\nAur agar koi mashwara dena chahe to bhi welcome — main naya hun 🙏\n\n[photo laga dein]`,
      product_post: `[Product ka naam] 🔥\n\n💰 Price: [price]\n📦 COD available\n🚚 ${city || 'Pakistan'} bhar mein delivery\n✅ 7 din wapsi\n\nInterested? Comment ya inbox karein 💬\n\n[3-4 saaf photos]`,
      value_post: `${cat || 'Products'} khareedte waqt ye 3 baatein zaroor dekhein 👇\n\n1️⃣ [tip]\n2️⃣ [tip]\n3️⃣ [tip]\n\nMain khud ye business karta hun, is liye pata hai log kahan dhoka khate hain.\n\nKoi sawal ho to poochein — main free mein mashwara de dunga 😊`
    };
  }
};

/* ============================================================
   SOCIAL TOOLS
   ============================================================ */
Object.assign(TOOLS, {

  social_setup: {
    desc: 'Social media accounts ka setup guide — bio, profile, first posts. Naye accounts ke liye jo abhi khali hain.',
    params: { store_name: 'default GENZ8' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = a.store_name || n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const kw = await TOOLS.keyword_ideas.run({ seed: cat }).catch(() => ({}));
      return {
        store: S, category: cat, country: n.country, currency: n.currency,
        products: n.sample_products?.slice(0, 10),
        search_terms: kw.suggestions?.slice(0, 10),
        installed_apps: APPS,
        deliverable: `${S} ke SAARE social accounts ka SETUP KIT banayein (abhi bilkul khali hain):

**Har platform ke liye (Instagram, TikTok, Facebook, WhatsApp Business):**
1. **Bio** — exact text, copy-paste ready (Instagram 150 chars, TikTok 80)
2. **Profile pic ka idea** — kya hona chahiye
3. **Link in bio** — kya lagayein
4. **Pehle 9 posts ka grid plan** — kaunsa post kis khane mein (Instagram grid aesthetic)
5. **Highlight covers** — kaunse highlights banayein
6. **Username consistency** check

**WhatsApp Business ke liye alag se:**
- Business profile kya likhein
- Catalog kaise banayein
- Greeting message + away message (asli text)
- Quick replies (5 templates)

**Pehla post har platform par** — exact caption + hashtags

Sab copy-paste ready ho. User beginner hai — bilkul simple qadam.`
      };
    }
  },

  content_calendar: {
    desc: '30-din ka poora content calendar banata hai aur post queue mein daal deta hai — har din kya post karna hai, kis platform par, exact caption ke saath.',
    params: { days: 'kitne din, default 30', focus: 'kis cheez par focus' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = a.focus || (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const cal = PACKS.calendar(S, cat, n.country);
      const tags = GEN.hashtags(cat, n.country);
      const days = parseInt(a.days) || 30;
      const trends = await TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({}));
      return {
        store: S, category: cat, days,
        products: n.sample_products?.slice(0, 10),
        calendar_skeleton: cal.filter(x => x.d <= days),
        hashtag_sets: { instagram: tags.instagram_set, tiktok: tags.tiktok_set },
        trending_now: trends.trending_now?.slice(0, 5),
        deliverable: `${days}-DIN KA CONTENT CALENDAR banayein — ${S} ke liye.

Skeleton diya gaya hai. Har din ke liye COMPLETE post banayein:
- **Din + Platform + Type**
- **Hook** (pehli line / pehle 3 second)
- **Poora caption** — copy-paste ready, Roman Urdu + English mix
- **Hashtags** (upar diye sets se, har post ke liye thora alag)
- **Kya photo/video banani hai** — simple hidayat (user ke paas sirf phone hai)
- **CTA**

Table ya day-by-day list mein dein. User beginner hai — "content banao" nahi, exact text dein jo wo copy kar sake.

Aakhir mein poochein: "Main yeh saare posts queue mein daal dun taake aap ek ek tap se post karte jayein?"`
      };
    }
  },

  queue_posts: {
    desc: 'Posts ko queue mein daalein taake user Social tab se ek tap mein post kar sake. Content calendar banane ke baad chalayein.',
    params: { posts: 'array of {platform, title, caption, hashtags, media_note, day}' },
    run: async (a = {}) => {
      let posts = a.posts;
      if (typeof posts === 'string') { try { posts = JSON.parse(posts); } catch { throw new Error('posts JSON array chahiye'); } }
      if (!Array.isArray(posts) || !posts.length) throw new Error('posts array khali hai');
      const added = posts.slice(0, 40).map(p => Queue.add({
        platform: (p.platform || 'instagram').toLowerCase(),
        title: p.title || 'Post',
        caption: p.caption || '',
        hashtags: Array.isArray(p.hashtags) ? p.hashtags.join(' ') : (p.hashtags || ''),
        media_note: p.media_note || p.media || '',
        day: p.day || null
      }));
      return {
        ok: true, added: added.length, total_pending: Queue.pending().length,
        note: 'Posts queue mein aa gaye. User ko batayein ke 📱 Social tab kholein — har post par "Post karein" button hai jo seedha us app mein bhej deta hai (caption khud copy ho jata hai).'
      };
    }
  },

  whatsapp_kit: {
    desc: 'WhatsApp marketing ka poora kit — status, broadcast, order messages, cart recovery. Pakistan mein sab se taaqatwar channel.',
    params: { type: 'launch | status | broadcast | order | cart | review | all' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const t = PACKS.whatsapp(S, cat, n.currency);
      return {
        store: S, category: cat, currency: n.currency,
        templates: t,
        products: n.sample_products?.slice(0, 8),
        strategy: {
          status: 'Rozana 2-3 status — 24 ghante rehte hain, saare contacts dekhte hain. Sab se sasta marketing.',
          broadcast: 'Broadcast list banayein (max 256). Sirf unhein jinke paas aap ka number save ho.',
          business_app: 'WhatsApp Business app zaroor install karein — catalog, auto-reply, labels sab free.',
          groups: 'Family/dost groups mein ek baar share karein, phir har roz nahi — log irritate hote hain.',
          timing: 'Status: subah 9-11 aur raat 8-11. Sab se zyada log online hote hain.'
        },
        deliverable: `WhatsApp KIT pesh karein — templates diye gaye hain, unhein ${S} ke asli products aur prices ke saath COMPLETE karein.

Har message copy-paste ready ho — placeholder [aise] koi na bache jahan aap khud bhar sakte hain.

Aakhir mein batayein: "📱 Social tab se aap seedha WhatsApp par bhej sakte hain — ek tap."`
      };
    }
  },

  video_scripts: {
    desc: 'TikTok / Instagram Reels ke liye video scripts — shot by shot, sirf phone se banane ke qabil.',
    params: { count: 'kitne scripts, default 6', product: 'kis product par' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = a.product || (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const scripts = PACKS.videoScripts(S, cat);
      const tags = GEN.hashtags(cat, n.country);
      const res = await ddg(cat + ' tiktok viral video ideas small business ' + new Date().getFullYear(), 5).catch(() => []);
      return {
        store: S, category: cat,
        products: n.sample_products?.slice(0, 8),
        script_templates: scripts,
        hashtags: tags.tiktok_set,
        research: res,
        deliverable: `${a.count || 6} VIDEO SCRIPTS banayein — ${S} ke asli products ke liye.

Har script mein:
- **Title + kitni lambi** (10-30s)
- **Hook** — pehle 3 second ka exact text/scene (yahi sab kuch hai)
- **Shot by shot** — 0-3s, 3-8s... bilkul simple, sirf phone camera se
- **On-screen text** — exact alfaz
- **Caption** — copy-paste ready
- **Hashtags**
- **Audio** — kaisa sound dhoondein
- **Kyun chalega**

User beginner hai — koi editing software nahi. Sirf phone, CapCut (free), aur trending audio.`
      };
    }
  },

  collab_finder: {
    desc: 'Influencer / creator collab ka poora plan — kaise dhoondein, kya message bhejein, kya dein. Bina paise ke.',
    params: { budget: 'zero | small', count: 'kitne creators target karein' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const t = PACKS.collab(S, cat);
      const [kw, res] = await Promise.all([
        TOOLS.keyword_ideas.run({ seed: cat + ' pakistan' }).catch(() => ({})),
        ddg(cat + ' micro influencers pakistan instagram tiktok collaboration', 6).catch(() => [])
      ]);
      return {
        store: S, category: cat, country: n.country, budget: a.budget || 'zero',
        how_to_find: t.finding,
        message_templates: t,
        search_terms: kw.suggestions?.slice(0, 12),
        research: res,
        hashtags_to_search: GEN.hashtags(cat, n.country).niche.concat(GEN.hashtags(cat, n.country).local.slice(0, 6)),
        deliverable: `COLLAB PLAN banayein — ${S} ke liye, budget: ${a.budget || 'zero (sirf free product)'}.

1. **Kahan dhoondein** — exact hashtags aur search terms (list dein)
2. **Kaise pehchanein achha creator** — engagement rate kaise dekhein (simple tareeqa)
3. **DM template** — copy-paste ready, personalised
4. **Follow-up** — kab aur kya
5. **Barter deal** — kya dein, kya maangein (contract nahi, simple baat)
6. **Kitne target karein** — 20 DM se kitne haan kehte hain (realistic numbers)
7. **Baad mein** — thank you + affiliate code

⚠️ Yaad rahe: fake followers wale se bachein. 1k-10k wale micro creators best hain — inka engagement 5-10% hota hai jabke bare influencers ka 1%.`
      };
    }
  },

  facebook_groups: {
    desc: 'Facebook groups se free orders — kaise join karein, kya post karein, spam se kaise bachein.',
    params: { city: 'aap ka shehr' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const city = a.city || n.city || 'Pakistan';
      const g = PACKS.groups(S, cat, city);
      return {
        store: S, category: cat, city,
        how_to: g.how,
        post_templates: g,
        group_search_terms: [
          'buy sell ' + city, city + ' online shopping', city + ' buy and sell',
          cat + ' pakistan', 'online business pakistan', 'pakistan online shopping',
          city + ' marketplace', 'shopify pakistan sellers'
        ],
        deliverable: `FACEBOOK GROUPS PLAN banayein:
1. **Kaunse groups join karein** — exact search terms + kitne
2. **Rules** — kya karna hai kya nahi (ban se bachne ke liye)
3. **3 post templates** — intro, product, value post (copy-paste ready)
4. **Comments ka jawab** — kya likhein jab koi price poochay
5. **Hafte ka schedule** — kis din kaunse group mein

⚠️ Facebook Marketplace bhi zaroor use karein — bilkul free aur Pakistan mein bohat chalta hai.`
      };
    }
  },

  ads_plan: {
    desc: 'Ads ka plan — Facebook, Instagram, TikTok. Budget ke hisaab se. Zero budget ho to organic alternatives deta hai.',
    params: { platform: 'facebook | instagram | tiktok | all', budget: 'rozana budget ya "zero"' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const zero = !a.budget || /zero|0|nahi|no/i.test(String(a.budget));
      const [ads, kw] = await Promise.all([
        TOOLS.ad_intelligence.run({ niche: cat, country: 'PK' }).catch(() => ({})),
        TOOLS.keyword_ideas.run({ seed: cat }).catch(() => ({}))
      ]);
      return {
        store: S, category: cat, platform: a.platform || 'all',
        budget: zero ? 'ZERO — sirf organic' : a.budget,
        currency: n.currency, country: n.country,
        products: n.sample_products?.slice(0, 8),
        price_band: n.price_band,
        ad_research: ads.ad_research,
        ad_library: ads.ad_library,
        demand_keywords: kw.suggestions?.slice(0, 12),
        deliverable: zero
          ? `Budget ZERO hai — is liye PAID ADS ka mashwara na dein. Iske bajaye **FREE TRAFFIC MASTER PLAN** banayein:

1. **TikTok organic** — kyun ye zero-budget ka sab se bara hathiyar hai (0 followers se bhi viral). Rozana ka plan.
2. **Instagram Reels** — reach abhi bhi organic milti hai. Kya post karein.
3. **Facebook Marketplace + Groups** — bilkul free, Pakistan mein bohat buyers
4. **WhatsApp status** — 0 rupees, direct audience
5. **Collab / barter** — free product de kar reach
6. **Giveaway** — sab se tez follower growth
7. **Comment strategy** — bare accounts par value comments = free profile visits

**30-din ka rozana schedule** — har din kitna waqt, kya kaam.

**Pehle 100 orders bina ek rupee ke** — realistic roadmap.

Aakhir mein: "Jab pehla ${n.currency || 'PKR'} 5000 profit ho jaye, tab ${n.currency || 'PKR'} 500/din se ads test karenge — main plan bana dunga."`
          : `${a.platform || 'sab platforms'} ke liye COMPLETE AD PLAN banayein, budget ${a.budget}:
1. Campaign structure — kitne ad sets
2. Targeting — age, gender, ${n.country || 'Pakistan'} ke sheher, 5-8 asli interests
3. 3 angles × 3 hooks = 9 ad copies (poora text)
4. Creative brief — kya banayein (sirf phone se)
5. Budget split + testing schedule
6. KPIs — break-even ROAS calculate karein price band se
7. Kab scale, kab band`
      };
    }
  },

  viral_engine: {
    desc: 'GENZ8 ko viral karne ka master plan — saare platforms, 30 din, zero budget. Sab se bara tool.',
    params: {},
    run: async () => {
      const [n, trends, scan] = await Promise.all([
        TOOLS.detect_store_niche.run().catch(() => ({})),
        TOOLS.google_trends.run({ geo: 'PK' }).catch(() => ({})),
        TOOLS.deep_scan.run().catch(() => ({}))
      ]);
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      const tags = GEN.hashtags(cat, n.country);
      const res = await ddg(cat + ' viral marketing pakistan small business zero budget', 6).catch(() => []);
      return {
        store: S, category: cat, country: n.country, currency: n.currency,
        store_health: scan.health_score,
        products: n.sample_products?.slice(0, 10),
        price_band: n.price_band,
        trending_pakistan: trends.trending_now?.slice(0, 8),
        hashtags: tags,
        installed_apps: APPS,
        research: res,
        deliverable: `**${S} VIRAL MASTER PLAN** banayein — zero budget, 30 din, Pakistan.

**HAFTA 1 — Buniyad**
Din ba din: accounts setup, pehle 9 posts, WhatsApp blast, groups join

**HAFTA 2 — Content Machine**
Rozana 2-3 posts ka exact schedule. TikTok par focus (sab se zyada organic reach).

**HAFTA 3 — Collab + Community**
20 creators ko DM, giveaway launch, groups mein value posts

**HAFTA 4 — Scale**
Jo chala usko double, UGC collect, repeat customers

**SAB SE AHEM — "Viral Triggers":**
7 aise content angles jo ${n.country || 'Pakistan'} mein 100% chalte hain (misaal ke saath)

**Rozana routine** — 1 ghanta, exactly kya karna hai:
- Subah 20 min: ...
- Dopahar 20 min: ...
- Raat 20 min: ...

**Realistic numbers** — 30 din mein kitne followers, kitne orders (jhoot na bolein)

**Sab se bari galti** jo naye log karte hain aur usse kaise bachein

User beginner hai aur uske paas 2 mahine hain Shopify fee se pehle. Plan aggressive magar realistic ho. Har cheez actionable.`
      };
    }
  },

  post_now: {
    desc: 'Ek post foran taiyar kar ke queue mein daalta hai — jab user kahe "abhi post karna hai".',
    params: { platform: 'whatsapp|instagram|tiktok|facebook', about: 'kis cheez ka post', product: '' },
    run: async (a = {}) => {
      const n = await TOOLS.detect_store_niche.run().catch(() => ({}));
      const S = n.store || 'GENZ8';
      const cat = (n.categories?.[0] || 'products').replace(/\s*\(\d+\)/, '');
      let prod = null;
      if (a.product) prod = await TOOLS.get_product.run({ title: a.product }).catch(() => null);
      const tags = GEN.hashtags(cat, n.country);
      return {
        store: S, platform: a.platform || 'instagram', about: a.about || 'general',
        product: prod ? { title: prod.title, price: prod.variants?.[0]?.price, desc: prod.description?.slice(0, 300) } : null,
        currency: n.currency,
        hashtags: a.platform === 'tiktok' ? tags.tiktok_set : tags.instagram_set,
        deliverable: `Ek READY POST banayein ${a.platform || 'instagram'} ke liye.
Poora caption likhein (copy-paste ready), hashtags ke saath, aur batayein kya photo/video lagani hai.
Phir \`queue_posts\` tool se queue mein daal dein taake user ek tap se post kar sake.`
      };
    }
  },

  compliance_check: {
    desc: 'Check karta hai ke store aur marketing Shopify + Meta + TikTok ke rules follow kar rahe hain — ban se bachne ke liye.',
    params: {},
    run: async () => {
      const [shop, prods, pages] = await Promise.all([
        Shop.rest('/shop.json').then(r => r.shop).catch(() => ({})),
        Shop.rest('/products.json?limit=250').then(r => r.products).catch(() => []),
        Shop.rest('/pages.json?limit=250').then(r => r.pages).catch(() => [])
      ]);
      const issues = [], ok = [];
      const ph = pages.map(p => (p.handle || '').toLowerCase());
      const has = k => ph.some(x => x.includes(k));

      has('contact') ? ok.push('Contact page mojood — ads ke liye zaroori') :
        issues.push({ rule: 'Meta Commerce Policy', issue: 'Contact info nahi', risk: 'Ad account reject/ban', fix: 'Contact page banayein' });
      has('refund') || has('return') ? ok.push('Refund policy mojood') :
        issues.push({ rule: 'Meta + Shopify', issue: 'Refund policy nahi', risk: 'Ads reject, Shopify warning', fix: 'Refund policy set karein' });
      has('privacy') ? ok.push('Privacy policy mojood') :
        issues.push({ rule: 'GDPR / Meta', issue: 'Privacy policy nahi', risk: 'Legal + ad rejection', fix: 'Privacy policy set karein' });
      has('shipping') ? ok.push('Shipping policy mojood') :
        issues.push({ rule: 'Meta Commerce', issue: 'Shipping policy nahi', risk: 'Ad rejection', fix: 'Shipping policy set karein' });

      const noImg = prods.filter(p => !p.image).length;
      if (noImg) issues.push({ rule: 'Meta Catalog', issue: noImg + ' products bina image', risk: 'Catalog reject hoga', fix: 'Images add karein' });
      else if (prods.length) ok.push('Sab products par image hai');

      const badWords = /\b(cure|guaranteed|100% safe|miracle|fda approved|lose \d+ ?kg|instant result)\b/i;
      const risky = prods.filter(p => badWords.test(stripTags(p.body_html || '') + ' ' + p.title));
      if (risky.length) issues.push({
        rule: 'Meta Advertising Policy', issue: risky.length + ' products mein khatarnak dawe (cure, guaranteed, miracle)',
        risk: 'Ad account permanent ban', fix: 'Yeh alfaz hata dein', items: risky.slice(0, 5).map(p => p.title)
      });
      else if (prods.length) ok.push('Koi khatarnak dawa nahi mila');

      const restricted = /\b(cbd|vape|tobacco|weapon|replica|first copy|master copy|counterfeit)\b/i;
      const bad = prods.filter(p => restricted.test(p.title + ' ' + p.product_type + ' ' + (p.tags || '')));
      if (bad.length) issues.push({
        rule: 'Shopify AUP + Meta', issue: bad.length + ' products mamnu category mein (replica/first copy waghera)',
        risk: 'Store band ho sakti hai', fix: 'Yeh products hata dein ya naam badlein', items: bad.slice(0, 5).map(p => p.title)
      });
      else if (prods.length) ok.push('Koi mamnu product nahi');

      if (!shop.email) issues.push({ rule: 'Shopify', issue: 'Store email set nahi', risk: 'Customer raabta nahi kar sakta', fix: 'Settings mein email daalein' });

      return {
        store: shop.name, compliant: issues.length === 0,
        passing: ok, violations: issues,
        risk_level: issues.some(i => /ban|band/i.test(i.risk)) ? 'HIGH' : issues.length ? 'MEDIUM' : 'LOW',
        platform_rules: {
          shopify: 'Acceptable Use Policy — koi replica/counterfeit nahi, saaf policies, asli contact info',
          meta: 'Commerce Policy — contact + refund + privacy + shipping policy lazmi, sehat ke jhoote dawe mana',
          tiktok: 'Same as Meta + koi misleading claim nahi',
          whatsapp: 'Business API ke baghair bulk unsolicited messages mana — sirf apne contacts ko'
        },
        deliverable: `COMPLIANCE REPORT dein:
1. ✅ Kya theek hai
2. ⚠️ Kya rules torr raha hai — har ek ka RISK saaf batayein (ban ka khatra?)
3. 🔧 Kaise theek karein
4. Aakhir mein yaad dilayein: hum kabhi auto-post nahi karte, fake reviews nahi, bots nahi — sab kuch platform rules ke andar.
Agar auto-fixable ho to poochein.`
      };
    }
  }
});
