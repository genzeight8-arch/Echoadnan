/* ============================================================
   socialui.js — SOCIAL TAB
   Post queue + one-tap share to WhatsApp/IG/TikTok/FB
   ============================================================ */

function buildSocial() {
  const el = document.getElementById('socialbody');
  if (!el) return;
  const q = Queue.all();
  const pend = q.filter(x => x.status === 'pending');
  const done = q.filter(x => x.status === 'posted');

  let h = '';

  /* ---- quick share bar ---- */
  h += `<div class="sec">⚡ Foran share karein</div>
  <div class="qshare">
    ${Object.entries(PLATFORMS).map(([k, p]) => `
      <div class="qs" data-plat="${k}">
        <div class="qsi" style="background:${p.color}22;border-color:${p.color}55">${p.icon}</div>
        <b>${p.name}</b>
        <small>${APPS[k] === false ? 'install nahi' : 'ready'}</small>
      </div>`).join('')}
  </div>
  <div class="hint" style="margin:-4px 0 4px">Tap karein → ECHO caption bana kar us app mein bhej dega</div>`;

  /* ---- generators ---- */
  h += `<div class="sec">🎁 Ready content banwayein</div>`;
  const gens = [
    { i: '📅', t: '30-din ka content calendar', s: 'GENZ8 ke liye 30 din ka poora content calendar banao — har din ka exact caption aur hashtags ke saath, phir sab queue mein daal do' },
    { i: '💬', t: 'WhatsApp kit', s: 'WhatsApp ka poora kit banao — status, broadcast, order messages, cart recovery, sab ready text ke saath' },
    { i: '🎬', t: 'TikTok/Reels scripts', s: 'TikTok aur Reels ke liye 6 video scripts banao — shot by shot, sirf phone se banane wale' },
    { i: '🤝', t: 'Collab plan (free)', s: 'Influencer collab ka plan banao — bina paise ke, sirf free product de kar. DM templates ke saath' },
    { i: '📘', t: 'Facebook groups plan', s: 'Facebook groups aur marketplace se free orders lene ka plan banao, post templates ke saath' },
    { i: '🔥', t: 'VIRAL MASTER PLAN', s: 'GENZ8 ko viral karne ka master plan banao — 30 din, zero budget, saare platforms, rozana routine ke saath' },
    { i: '🆕', t: 'Accounts setup guide', s: 'Mere social media accounts abhi bilkul khali hain — sab ka setup guide do: bio, profile, pehle 9 posts ka plan' },
    { i: '📢', t: 'Ads plan', s: 'Ads ka plan banao — mera budget abhi zero hai to free traffic ke tareeqe batao' }
  ];
  gens.forEach(g => {
    h += `<div class="item act" data-s="${escAttr(g.s)}">
      <div class="ph">${g.i}</div>
      <div class="t"><b>${g.t}</b></div>
      <span class="tag b">GO</span></div>`;
  });

  /* ---- queue ---- */
  h += `<div class="sec">📬 Post Queue ${pend.length ? '<span class="cnt">' + pend.length + '</span>' : ''}</div>`;
  if (!pend.length) {
    h += `<div class="empty" style="padding:26px 16px"><div class="e">📭</div>
      Queue khali hai.<br>Upar se <b>content calendar</b> banwayein — saare posts yahan aa jayenge.</div>`;
  } else {
    pend.slice(0, 40).forEach(p => {
      const pl = PLATFORMS[p.platform] || { icon: '📱', name: p.platform, color: '#5B8CFF' };
      const cap = (p.caption || '') + (p.hashtags ? '\n\n' + p.hashtags : '');
      h += `<div class="post" data-id="${p.id}">
        <div class="phead">
          <span class="pico" style="background:${pl.color}22">${pl.icon}</span>
          <div class="pt"><b>${esc(p.title)}</b><small>${pl.name}${p.day ? ' · Din ' + p.day : ''}</small></div>
          <button class="pdel" data-del="${p.id}">✕</button>
        </div>
        ${p.media_note ? `<div class="pmedia">📷 ${esc(p.media_note)}</div>` : ''}
        <div class="pcap">${esc(cap).replace(/\n/g, '<br>')}</div>
        <div class="pacts">
          <button class="pbtn go" data-post="${p.id}">${pl.icon} ${pl.name} par post karein</button>
          <button class="pbtn" data-copy="${p.id}">📋</button>
          <button class="pbtn" data-done="${p.id}">✓</button>
        </div>
      </div>`;
    });
  }

  if (done.length) {
    h += `<div class="sec">✅ Ho chuke (${done.length})</div>`;
    done.slice(0, 8).forEach(p => {
      const pl = PLATFORMS[p.platform] || { icon: '📱', name: p.platform };
      h += `<div class="item" style="opacity:.55">
        <div class="ph">${pl.icon}</div>
        <div class="t"><b>${esc(p.title)}</b><small>${pl.name}</small></div>
        <span class="tag g">✓</span></div>`;
    });
    h += `<button class="btn o" id="clrq" style="margin-top:10px">Queue saaf karein</button>`;
  }

  el.innerHTML = h;

  /* ---- wire events ---- */
  el.querySelectorAll('.act').forEach(n => n.onclick = () => { go('chat'); send(n.dataset.s); });
  el.querySelectorAll('.qs').forEach(n => n.onclick = () => quickShare(n.dataset.plat));
  el.querySelectorAll('[data-post]').forEach(n => n.onclick = () => doPost(n.dataset.post));
  el.querySelectorAll('[data-copy]').forEach(n => n.onclick = () => copyPost(n.dataset.copy, n));
  el.querySelectorAll('[data-done]').forEach(n => n.onclick = () => { Queue.mark(n.dataset.done, 'posted'); buildSocial(); });
  el.querySelectorAll('[data-del]').forEach(n => n.onclick = () => { Queue.remove(n.dataset.del); buildSocial(); });
  const c = document.getElementById('clrq');
  if (c) c.onclick = () => { if (confirm('Poora queue saaf kar dein?')) { Queue.clear(); buildSocial(); } };
}

const escAttr = s => String(s).replace(/"/g, '&quot;');

/* ---- post to a platform ---- */
function doPost(id) {
  const p = Queue.all().find(x => x.id === id);
  if (!p) return;
  const text = (p.caption || '') + (p.hashtags ? '\n\n' + p.hashtags : '');
  if (window.Native?.shareTo) {
    Native.shareTo(p.platform, text, null);
  } else {
    navigator.clipboard?.writeText(text);
    alert('Caption copy ho gaya. ' + (PLATFORMS[p.platform]?.name || p.platform) + ' kholein aur paste karein.');
  }
  setTimeout(() => { Queue.mark(id, 'posted'); buildSocial(); }, 1200);
}

function copyPost(id, btn) {
  const p = Queue.all().find(x => x.id === id);
  if (!p) return;
  const text = (p.caption || '') + (p.hashtags ? '\n\n' + p.hashtags : '');
  if (window.Native?.copy) Native.copy(text); else navigator.clipboard?.writeText(text);
  if (btn) { btn.textContent = '✓'; setTimeout(() => btn.textContent = '📋', 1300); }
  if (window.Native?.toast) Native.toast('Copy ho gaya');
}

/* ---- quick share (no queue) ---- */
function quickShare(plat) {
  go('chat');
  const map = {
    whatsapp: 'WhatsApp status ke liye ek abhi ka post banao — GENZ8 ka, ready text ke saath, phir queue mein daal do',
    instagram: 'Instagram ke liye abhi ek post banao — caption aur hashtags ke saath, phir queue mein daal do',
    tiktok: 'TikTok ke liye abhi ek video script aur caption banao, phir queue mein daal do',
    facebook: 'Facebook ke liye abhi ek post banao — group mein daalne wala, phir queue mein daal do'
  };
  send(map[plat] || map.instagram);
}
