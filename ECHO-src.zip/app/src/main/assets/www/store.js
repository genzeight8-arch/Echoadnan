/* store.js — local persistence (nothing leaves the device) */
const DEFAULTS = {
  shop: { domain: '', token: '' },
  ai: { provider: 'groq', key: '', model: 'llama-3.3-70b-versatile' }
};

const Store = {
  get() {
    try {
      const raw = JSON.parse(localStorage.getItem('apsa_cfg') || '{}');
      return {
        shop: Object.assign({}, DEFAULTS.shop, raw.shop),
        ai: Object.assign({}, DEFAULTS.ai, raw.ai)
      };
    } catch { return JSON.parse(JSON.stringify(DEFAULTS)); }
  },
  set(cfg) { localStorage.setItem('apsa_cfg', JSON.stringify(cfg)); },
  patch(part) { const c = this.get(); Object.assign(c, part); this.set(c); return c; },

  history(h) {
    if (h === undefined) { try { return JSON.parse(sessionStorage.getItem('apsa_h') || '[]'); } catch { return []; } }
    sessionStorage.setItem('apsa_h', JSON.stringify(h)); return h;
  },
  clearHistory() { sessionStorage.removeItem('apsa_h'); },
  wipe() { localStorage.removeItem('apsa_cfg'); sessionStorage.removeItem('apsa_h'); }
};
