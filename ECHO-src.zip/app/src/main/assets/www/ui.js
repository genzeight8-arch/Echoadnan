/* ui.js — wiring */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const chat = $('#chat'), inp = $('#inp');
let busy = false, page = 'chat';

/* ---------- markdown-ish renderer ---------- */
function md(s) {
  s = s.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  const blocks = [];
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (m, l, c) => { blocks.push(c); return '\u0000' + (blocks.length - 1) + '\u0000'; });

  // tables
  s = s.replace(/((?:^\|.*\|\s*$\n?)+)/gm, tbl => {
    const rows = tbl.trim().split('\n').filter(r => !/^\|[\s\-:|]+\|$/.test(r.trim()));
    if (rows.length < 2) return tbl;
    let h = '<table>';
    rows.forEach((r, i) => {
      const cells = r.trim().replace(/^\||\|$/g, '').split('|');
      h += '<tr>' + cells.map(c => `<${i ? 'td' : 'th'}>${c.trim()}</${i ? 'td' : 'th'}>`).join('') + '</tr>';
    });
    return h + '</table>';
  });

  s = s
    .replace(/^###?\s+(.+)$/gm, '<h4>$1</h4>')
    .replace(/^---+$/gm, '<hr>')
    .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>')
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/^\s*[-•*]\s+(.+)$/gm, '<li>$1</li>')
    .replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g, '<ul>$1</ul>')
    .replace(/\n{2,}/g, '<br><br>').replace(/\n/g, '<br>');

  s = s.replace(/<br>?\s*(<(?:h4|ul|table|hr|pre))/g, '$1');
  return s.replace(/\u0000(\d+)\u0000/g, (m, i) => '<pre>' + blocks[i].trim() + '</pre>');
}

/* ---------- chat bubbles ---------- */
function bubble(html, cls) {
  const d = document.createElement('div');
  d.className = 'm ' + cls; d.innerHTML = html;
  chat.appendChild(d); scroll(); return d;
}
function note(t) { const d = document.createElement('div'); d.className = 'note'; d.textContent = t; chat.appendChild(d); scroll(); return d; }
function scroll() { requestAnimationFrame(() => { const m = $('#main'); m.scrollTop = m.scrollHeight; }); }

const TOOL_LABEL = {
  get_shop_info: 'Store info le raha hun', list_products: 'Products laa raha hun', get_product: 'Product dekh raha hun',
  create_product: 'Product bana raha hun', update_product: 'Product update kar raha hun', delete_product: 'Product delete kar raha hun',
  list_orders: 'Orders laa raha hun', track_order: 'Order track kar raha hun', fulfill_order: 'Order fulfill kar raha hun',
  list_themes: 'Themes check kar raha hun', get_theme_assets: 'Theme files dekh raha hun', publish_theme: 'Theme publish kar raha hun',
  list_customers: 'Customers laa raha hun', low_stock: 'Stock check kar raha hun', sales_summary: 'Sales calculate kar raha hun',
  create_discount: 'Discount bana raha hun', list_discounts: 'Discounts laa raha hun',
  list_collections: 'Collections laa raha hun', shopify_api: 'Shopify se data le raha hun',
  /* research */
  web_search: '🔍 Internet par dhoond raha hun', read_webpage: '📖 Page parh raha hun',
  google_trends: '📈 Trends check kar raha hun', keyword_ideas: '🔑 Keywords nikaal raha hun',
  spy_competitor: '🕵️ Competitor analyse kar raha hun', find_winning_products: '🏆 Winning products dhoond raha hun',
  ad_intelligence: '📢 Ads research kar raha hun',
  /* content */
  read_theme_file: '📄 Theme file parh raha hun', write_theme_file: '✍️ Theme file likh raha hun',
  add_theme_css: '🎨 CSS add kar raha hun', fix_footer_alignment: '🔧 Footer theek kar raha hun',
  list_pages: '📑 Pages dekh raha hun', create_page: '➕ Page bana raha hun', update_page: '✏️ Page update kar raha hun',
  setup_essential_pages: '🧾 Zaroori pages check kar raha hun',
  list_menus: '🗂 Menus dekh raha hun', update_menu: '🔗 Menu update kar raha hun',
  update_policy: '⚖️ Policy set kar raha hun', write_product_description: '📝 Description likh raha hun',
  audit_store: '🩺 Store ka audit kar raha hun',
  /* growth */
  detect_store_niche: '🎯 Store ka niche samajh raha hun', create_ad_campaign: '📢 Ad campaign bana raha hun',
  ad_creative_variants: '🎬 Ad variants bana raha hun', marketing_campaign: '📧 Campaign plan bana raha hun',
  think_tank: '🧠 Deep analysis kar raha hun', competitor_battle_plan: '⚔️ Battle plan bana raha hun',
  seo_plan: '🔎 SEO plan bana raha hun', pricing_strategy: '💰 Pricing analyse kar raha hun',
  daily_briefing: '☀️ Aaj ka briefing bana raha hun', autopilot: '🤖 AUTOPILOT — store scan kar raha hun',
  /* launch + fix */
  deep_scan: '🔬 Poori store ka deep scan kar raha hun', auto_fix_all: '🔧 Sab kuch khud theek kar raha hun',
  auto_fix_footer_menu: '🔗 Footer menu bhar raha hun', bulk_fix_descriptions: '📝 Descriptions check kar raha hun',
  launch_readiness: '🚦 Launch readiness check', launch_plan: '🚀 Launch plan bana raha hun',
  viral_kit: '🔥 Viral kit bana raha hun', hashtag_generator: '#️⃣ Hashtags bana raha hun',
  product_hunt_kit: '🏹 Product Hunt kit bana raha hun', store_watch: '👁 Store par nazar daal raha hun',
  /* social */
  social_setup: '🆕 Accounts ka setup bana raha hun', content_calendar: '📅 30-din ka calendar bana raha hun',
  queue_posts: '📬 Posts queue mein daal raha hun', whatsapp_kit: '💬 WhatsApp kit bana raha hun',
  video_scripts: '🎬 Video scripts likh raha hun', collab_finder: '🤝 Collab plan bana raha hun',
  facebook_groups: '📘 Facebook groups plan', ads_plan: '📢 Ads plan bana raha hun',
  viral_engine: '🔥 VIRAL MASTER PLAN bana raha hun', post_now: '⚡ Post tayar kar raha hun',
  compliance_check: '⚖️ Rules check kar raha hun'
};

/* ---------- send ---------- */
async function send(text) {
  const t = (text || inp.value).trim();
  if (!t || busy) return;
  const cfg = Store.get();
  if (!cfg.ai.key) { go('set'); note('Pehle Settings mein AI API key daalein ⚙️'); return; }

  inp.value = ''; inp.style.height = 'auto';
  bubble(md(t), 'u');
  busy = true; $('#snd').disabled = true;

  const typ = document.createElement('div');
  typ.className = 'm a typ'; typ.innerHTML = '<i></i><i></i><i></i>';
  chat.appendChild(typ); scroll();

  let live = null;
  try {
    const ans = await runAgent(t, ev => {
      if (ev.type === 'offline') {
        const o = document.createElement('div'); o.className = 'tool off';
        o.innerHTML = '📴 Offline mode — bina internet ke jawab de raha hun';
        chat.insertBefore(o, typ); scroll();
      }
      if (ev.type === 'note' && ev.text) note(ev.text.slice(0, 220));
      if (ev.type === 'tool') {
        live = document.createElement('div'); live.className = 'tool';
        live.innerHTML = '<span class="sp"></span><span>' + (TOOL_LABEL[ev.name] || ev.name) + '…</span>';
        chat.insertBefore(live, typ); scroll();
      }
      if (ev.type === 'tool_done' && ev.name === 'queue_posts' && typeof buildSocial === 'function') buildSocial();
      if (ev.type === 'tool_done' && live) {
        live.className = 'tool ' + (ev.ok ? 'ok' : 'bad');
        live.innerHTML = (ev.ok ? '✓ ' : '✕ ') + (TOOL_LABEL[ev.name] || ev.name) +
          (ev.ok ? '' : ' — ' + (ev.error || 'fail'));
        live = null; scroll();
      }
    });
    typ.remove();
    bubble(md(ans), 'a');

    const acts = document.createElement('div'); acts.className = 'acts';
    const cp = document.createElement('button'); cp.className = 'mini'; cp.textContent = '📋 Copy';
    cp.onclick = () => { navigator.clipboard?.writeText(ans); cp.textContent = '✓ Copied'; setTimeout(() => cp.textContent = '📋 Copy', 1400); };
    const sh = document.createElement('button'); sh.className = 'mini'; sh.textContent = '↗ Share';
    sh.onclick = () => { if (window.Native?.share) Native.share(ans); };
    acts.append(cp, sh); chat.appendChild(acts); scroll();
  } catch (e) {
    typ.remove();
    bubble('⚠️ <b>Error:</b> ' + e.message, 'a');
  }
  busy = false; $('#snd').disabled = false;
}

/* ---------- suggestions ---------- */
const SUGS = [
  '🔬 Deep scan karo', '🔧 Sab theek kar do', '🚦 Launch ke liye tayar hun?',
  '#️⃣ Hashtags do', '🔥 Viral kit banao', '📄 About Us banao',
  '📞 Contact page banao', '⚖️ Policies set karo', '📢 Ad banao',
  '🧠 Sales double karo', '☀️ Aaj ka briefing', '📈 Kya trend kar raha hai?',
  'Kam stock dikhao', 'Naye orders'
];
function chips() {
  const c = $('#sug'); c.innerHTML = '';
  SUGS.forEach(q => {
    const b = document.createElement('div'); b.className = 'chip'; b.textContent = q;
    b.onclick = () => send(q.replace(/^[^\w\u0600-\u06FF]+\s*/, '')); c.appendChild(b);
  });
}

/* ---------- Grow tab actions ---------- */
const GROW = [
  { g: '🔥 GENZ8 — launch aur viral', a: [
    { i: '🚀', t: 'PURA LAUNCH — sab kuch karo', s: 'Meri store GENZ8 launch karni hai. Pehle deep scan karo, phir jo bhi theek ho sakta hai sab khud theek kar do, phir mujhe batao ke ab main kya karun. Budget zero hai.' },
    { i: '🔥', t: 'VIRAL MASTER PLAN', s: 'GENZ8 ko viral karne ka master plan banao — 30 din, zero budget, TikTok/Instagram/Facebook/WhatsApp sab, rozana routine ke saath' },
    { i: '📅', t: '30-din content calendar', s: 'GENZ8 ke liye 30 din ka content calendar banao — har din ka poora caption aur hashtags, phir sab queue mein daal do' },
    { i: '🆕', t: 'Social accounts setup', s: 'Mere social accounts GENZ8 ke naam se bane hain magar bilkul khali hain. Sab ka setup guide do — bio, profile, pehle 9 posts' },
    { i: '⚖️', t: 'Rules check — safe hun?', s: 'Check karo meri store aur marketing Shopify, Meta aur TikTok ke rules follow kar rahi hai ya nahi. Ban ka koi khatra to nahi?' }
  ]},
  { g: '📱 Social Media', a: [
    { i: '💬', t: 'WhatsApp kit', s: 'WhatsApp ka poora kit banao — status, broadcast, order messages, cart recovery ke ready templates' },
    { i: '🎬', t: 'TikTok/Reels scripts', s: 'TikTok aur Reels ke 6 video scripts banao — shot by shot, sirf phone se banane wale' },
    { i: '🤝', t: 'Collab plan (free)', s: 'Influencer collab plan banao — zero budget, sirf free product de kar. DM templates ke saath' },
    { i: '📘', t: 'Facebook groups', s: 'Facebook groups aur marketplace se free orders lene ka plan banao' },
    { i: '📢', t: 'Ads plan', s: 'Ads ka plan banao — budget abhi zero hai to free traffic ke tareeqe batao' },
    { i: '#️⃣', t: 'Hashtags', s: 'GENZ8 ke liye best hashtags do — Instagram aur TikTok, copy-paste ready' }
  ]},
  { g: '⭐ Store theek karein', a: [
    { i: '🔬', t: 'DEEP SCAN — poori store check', s: 'Meri poori store ka deep scan karo — har masla dhoondo aur priority ke saath batao' },
    { i: '🔧', t: 'SAB KUCH THEEK KARO', s: 'Meri store mein jo bhi masail hain sab khud theek kar do — pages, policies, footer, menu, sab' },
    { i: '🚦', t: 'Launch ke liye tayar hun?', s: 'Check karo meri store launch ke liye tayar hai ya nahi, kya kya baaki hai' },
    { i: '👁', t: 'Store par nazar (rozana)', s: 'Store watch chalao — pichli baar se kya badla aur abhi kya urgent hai' }
  ]},
  { g: '🚀 Launch aur Viral', a: [
    { i: '🎯', t: 'Poora launch plan', s: 'Meri store launch karne ka poora din-ba-din plan banao — pehli 10 sales tak' },
    { i: '🔥', t: 'Viral kit banao', s: 'Viral kit banao — 15 content ideas, hooks, 30-din calendar, influencer plan' },
    { i: '#️⃣', t: 'Hashtags do', s: 'Mere store ke liye best hashtags do — Instagram aur TikTok dono ke liye copy-paste ready' },
    { i: '🏹', t: 'Product Hunt kit', s: 'Product Hunt aur directories par launch karne ka poora kit banao' },
    { i: '💥', t: 'Pehli sale kaise laun?', s: 'Mujhe pehli 10 sales chahiye — bilkul specific tareeqe batao jo Pakistan mein chalte hain' }
  ]},
  { g: '🤖 Autopilot — store khud sambhalo', a: [
    { i: '🩺', t: 'Full store audit', s: 'Poori store ka audit karo aur bata kya kya theek karna hai' },
    { i: '🔧', t: 'Autopilot FIX', s: 'Autopilot fix mode chalao — jo masail hain wo theek karne ka plan do' },
    { i: '🚀', t: 'Autopilot GROW', s: 'Autopilot grow mode — is hafte sales barhane ka plan do' },
    { i: '☀️', t: 'Aaj ka briefing', s: 'Aaj ka daily briefing do' }
  ]},
  { g: '🎨 Store banao / sudharo', a: [
    { i: '🔧', t: 'Footer align karo', s: 'Mere store ka footer automatically theek align karo, mobile par bhi' },
    { i: '📄', t: 'About Us page', s: 'Mere store ke liye professional About Us page banao aur publish kar do' },
    { i: '📞', t: 'Contact page', s: 'Contact Us page banao — form, email, WhatsApp, address ke saath' },
    { i: '❓', t: 'FAQ page', s: 'Meri store ke hisaab se FAQ page banao, kam az kam 10 sawal' },
    { i: '⚖️', t: 'Saari policies', s: 'Shipping, Refund, Privacy aur Terms policies likh kar set kar do' },
    { i: '🧾', t: 'Missing pages check', s: 'Check karo kaunse zaroori pages missing hain aur sab bana do' },
    { i: '🔗', t: 'Footer menu links', s: 'Footer menu mein About, Contact, FAQ aur policies ke links add karo' },
    { i: '📝', t: 'Product descriptions', s: 'Jin products ki description khali hai unke liye achhi SEO description likho' }
  ]},
  { g: '📢 Ads aur Marketing', a: [
    { i: '📘', t: 'Facebook ad campaign', s: 'Mere best selling product ka poora Facebook ad campaign banao — targeting, copy, creative brief sab' },
    { i: '🎵', t: 'TikTok ad', s: 'TikTok ke liye ad banao — hooks aur video script ke saath' },
    { i: '🔍', t: 'Google ad', s: 'Google Ads campaign banao — keywords aur ad copy ke saath' },
    { i: '🎬', t: '5 ad variants', s: 'Mere top product ke 5 alag ad copy variants banao A/B testing ke liye' },
    { i: '🛒', t: 'Abandoned cart emails', s: 'Abandoned cart email sequence banao' },
    { i: '📧', t: 'Sale campaign', s: 'Ek sale campaign ka poora plan banao — email, SMS, WhatsApp' },
    { i: '📢', t: 'Ad research', s: 'Mere niche mein log kaunse ads chala rahe hain, research karo' }
  ]},
  { g: '🧠 Think Tank / Strategy', a: [
    { i: '💡', t: 'Sales double karo', s: 'Think tank mode: meri sales double karne ka poora plan banao' },
    { i: '⚔️', t: 'Competitor analysis', s: 'Mere competitor ka analysis karo aur battle plan banao — main tumhe domain bataunga' },
    { i: '💰', t: 'Pricing strategy', s: 'Meri pricing analyse karo — kya sahi hai, kya barhana chahiye' },
    { i: '🔎', t: 'SEO plan', s: 'Poora SEO plan banao — keywords, blog ideas, product optimization' },
    { i: '📈', t: 'Kya trend kar raha hai', s: 'Pakistan mein abhi kya trend kar raha hai, aur main us se kaise faida uthaun?' },
    { i: '🏆', t: 'Winning products', s: 'Mere niche mein winning products dhoondo jo main add kar sakun' },
    { i: '🕵️', t: 'Competitor spy', s: 'Ek competitor Shopify store ke products aur prices nikalo' }
  ]},
  { g: '📦 Rozana ke kaam', a: [
    { i: '🧾', t: 'Naye orders', s: 'Aaj ke naye orders dikhao' },
    { i: '🚚', t: 'Bhejne wale orders', s: 'Kaunse orders abhi tak ship nahi hue?' },
    { i: '⚠️', t: 'Low stock', s: 'Kam stock wale products dikhao' },
    { i: '📊', t: '30 din sales', s: 'Pichle 30 din ki sales report do' },
    { i: '👥', t: 'Top customers', s: 'Mere top customers kaun hain?' },
    { i: '🎟️', t: 'Discount banao', s: '10% ka discount code banao' }
  ]}
];
function buildGrow() {
  const el = $('#growbody'); let h = '';
  GROW.forEach(sec => {
    h += '<div class="sec">' + sec.g + '</div>';
    sec.a.forEach(x => {
      h += `<div class="item act" data-s="${esc(x.s)}">
        <div class="ph">${x.i}</div>
        <div class="t"><b>${esc(x.t)}</b><small>${esc(x.s).slice(0, 58)}…</small></div>
        <span class="tag b">GO</span></div>`;
    });
  });
  el.innerHTML = h;
  el.querySelectorAll('.act').forEach(n => n.onclick = () => { go('chat'); send(n.dataset.s); });
}

/* ---------- nav ---------- */
function go(p) {
  page = p;
  $$('nav b').forEach(b => b.classList.toggle('on', b.dataset.p === p));
  $$('.page').forEach(x => x.classList.toggle('on', x.id === 'p-' + p));
  $('#sug').style.display = p === 'chat' ? 'flex' : 'none';
  document.querySelector('footer').style.display = p === 'chat' ? 'block' : 'none';
  $('#main').scrollTop = 0;
  if (p === 'dash') loadDash();
  if (p === 'grow') buildGrow();
  if (p === 'social') buildSocial();
}
$$('nav b').forEach(b => b.onclick = () => go(b.dataset.p));
window.onAndroidBack = () => { if (page !== 'chat') { go('chat'); return true; } return false; };

/* ---------- status ---------- */
async function status() {
  const c = Store.get();
  const s = !!(c.shop.domain && c.shop.token), a = !!c.ai.key;
  const on = isOnline();
  $('#offbar').classList.toggle('on', !on);
  const d = $('#dot');
  d.className = 'dot' + (!on ? ' half' : (s && a ? ' on' : (s || a ? ' half' : '')));
  $('#stat').textContent = !on ? 'Offline mode' :
    (s && a ? 'Sab tayar · ' + (c.ai.model || '').split('/').pop().slice(0, 20)
      : s ? 'AI key chahiye' : a ? 'Store connect karein' : 'Setup zaroori hai');
  const cs = Cache.get('shop');
  if (cs?.v?.name) $('#sname').textContent = cs.v.name;
  if (s && on) {
    try {
      const sh = await TOOLS.get_shop_info.run();
      Cache.put('shop', sh);
      $('#sname').textContent = sh.name;
      TOOLS.detect_store_niche.run().then(n => Cache.put('niche', n)).catch(() => {});
    } catch (_) { }
  }
}
window.addEventListener('online', () => { status(); note('🌐 Internet wapas aa gaya — ab poori taaqat se kaam karunga.'); });
window.addEventListener('offline', () => { status(); note('📴 Internet chala gaya — offline mode on.'); });

/* ---------- dashboard ---------- */
async function loadDash() {
  const b = $('#dashbody');
  if (!Shop.ok()) { b.innerHTML = '<div class="empty"><div class="e">🔌</div>Settings mein Shopify store connect karein.</div>'; return; }
  b.innerHTML = '<div class="empty"><div class="e">⏳</div>Data load ho raha hai…</div>';
  try {
    const [sum, ord, low, th, prod] = await Promise.all([
      TOOLS.sales_summary.run({ days: 30 }).catch(e => ({ error: e.message })),
      TOOLS.list_orders.run({ limit: 6, status: 'any' }).catch(() => ({ orders: [] })),
      TOOLS.low_stock.run({ threshold: 5 }).catch(() => ({ items: [], count: 0 })),
      TOOLS.list_themes.run().catch(() => ({ themes: [] })),
      TOOLS.list_products.run({ limit: 5 }).catch(() => ({ products: [] }))
    ]);
    const cur = sum.currency || '';
    let h = '<div class="grid">' +
      kpi('30-din Revenue', cur + ' ' + Number(sum.revenue || 0).toLocaleString(), sum.orders + ' orders') +
      kpi('Avg Order', cur + ' ' + Number(sum.avg_order_value || 0).toLocaleString(), 'per order') +
      kpi('Unfulfilled', sum.unfulfilled ?? '—', 'bhejne wale') +
      kpi('Low Stock', low.count ?? 0, '≤ 5 baqi') +
      '</div>';

    if (sum.top_products?.length) {
      h += '<div class="sec">🏆 Top Products (30 din)</div>';
      sum.top_products.slice(0, 5).forEach((p, i) => {
        h += `<div class="item"><div class="ph">${['🥇', '🥈', '🥉', '4️⃣', '5️⃣'][i]}</div>
          <div class="t"><b>${esc(p.product)}</b><small>${p.units} bikay</small></div>
          <span class="tag g">${cur} ${Number(p.revenue).toLocaleString()}</span></div>`;
      });
    }
    if (ord.orders?.length) {
      h += '<div class="sec">🧾 Recent Orders</div>';
      ord.orders.forEach(o => {
        const f = o.fulfillment === 'fulfilled';
        h += `<div class="item"><div class="ph">${f ? '📦' : '⏳'}</div>
          <div class="t"><b>${o.order} · ${esc(o.customer)}</b><small>${new Date(o.created).toLocaleDateString()} · ${o.items} items</small></div>
          <span class="tag ${o.payment === 'paid' ? 'g' : 'y'}">${o.currency} ${o.total}</span></div>`;
      });
    }
    if (low.items?.length) {
      h += '<div class="sec">⚠️ Low Stock</div>';
      low.items.slice(0, 6).forEach(x => {
        h += `<div class="item"><div class="ph">📉</div>
          <div class="t"><b>${esc(x.product)}</b><small>${esc(x.variant || '')} ${x.sku ? '· ' + esc(x.sku) : ''}</small></div>
          <span class="tag ${x.stock <= 0 ? 'r' : 'y'}">${x.stock} left</span></div>`;
      });
    }
    if (th.themes?.length) {
      h += '<div class="sec">🎨 Themes</div>';
      th.themes.forEach(t => {
        h += `<div class="item"><div class="ph">${t.live ? '✅' : '🎨'}</div>
          <div class="t"><b>${esc(t.name)}</b><small>ID ${t.id}</small></div>
          <span class="tag ${t.live ? 'g' : 'b'}">${t.live ? 'LIVE' : t.role}</span></div>`;
      });
    }
    if (prod.products?.length) {
      h += '<div class="sec">🛍️ Products</div>';
      prod.products.forEach(p => {
        h += `<div class="item">${p.image ? `<img src="${p.image}">` : '<div class="ph">📦</div>'}
          <div class="t"><b>${esc(p.title)}</b><small>${cur} ${p.price || '—'} · stock ${p.inventory ?? '—'}</small></div>
          <span class="tag ${p.status === 'active' ? 'g' : 'y'}">${p.status}</span></div>`;
      });
    }
    b.innerHTML = h;
  } catch (e) {
    b.innerHTML = '<div class="empty"><div class="e">⚠️</div>' + esc(e.message) + '</div>';
  }
}
const kpi = (l, v, s) => `<div class="kpi"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- settings ---------- */
function fillProviders() {
  const sel = $('#i-prov'); sel.innerHTML = '';
  Object.entries(PROVIDERS).forEach(([k, p]) => {
    const o = document.createElement('option'); o.value = k; o.textContent = p.label; sel.appendChild(o);
  });
}
function fillModels(prov, cur) {
  const sel = $('#i-mdl'); sel.innerHTML = '';
  PROVIDERS[prov].models.forEach(m => {
    const o = document.createElement('option'); o.value = m; o.textContent = m; sel.appendChild(o);
  });
  sel.value = cur && PROVIDERS[prov].models.includes(cur) ? cur : PROVIDERS[prov].model;
  $('#keyhint').innerHTML = 'Free key: <a href="#" onclick="Native&&Native.openUrl(\'' + PROVIDERS[prov].keyUrl + '\');return false">' + PROVIDERS[prov].keyHint + '</a>';
}
function loadSettings() {
  const c = Store.get();
  $('#i-dom').value = c.shop.domain; $('#i-tok').value = c.shop.token;
  $('#i-prov').value = c.ai.provider; fillModels(c.ai.provider, c.ai.model);
  $('#i-key').value = c.ai.key;
}
$('#i-prov').onchange = e => fillModels(e.target.value, null);

$('#save').onclick = () => {
  Store.set({
    shop: { domain: $('#i-dom').value.trim(), token: $('#i-tok').value.trim() },
    ai: { provider: $('#i-prov').value, key: $('#i-key').value.trim(), model: $('#i-mdl').value }
  });
  toast('✅ Save ho gaya!'); status(); go('chat');
  note('Settings save ho gayin. Ab kuch bhi poochein!');
};
$('#test').onclick = async () => {
  Store.patch({ shop: { domain: $('#i-dom').value.trim(), token: $('#i-tok').value.trim() } });
  const b = $('#test'); b.textContent = '⏳ Check kar raha hun…';
  try {
    const s = await TOOLS.get_shop_info.run();
    b.textContent = '✅ Connected: ' + s.name;
    $('#sname').textContent = s.name; status();
  } catch (e) { b.textContent = '❌ ' + e.message.slice(0, 60); }
  setTimeout(() => b.textContent = '🔌  Connection test karein', 4500);
};
$('#export').onclick = () => {
  const c = Store.get();
  const t = 'Apsa backup\ndomain: ' + c.shop.domain + '\ntoken: ' + c.shop.token +
    '\nprovider: ' + c.ai.provider + '\nmodel: ' + c.ai.model + '\nkey: ' + c.ai.key;
  if (window.Native?.share) Native.share(t); else navigator.clipboard?.writeText(t);
  toast('Backup share/copy ho gaya');
};
$('#wipe').onclick = () => { if (confirm('Sab settings aur chat mit jayenge. Pakka?')) { Store.wipe(); location.reload(); } };

/* ---------- misc ---------- */
const toast = m => window.Native?.toast ? Native.toast(m) : console.log(m);
$('#bset').onclick = () => go('set');
document.addEventListener('click', e => {
  if (e.target?.id === 'openwiz') Wiz.open(true);
});
$('#bnew').onclick = () => { Store.clearHistory(); chat.innerHTML = ''; welcome(); go('chat'); };
$('#refresh').onclick = loadDash;
$('#snd').onclick = () => send();
inp.oninput = () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight, 120) + 'px'; };

/* ---------- boot ---------- */
function welcome() {
  const c = Store.get();
  const ready = !!(c.shop.domain && c.shop.token && c.ai.key);
  const off = !isOnline();
  bubble(md(ready
    ? `**Assalam-o-Alaikum!** 👋 Main **ECHO** hun.${off ? '\n\n📴 *Abhi offline hun — phir bhi bohat kuch kar sakta hun.*' : ''}\n\nAapki store ka AI manager. Mujhe bas bata dein, main khud kar dunga:\n\n🔬 **"Deep scan karo"** — poori store check, har masla dhoondh lunga\n🔧 **"Sab theek kar do"** — pages, policies, footer, menu — khud bana dunga\n🚦 **"Launch ke liye tayar hun?"** — checklist score ke saath\n🔥 **"Viral kit banao"** — content ideas, hooks, hashtags\n📢 **"Ad banao"** — targeting aur copy ke saath\n\n👉 Sab se aasan: neeche **🚀 Grow** tab kholein aur kisi button par tap karein.`
    : `**Assalam-o-Alaikum!** 👋 Main **ECHO** hun — aapki store ka AI manager.${off ? '\n\n📴 *Abhi offline hun.*' : ''}\n\nSetup abhi mukammal nahi hua. Fikar na karein — **2 tap ka kaam hai**.\n\nSetup ke baad main:\n• Poori store scan kar ke har masla dhoondta hun\n• Pages, policies, footer khud bana deta hun\n• Ads, hashtags, launch plan banata hun\n\n👉 Neeche button dabayein.`
  ), 'a');

  if (!ready) {
    const r = document.createElement('div'); r.className = 'acts';
    const b = document.createElement('button'); b.className = 'mini';
    b.style.cssText = 'border-color:var(--acc);color:var(--acc);font-size:12.5px;padding:7px 14px';
    b.textContent = '⚡ 2-minute setup shuru karein';
    b.onclick = () => Wiz.open(true);
    r.appendChild(b); chat.appendChild(r);
  }
  const h = Store.history();
  if (h.length) h.forEach(m => bubble(md(m.content), m.role === 'user' ? 'u' : 'a'));
}

fillProviders(); loadSettings(); chips(); buildGrow(); if (typeof buildSocial === 'function') buildSocial(); welcome(); status();
if (window.Native?.appVersion) $('#ver').textContent = 'v' + Native.appVersion();
setTimeout(() => { if (typeof Wiz !== 'undefined' && Wiz.needed()) Wiz.open(); }, 600);
