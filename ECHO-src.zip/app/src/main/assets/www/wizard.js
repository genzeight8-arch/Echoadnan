/* ============================================================
   wizard.js — 3-STEP PLUG & PLAY SETUP
   Beginner ke liye. Koi technical baat nahi.
   ============================================================ */

const Wiz = {
  step: 0,
  el: null,

  needed() {
    const c = Store.get();
    if (localStorage.getItem('echo_wiz_done') === '1') return false;
    return !(c.shop.domain && c.shop.token && c.ai.key);
  },

  open(force) {
    if (!force && !this.needed()) return;
    this.step = 0;
    if (!this.el) this.build();
    this.el.classList.add('open');
    this.render();
  },

  close() { this.el?.classList.remove('open'); },

  skip() {
    localStorage.setItem('echo_wiz_done', '1');
    this.close();
    if (typeof note === 'function') note('Setup baad mein ⚙️ Settings se kar sakte hain. Filhaal main offline mode mein kaam karunga.');
  },

  build() {
    const d = document.createElement('div');
    d.id = 'wiz';
    d.className = 'wiz';
    d.innerHTML = '<div class="wizcard"><div id="wizbody"></div></div>';
    document.body.appendChild(d);
    this.el = d;
  },

  render() {
    const b = document.getElementById('wizbody');
    const dots = n => [0, 1, 2, 3].map(i =>
      `<span class="wd ${i === n ? 'on' : ''} ${i < n ? 'done' : ''}"></span>`).join('');

    /* ---------- STEP 0: welcome ---------- */
    if (this.step === 0) {
      b.innerHTML = `
        <div class="wizhead">
          <div class="wizlogo">E</div>
          <h2>ECHO mein khush aamdeed</h2>
          <p class="wizsub">Aapki Shopify store ka AI manager</p>
        </div>
        <div class="wizfeat">
          <div class="wf"><b>🩺</b><span>Store ka deep scan — har masla dhoondta hun</span></div>
          <div class="wf"><b>🔧</b><span>Khud theek karta hun — pages, policies, footer</span></div>
          <div class="wf"><b>📢</b><span>Ads aur hashtags banata hun</span></div>
          <div class="wf"><b>🚀</b><span>Launch aur viral ka poora plan</span></div>
          <div class="wf"><b>📴</b><span>Internet na ho tab bhi kaam karta hun</span></div>
        </div>
        <div class="wizdots">${dots(0)}</div>
        <button class="btn" onclick="Wiz.go(1)">Shuru karein →</button>
        <button class="btn o" onclick="Wiz.skip()">Abhi nahi, baad mein</button>`;
      return;
    }

    /* ---------- STEP 1: AI key ---------- */
    if (this.step === 1) {
      b.innerHTML = `
        <div class="wizhead sm">
          <div class="wizn">1 / 2</div>
          <h2>🧠 ECHO ka dimaag on karein</h2>
          <p class="wizsub">Ek free key chahiye. 1 minute ka kaam.</p>
        </div>

        <div class="wizsteps">
          <div class="ws"><b>1</b><span>Neeche button dabayein — website khulegi</span></div>
          <div class="ws"><b>2</b><span>Google/email se sign up karein (free hai)</span></div>
          <div class="ws"><b>3</b><span>"Create API Key" dabayein → key copy karein</span></div>
          <div class="ws"><b>4</b><span>Wapas aa kar neeche paste karein</span></div>
        </div>

        <button class="btn glow" onclick="Wiz.openKey()">🔑  Free key lein (Groq)</button>
        <div class="hint" style="text-align:center">Credit card ki zaroorat nahi · hamesha free</div>

        <label>Key yahan paste karein</label>
        <input id="wz-key" type="text" placeholder="gsk_..." autocapitalize="off" autocorrect="off"
               oninput="Wiz.checkKey()">
        <div id="wz-kmsg" class="hint"></div>

        <button class="btn" id="wz-next1" onclick="Wiz.saveKey()">Aage barhein →</button>
        <button class="btn o" onclick="Wiz.go(2)">Chhorein — offline mode chalega</button>`;
      setTimeout(() => document.getElementById('wz-key')?.focus(), 300);
      return;
    }

    /* ---------- STEP 2: Shopify ---------- */
    if (this.step === 2) {
      b.innerHTML = `
        <div class="wizhead sm">
          <div class="wizn">2 / 2</div>
          <h2>🛍️ Apni store joriye</h2>
          <p class="wizsub">Taake main aapki store sambhal sakun</p>
        </div>

        <label>Store ka address</label>
        <input id="wz-dom" placeholder="meri-store.myshopify.com" autocapitalize="off" autocorrect="off">
        <div class="hint">Shopify admin ke URL mein jo likha hai — jaise <code>xyz.myshopify.com</code></div>

        <div class="wizsteps" style="margin-top:16px">
          <div class="wsh">Token kaise lein — 4 tap:</div>
          <div class="ws"><b>1</b><span>Shopify admin → <b>Settings</b> → <b>Apps and sales channels</b></span></div>
          <div class="ws"><b>2</b><span><b>Develop apps</b> → <b>Create an app</b> → naam: ECHO</span></div>
          <div class="ws"><b>3</b><span><b>Configure Admin API scopes</b> → neeche wala button dabayein aur SAB tick karein</span></div>
          <div class="ws"><b>4</b><span><b>Install app</b> → <b>Reveal token</b> → copy</span></div>
        </div>

        <button class="btn o" onclick="Wiz.showScopes()">📋  Scopes ki list copy karein</button>

        <label>Token paste karein</label>
        <input id="wz-tok" type="text" placeholder="shpat_..." autocapitalize="off" autocorrect="off">

        <div id="wz-smsg" class="hint"></div>
        <button class="btn" id="wz-next2" onclick="Wiz.saveShop()">🔌  Connect karein</button>
        <button class="btn o" onclick="Wiz.go(3)">Baad mein karunga</button>`;
      const c = Store.get();
      setTimeout(() => {
        const dm = document.getElementById('wz-dom');
        if (dm && c.shop.domain) dm.value = c.shop.domain;
      }, 50);
      return;
    }

    /* ---------- STEP 3: done ---------- */
    if (this.step === 3) {
      const c = Store.get();
      const okAi = !!c.ai.key, okShop = !!(c.shop.domain && c.shop.token);
      b.innerHTML = `
        <div class="wizhead">
          <div class="wizlogo done">${okAi && okShop ? '✓' : 'E'}</div>
          <h2>${okAi && okShop ? 'Sab tayar hai! 🎉' : 'Chaliye shuru karte hain'}</h2>
          <p class="wizsub">${okAi && okShop
            ? 'ECHO ab aapki store sambhal sakta hai'
            : 'Jitna setup hua hai utne se bhi kaam chalega'}</p>
        </div>

        <div class="wizstat">
          <div class="wst ${okAi ? 'ok' : 'no'}"><b>${okAi ? '✓' : '○'}</b> AI dimaag ${okAi ? 'on hai' : 'off — offline mode chalega'}</div>
          <div class="wst ${okShop ? 'ok' : 'no'}"><b>${okShop ? '✓' : '○'}</b> Store ${okShop ? 'juri hui hai' : 'nahi juri'}</div>
        </div>

        <div class="wizsteps">
          <div class="wsh">Ab yeh try karein:</div>
          <div class="ws go" onclick="Wiz.finish('Meri store ka deep scan karo aur bata kya kya masail hain')">
            <b>🩺</b><span>Store ka deep scan karo</span></div>
          <div class="ws go" onclick="Wiz.finish('Meri store mein jo bhi masail hain sab khud theek kar do')">
            <b>🔧</b><span>Sab kuch khud theek kar do</span></div>
          <div class="ws go" onclick="Wiz.finish('Launch ke liye kya kya karna hai?')">
            <b>🚀</b><span>Launch ke liye tayar karo</span></div>
          <div class="ws go" onclick="Wiz.finish('Hashtags do')">
            <b>#️⃣</b><span>Hashtags do</span></div>
        </div>

        <button class="btn" onclick="Wiz.finish()">Chalo shuru karein →</button>`;
      return;
    }
  },

  go(n) {
    if (this.step === 1 && n === 2) {
      const k = document.getElementById('wz-key')?.value.trim();
      if (k) Store.patch({ ai: Object.assign(Store.get().ai, { key: k }) });
    }
    this.step = n; this.render();
  },

  openKey() {
    const u = 'https://console.groq.com/keys';
    if (window.Native?.openUrl) Native.openUrl(u); else window.open(u, '_blank');
  },

  checkKey() {
    const v = document.getElementById('wz-key').value.trim();
    const m = document.getElementById('wz-kmsg');
    if (!v) { m.textContent = ''; m.className = 'hint'; return; }
    if (v.length < 20) { m.textContent = '⏳ Poori key paste karein…'; m.className = 'hint'; return; }
    m.textContent = '✓ Key theek lag rahi hai'; m.className = 'hint ok';
  },

  async saveKey() {
    const v = document.getElementById('wz-key').value.trim();
    const m = document.getElementById('wz-kmsg');
    const btn = document.getElementById('wz-next1');
    if (!v) { m.textContent = '⚠️ Pehle key paste karein (ya "Chhorein" dabayein)'; m.className = 'hint bad'; return; }

    // auto-detect provider from key prefix
    let prov = 'groq';
    if (v.startsWith('sk-or-')) prov = 'openrouter';
    else if (v.startsWith('AIza')) prov = 'gemini';
    else if (v.startsWith('sk-')) prov = 'openai';
    const model = PROVIDERS[prov].model;

    Store.patch({ ai: { provider: prov, key: v, model } });
    btn.textContent = '⏳ Check kar raha hun…';
    m.textContent = ''; m.className = 'hint';
    try {
      await llm([{ role: 'user', content: 'Say OK' }]);
      m.textContent = '✅ Kaam kar raha hai! (' + PROVIDERS[prov].label.split(' ')[0] + ')';
      m.className = 'hint ok';
      btn.textContent = 'Aage barhein →';
      setTimeout(() => this.go(2), 800);
    } catch (e) {
      m.textContent = '❌ ' + e.message.slice(0, 90) + ' — key dobara check karein';
      m.className = 'hint bad';
      btn.textContent = 'Dobara koshish karein';
    }
  },

  showScopes() {
    const s = 'read_products,write_products,read_orders,write_orders,read_customers,read_themes,write_themes,read_content,write_content,read_online_store_navigation,write_online_store_navigation,read_legal_policies,write_legal_policies,read_inventory,write_inventory,read_discounts,write_discounts,read_price_rules,write_price_rules,read_fulfillments,write_fulfillments,read_analytics';
    navigator.clipboard?.writeText(s.replace(/,/g, ', '));
    if (window.Native?.toast) Native.toast('Scopes copy ho gaye — Shopify mein search kar ke tick karein');
    const m = document.getElementById('wz-smsg');
    if (m) { m.innerHTML = '📋 Copy ho gaya! Shopify ki scopes list mein har naam search kar ke tick karein.'; m.className = 'hint ok'; }
  },

  async saveShop() {
    const d = document.getElementById('wz-dom').value.trim();
    const t = document.getElementById('wz-tok').value.trim();
    const m = document.getElementById('wz-smsg');
    const btn = document.getElementById('wz-next2');
    if (!d || !t) { m.textContent = '⚠️ Dono cheezein chahiye (ya "Baad mein" dabayein)'; m.className = 'hint bad'; return; }
    Store.patch({ shop: { domain: d, token: t } });
    btn.textContent = '⏳ Connect kar raha hun…';
    try {
      const s = await TOOLS.get_shop_info.run();
      Cache.put('shop', s);
      m.textContent = '✅ Juri gayi: ' + s.name;
      m.className = 'hint ok';
      btn.textContent = '✓ Connected';
      setTimeout(() => this.go(3), 900);
    } catch (e) {
      m.textContent = '❌ ' + e.message.slice(0, 110);
      m.className = 'hint bad';
      btn.textContent = 'Dobara koshish karein';
    }
  },

  finish(prompt) {
    localStorage.setItem('echo_wiz_done', '1');
    this.close();
    if (typeof status === 'function') status();
    if (typeof chat !== 'undefined') { chat.innerHTML = ''; Store.clearHistory(); }
    if (typeof welcome === 'function') welcome();
    if (prompt && typeof send === 'function') setTimeout(() => send(prompt), 350);
  }
};
