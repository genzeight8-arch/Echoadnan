package com.apsa.shopifyagent

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.FileProvider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Bridge exposed to JS as `Native`.
 * All HTTP is native (no CORS). Social sharing uses standard Android
 * share intents — the user always taps "post" themselves, so no platform
 * Terms of Service are violated and no account is ever at risk.
 */
class NativeBridge(private val ctx: Context, private val web: WebView) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json; charset=utf-8".toMediaType()

    /* ==================== HTTP ==================== */

    @JavascriptInterface
    fun request(reqId: String, method: String, url: String, headersJson: String, body: String?) {
        thread {
            var status = 0
            var text: String
            try {
                val b = if (body.isNullOrEmpty()) null else body.toRequestBody(JSON)
                val builder = Request.Builder().url(url)
                when (method.uppercase()) {
                    "GET" -> builder.get()
                    "DELETE" -> if (b == null) builder.delete() else builder.delete(b)
                    "PUT" -> builder.put(b ?: "".toRequestBody(JSON))
                    "PATCH" -> builder.patch(b ?: "".toRequestBody(JSON))
                    else -> builder.post(b ?: "".toRequestBody(JSON))
                }
                val h = JSONObject(headersJson)
                h.keys().forEach { k -> builder.addHeader(k, h.getString(k)) }

                http.newCall(builder.build()).execute().use { res ->
                    status = res.code
                    text = res.body?.string() ?: ""
                }
            } catch (e: Exception) {
                status = -1
                text = JSONObject().put("error", (e.message ?: "network error")).toString()
            }
            resolve(reqId, status, text)
        }
    }

    private fun resolve(reqId: String, status: Int, text: String) {
        val payload = JSONObject().put("id", reqId).put("status", status).put("body", text).toString()
        val js = "window.__nativeResolve(" + JSONObject.quote(payload) + ")"
        (ctx as Activity).runOnUiThread { web.evaluateJavascript(js, null) }
    }

    /* ==================== SOCIAL SHARE ====================
     * Opens the target app's share sheet with text (and optional image)
     * pre-filled. The USER taps post. Fully compliant with every
     * platform's Terms of Service.
     */

    private val PKG = mapOf(
        "whatsapp" to "com.whatsapp",
        "whatsapp_business" to "com.whatsapp.w4b",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "messenger" to "com.facebook.orca",
        "tiktok" to "com.zhiliaoapp.musically",
        "twitter" to "com.twitter.android",
        "telegram" to "org.telegram.messenger",
        "snapchat" to "com.snapchat.android",
        "pinterest" to "com.pinterest",
        "linkedin" to "com.linkedin.android"
    )

    /** Share text (and optionally an image saved via saveImage) to a specific app. */
    @JavascriptInterface
    fun shareTo(app: String, text: String, imagePath: String?) {
        (ctx as Activity).runOnUiThread {
            try {
                // caption goes to clipboard too — Instagram/TikTok don't accept
                // pre-filled captions with images, so user just long-presses paste
                copy(text)

                val hasImg = !imagePath.isNullOrEmpty() && File(imagePath!!).exists()
                val i = Intent(if (hasImg) Intent.ACTION_SEND else Intent.ACTION_SEND)
                if (hasImg) {
                    val f = File(imagePath!!)
                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                    i.type = "image/*"
                    i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } else {
                    i.type = "text/plain"
                }
                i.putExtra(Intent.EXTRA_TEXT, text)
                i.putExtra(Intent.EXTRA_SUBJECT, "GENZ8")

                val pkg = PKG[app.lowercase()]
                if (pkg != null && isInstalled(pkg)) {
                    i.setPackage(pkg)
                    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    toast("Caption copy ho gaya — app mein paste karein")
                } else {
                    ctx.startActivity(
                        Intent.createChooser(i, "Share karein")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            } catch (e: Exception) {
                toast("Share nahi ho saka: " + (e.message ?: ""))
            }
        }
    }

    /** Open WhatsApp chat with a pre-filled message (optionally to a number). */
    @JavascriptInterface
    fun whatsapp(number: String?, text: String) {
        (ctx as Activity).runOnUiThread {
            try {
                copy(text)
                val n = number?.replace(Regex("[^0-9]"), "") ?: ""
                val url = if (n.isNotEmpty())
                    "https://wa.me/$n?text=" + Uri.encode(text)
                else
                    "https://wa.me/?text=" + Uri.encode(text)
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                toast("WhatsApp nahi khula")
            }
        }
    }

    /** True/false JSON of which social apps are installed. */
    @JavascriptInterface
    fun installedApps(): String {
        val o = JSONObject()
        PKG.forEach { (k, v) -> o.put(k, isInstalled(v)) }
        return o.toString()
    }

    private fun isInstalled(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    /** Save a base64 data-url image to cache, return absolute path for shareTo(). */
    @JavascriptInterface
    fun saveImage(dataUrl: String, name: String): String {
        return try {
            val b64 = dataUrl.substringAfter(",", dataUrl)
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val dir = File(ctx.cacheDir, "shared")
            if (!dir.exists()) dir.mkdirs()
            val f = File(dir, if (name.endsWith(".png") || name.endsWith(".jpg")) name else "$name.png")
            FileOutputStream(f).use { it.write(bytes) }
            f.absolutePath
        } catch (e: Exception) { "" }
    }

    /** Save text content as a downloadable file the user can find later. */
    @JavascriptInterface
    fun saveText(fileName: String, content: String): String {
        return try {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "ECHO")
            if (!dir.exists()) dir.mkdirs()
            val f = File(dir, fileName)
            f.writeText(content)
            toast("Save ho gaya: ECHO/$fileName")
            f.absolutePath
        } catch (e: Exception) { "" }
    }

    /* ==================== UTIL ==================== */

    @JavascriptInterface
    fun copy(text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ECHO", text))
        } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        (ctx as Activity).runOnUiThread {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface
    fun openUrl(url: String) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun appVersion(): String = BuildConfig.VERSION_NAME
}
